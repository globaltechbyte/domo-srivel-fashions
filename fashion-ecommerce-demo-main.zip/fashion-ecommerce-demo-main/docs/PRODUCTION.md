# From demo to production: order tracking and orders

The demo stores everything in the visitor's browser (`localStorage`). That is fine for a presentation and **unsafe and
non-functional for a real shop**. This document lists what must change before real customers use order tracking.

## What the demo does and does not do

| Demo behaviour | Reality |
| --- | --- |
| Orders live in `localStorage` (`aurelle-demo:orders`) | Only the browser that placed the order can see it. The shop owner sees nothing. |
| `/admin-demo` edits the same `localStorage` store | Admin and customer only "sync" because they share one browser profile (tabs are synced via the `storage` event). |
| Tracking looks up order ID + mobile in that store | Anyone with the browser's devtools can read every order, including full addresses and phone numbers. |
| Courier name / number / URL are typed by hand | There is **no courier API integration**, no webhooks and no automatic status updates. |
| Status changes are clicks in the demo admin | No real packing, shipping or delivery is represented. |
| `/admin-demo` has no authentication | Anyone can open it. |

## Required for production

### 1. Server-side database and API
- Store orders, order lines, status history, shipping info and customers in a real database (e.g. Postgres).
- Expose a server API (REST/tRPC/GraphQL); the browser never reads the whole orders table.
- Shape to keep: `Order { id, publicRef, customerId, lines[], totals, method, status, paymentStatus, history[], shippingInfo }`.
  The `Order`, `StatusEvent` and `ShippingInfo` types in `src/types/index.ts` map directly to tables.
- Generate order references on the server with a collision-safe, **non-sequential** scheme. Demo refs are random 6-digit numbers
  and are guessable.

### 2. Secure customer order verification
- Today: order ID + mobile number, compared in the browser. A 6-digit ID plus a 10-digit phone number is weak and enumerable.
- Production options (use one or combine):
  - Send a one-time passcode (OTP) to the order's mobile number via SMS/WhatsApp before showing the order.
  - Email/WhatsApp a long, unguessable, signed tracking link (e.g. 128-bit random token or signed JWT with expiry).
  - Verify on the server; return only the fields the tracking page needs.
- Keep returning one generic "not found" response for any mismatch so the endpoint can't be used to confirm which IDs or phone numbers exist.
- Keep personal data minimal in the tracking response: first name + initial, city/state, partial PIN, no full address, no full phone.
  The demo already masks these client-side, but in production they must be masked **on the server** so they are never sent to the browser.

### 3. Rate limiting and abuse protection
- Rate-limit the lookup endpoint per IP and per order reference (e.g. 5 attempts / 15 minutes) with exponential back-off and temporary lockout.
- Add bot protection (CAPTCHA / Turnstile) after repeated failures; log and alert on enumeration patterns.
- The demo has a fake 750 ms "loading" delay only for presentation; it is **not** a security control.

### 4. Shared order state across devices
- With a server database, customers on any device and the shop owner on the admin all read the same data.
- For live updates, use polling, server-sent events or WebSockets rather than `localStorage` events.
- Make status transitions authoritative on the server (see `ORDER_FLOW`/`nextStatuses` in `src/lib/tracking.ts`) and write the history row in the same
  transaction as the status change. Reject invalid transitions with a 409.

### 5. Admin authentication and authorisation
- Put `/admin` behind real authentication (staff accounts, SSO or a managed provider), role-based permissions and audit logging
  (who changed which status, when).
- Never ship admin routes to unauthenticated browsers.

### 6. Courier tracking links and integrations
- Keep the current rule: only `http`/`https` URLs are rendered as links, with `rel="noopener noreferrer nofollow"`, in a new tab
  (see `safeTrackingUrl`). Re-validate **on the server** when the admin saves the URL.
- Better: store a courier code + tracking number and build the link from a server-side allow-list of courier URL templates.
- For genuine automatic updates, integrate each courier's (or an aggregator's) API/webhooks on the server and map their events to your statuses.
  Only then should the UI describe tracking as live.

### 7. Notifications and compliance
- Send status notifications (SMS/WhatsApp/email) from the server on each transition, with opt-in and unsubscribe.
- Publish a real privacy policy; define data-retention rules for order and customer data (India's DPDP Act applies to personal data of customers).
- Back up the database and restrict access to production data.

### 8. Payments (out of scope for this demo)
- Online payments need a PCI-compliant gateway and server-side webhook confirmation before an order is marked paid.
  COD "collected" in the demo is a manual toggle with no cash reconciliation.

## Suggested migration path

1. Introduce an `OrdersRepository` interface (`create`, `getByRefAndVerifier`, `advance`, `setShippingInfo`, `list`) and move the current Zustand store behind it.
2. Implement it against your API; keep the `localStorage` implementation for the demo build.
3. Add server-side validation that mirrors `src/lib/tracking.ts` (these functions are pure and unit-tested in `src/lib/tracking.test.ts`).
4. Add OTP/signed-link verification and rate limiting to the tracking endpoint.
5. Replace `/admin-demo` with an authenticated admin.


---

# Social proof galleries: from demo to production

The "Styled on Instagram" and "Loved by Our Customers" sections use clean, API-ready models (`InstagramItem`, `CustomerPhoto`, `MediaRef` in `src/types/index.ts`).
Only the storage layer is demo-specific.

## What the demo does and does not do

| Demo behaviour | Reality |
| --- | --- |
| Gallery metadata lives in `localStorage` (`aurelle-demo:social`) | Per browser. Nothing is shared with other devices, other browsers or your visitors. |
| Uploaded photos/videos live in this browser's IndexedDB (`aurelle-demo-media`) | Not synced; wiped by clearing site data, private windows or storage pressure. Large files are limited (images 5 MB, videos 25 MB). |
| Instagram cards link to the pasted post/reel URL | The demo never calls Instagram. It can't fetch thumbnails, captions or counts. |
| Consent is a checkbox plus an admin-only note | There is no verification that consent exists. It's a process reminder, not a legal record. |
| `/admin-demo` has no authentication | Anyone can open it and edit the gallery. |

## Required for production

1. **Server storage and a CDN.** Store `media` as object-storage keys served via a CDN, with image resizing (WebP/AVIF), poster frames and transcoded video (HLS/MP4).
   `MediaRef.source: 'upload'` becomes a CDN URL; the `value` field already abstracts this. Remove the IndexedDB layer (`src/lib/idb.ts`).
2. **Upload security.** Validate type and size on the server (never trust the browser's MIME type), scan for malware, re-encode images (the demo already strips EXIF/GPS by re-encoding),
   use signed upload URLs, and reject SVG. Authenticated, role-checked admin only.
3. **Instagram integration (optional).** To show real thumbnails and captions use the official Instagram Graph API / Basic Display or oEmbed with an approved app and a server-side token,
   respecting Meta's platform terms and rate limits. Keep storing the canonical post URL as the link target.
4. **Consent and privacy as records, not checkboxes.** Persist `consentAt`, who recorded it, and the evidence (e.g. a stored WhatsApp/email confirmation). Support withdrawal: a customer
   asking for removal must take effect promptly (the demo's visibility gate in `isPublishable` should be enforced server-side in the public API, so withheld items are never sent to browsers).
5. **Moderation workflow.** Have a second person approve customer photos; automated checks (OCR for phone numbers/addresses/parcel labels, face/children detection policy) supplement the admin's
   manual check. The demo's text scan (`detectPrivateData`) is a basic safeguard, not a guarantee.
6. **Reviews must be real.** Show feedback only when a customer wrote it and approved its use; never write or edit it for them. If you display ratings or "verified" badges, they must be backed
   by genuine order data and comply with advertising/consumer-protection rules (including India's Consumer Protection Act and ASCI guidelines on endorsements).
7. **Data protection.** Customer name, city and photos are personal data (India's DPDP Act): record the lawful basis, honour deletion requests, set retention periods, and keep an audit log of publishing decisions.
8. **Public API shape.** `GET /api/gallery/instagram` and `GET /api/gallery/customers` return only active/published items already filtered and sorted by `order`, and omit admin-only fields such as `consentNote`.
