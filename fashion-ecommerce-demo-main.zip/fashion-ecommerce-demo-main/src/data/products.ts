import { makeArt, type ArtPattern } from '../lib/art'
import type { CategoryInfo, CategorySlug, ColorOption, Product, Variant } from '../types'

/**
 * ─────────────────────────────────────────────────────────────
 *  SAMPLE PRODUCT DATA — edit freely.
 *  • `images` accepts real photo URLs (e.g. '/products/saree-1.jpg' placed in /public,
 *    or any https URL). Broken URLs fall back to an on-brand illustration automatically.
 *  • To scale to 500+ products, replace SEED_PRODUCTS with a fetch() from your API or
 *    a generated JSON file; the rest of the app only depends on the `Product` type.
 * ─────────────────────────────────────────────────────────────
 */

export const CATEGORIES: CategoryInfo[] = [
  { slug: 'sarees', label: 'Sarees', blurb: 'Handloom drapes & festive silks' },
  { slug: 'kurtis', label: 'Kurtis', blurb: 'Everyday elegance, effortlessly' },
  { slug: 'ethnic-sets', label: 'Ethnic Sets', blurb: 'Coordinated kurta sets' },
  { slug: 'western-wear', label: 'Western Wear', blurb: 'Tailored, modern separates' },
  { slug: 'dresses', label: 'Dresses', blurb: 'Fluid silhouettes for every day' },
  { slug: 'occasion-wear', label: 'Occasion Wear', blurb: 'Lehengas & gowns for celebrations' },
]

export const categoryLabel = (slug: CategorySlug) =>
  CATEGORIES.find((c) => c.slug === slug)?.label ?? slug

export const COLLECTIONS = [
  { slug: 'festive-edit', title: 'The Festive Edit', blurb: 'Zari, silk and celebration-ready silhouettes.', category: 'occasion-wear' as CategorySlug, hex: '#7A1F2B' },
  { slug: 'everyday-linen', title: 'Everyday Linen', blurb: 'Breathable, softly structured daywear.', category: 'kurtis' as CategorySlug, hex: '#9AAA8A' },
  { slug: 'heirloom-weaves', title: 'Heirloom Weaves', blurb: 'Sarees inspired by classic regional looms.', category: 'sarees' as CategorySlug, hex: '#1F5B4A' },
  { slug: 'city-edit', title: 'The City Edit', blurb: 'Work-to-evening western separates.', category: 'western-wear' as CategorySlug, hex: '#2C3E6B' },
]

export const SIZE_SETS = {
  apparel: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
  free: ['Free Size'],
}

const C: Record<string, ColorOption> = {
  wine: { name: 'Wine', hex: '#7A1F2B' },
  rose: { name: 'Dusty Rose', hex: '#C98B9A' },
  blush: { name: 'Blush', hex: '#E5BDB8' },
  ivory: { name: 'Ivory', hex: '#EFE5D3' },
  emerald: { name: 'Emerald', hex: '#1F5B4A' },
  sage: { name: 'Sage', hex: '#9AAA8A' },
  indigo: { name: 'Indigo', hex: '#2C3E6B' },
  sky: { name: 'Powder Blue', hex: '#A9BFD6' },
  mustard: { name: 'Mustard', hex: '#C99A2E' },
  terracotta: { name: 'Terracotta', hex: '#B9593A' },
  charcoal: { name: 'Charcoal', hex: '#3A3532' },
  lilac: { name: 'Lilac', hex: '#B3A2C9' },
  champagne: { name: 'Champagne', hex: '#D8C3A0' },
  maroon: { name: 'Maroon', hex: '#5E1A24' },
  teal: { name: 'Teal', hex: '#27696B' },
}

/** Deterministic pseudo-stock so the demo looks lived-in but is stable between reloads. */
function buildVariants(sizes: string[], colors: ColorOption[], seed: number, lowStock = false): Variant[] {
  const out: Variant[] = []
  sizes.forEach((size, si) => {
    colors.forEach((color, ci) => {
      let stock = ((seed * 7 + si * 5 + ci * 3) % 9) + 2
      if (lowStock) stock = (si + ci) % 3 === 0 ? 0 : (seed + si) % 3 + 1
      out.push({ size, color: color.name, stock })
    })
  })
  return out
}

interface Seed {
  n: string
  cat: CategorySlug
  price: number
  was?: number
  colors: (keyof typeof C)[]
  pattern: ArtPattern
  desc: string
  fabric: string
  free?: boolean
  isNew?: boolean
  feat?: boolean
  best?: boolean
  low?: boolean
  collection?: string
}

const CARE_DEFAULT = ['Dry clean recommended', 'Wash separately in cold water if needed', 'Iron on low heat', 'Store folded in a breathable cotton bag']
const CARE_SILK = ['Dry clean only', 'Do not wring or bleach', 'Steam or iron on low heat from the reverse', 'Store wrapped in muslin; refold every few months']
const CARE_COTTON = ['Machine wash gentle, cold', 'Wash with similar colours', 'Medium iron while slightly damp', 'Do not tumble dry']

const slugify = (s: string) =>
  s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

const SEEDS: Seed[] = [
  // Sarees
  { n: 'Banarasi Zari Silk Saree', cat: 'sarees', price: 8499, was: 10499, colors: ['wine', 'emerald', 'champagne'], pattern: 'butti', fabric: 'Pure silk blend with zari weave', desc: 'A ceremonial drape woven with fine zari buttis and a richly detailed pallu. Comes with an unstitched matching blouse piece.', free: true, feat: true, best: true, collection: 'heirloom-weaves' },
  { n: 'Kanjivaram Temple Border Saree', cat: 'sarees', price: 12999, colors: ['maroon', 'teal', 'mustard'], pattern: 'stripe', fabric: 'Silk blend, temple-border weave', desc: 'Inspired by South Indian temple architecture, with a contrasting border and a gently structured fall that holds beautiful pleats.', free: true, isNew: true, feat: true, collection: 'heirloom-weaves' },
  { n: 'Chanderi Pastel Saree', cat: 'sarees', price: 4299, was: 5199, colors: ['blush', 'sky', 'sage'], pattern: 'dots', fabric: 'Chanderi cotton-silk', desc: 'Feather-light with a delicate sheen, finished with a slim gold border. A graceful choice for daytime celebrations.', free: true, best: true },
  { n: 'Organza Ombre Saree', cat: 'sarees', price: 5799, colors: ['rose', 'lilac', 'sky'], pattern: 'plain', fabric: 'Soft organza', desc: 'A sheer, ethereal drape with a graduated tone and a subtle scalloped edge. Pairs with a contrast blouse.', free: true, isNew: true },
  { n: 'Handloom Cotton Saree', cat: 'sarees', price: 2799, colors: ['indigo', 'terracotta', 'ivory'], pattern: 'stripe', fabric: '100% handloom cotton', desc: 'Breathable, crisp and made for long days. Naturally textured with a woven stripe pallu.', free: true, low: true },
  // Kurtis
  { n: 'Chikankari Straight Kurti', cat: 'kurtis', price: 1899, was: 2399, colors: ['ivory', 'blush', 'sky'], pattern: 'floral', fabric: 'Cotton with hand-style chikankari', desc: 'Delicate tonal embroidery along the yoke and hem on breathable cotton. A wardrobe staple that dresses up easily.', best: true, feat: true, collection: 'everyday-linen' },
  { n: 'Block Print A-line Kurti', cat: 'kurtis', price: 1499, colors: ['indigo', 'terracotta', 'sage'], pattern: 'dots', fabric: 'Pure cotton, block printed', desc: 'Hand-block inspired prints on a flattering A-line cut with three-quarter sleeves and side pockets.', isNew: true, collection: 'everyday-linen' },
  { n: 'Linen Notch-neck Kurti', cat: 'kurtis', price: 1699, colors: ['sage', 'champagne', 'charcoal'], pattern: 'plain', fabric: 'Linen blend', desc: 'Relaxed and quietly refined with a notched neckline and clean placket. Softens with every wash.', collection: 'everyday-linen' },
  { n: 'Anarkali Festive Kurti', cat: 'kurtis', price: 2599, was: 3199, colors: ['wine', 'emerald', 'mustard'], pattern: 'butti', fabric: 'Georgette with gold detailing', desc: 'A flowing Anarkali silhouette with gold-print motifs and a flared hem that moves beautifully.', isNew: true, feat: true },
  { n: 'Pintuck Cotton Kurti', cat: 'kurtis', price: 1299, colors: ['lilac', 'blush', 'ivory'], pattern: 'stripe', fabric: 'Cotton mul', desc: 'Fine pintuck detailing across the bodice gives soft structure. Light enough for humid days.', low: true },
  // Ethnic sets
  { n: 'Embroidered Kurta Pant Set', cat: 'ethnic-sets', price: 3499, was: 4299, colors: ['sage', 'rose', 'indigo'], pattern: 'floral', fabric: 'Cotton silk with thread embroidery', desc: 'A coordinated kurta, straight pants and dupatta. Thread-work neckline with a coordinated trim.', best: true, feat: true },
  { n: 'Gota Patti Festive Set', cat: 'ethnic-sets', price: 4999, colors: ['maroon', 'teal', 'champagne'], pattern: 'butti', fabric: 'Chanderi blend with gota patti trim', desc: 'Handwork-inspired gota detailing on the kurta and dupatta border. A celebration-ready three piece.', isNew: true, collection: 'festive-edit' },
  { n: 'Printed Cotton Co-ord Set', cat: 'ethnic-sets', price: 2799, colors: ['terracotta', 'sky', 'mustard'], pattern: 'dots', fabric: 'Soft cotton', desc: 'Easy kurta and palazzo pairing in a cheerful print. Designed for comfort from morning to evening.' },
  { n: 'Sharara Kurta Set', cat: 'ethnic-sets', price: 5499, was: 6499, colors: ['blush', 'lilac', 'emerald'], pattern: 'floral', fabric: 'Georgette with lining', desc: 'A graceful sharara with a short kurta and sheer dupatta. Light embroidery at the cuffs and neckline.', feat: true, collection: 'festive-edit' },
  // Western wear
  { n: 'Tailored Wide-leg Trousers Set', cat: 'western-wear', price: 3299, colors: ['charcoal', 'ivory', 'indigo'], pattern: 'plain', fabric: 'Crepe blend', desc: 'A relaxed blouse with high-waist wide-leg trousers. Sharp enough for the office, easy enough for dinner.', isNew: true, collection: 'city-edit' },
  { n: 'Satin Co-ord Set', cat: 'western-wear', price: 3799, was: 4599, colors: ['champagne', 'wine', 'sage'], pattern: 'plain', fabric: 'Matte satin', desc: 'A fluid shirt-and-trouser pairing with a subtle sheen that drapes cleanly.', best: true, collection: 'city-edit' },
  { n: 'Linen Blazer & Pant Set', cat: 'western-wear', price: 4599, colors: ['sky', 'ivory', 'charcoal'], pattern: 'stripe', fabric: 'Linen viscose', desc: 'A relaxed blazer with straight-leg pants for polished days. Lightly structured, never stiff.', collection: 'city-edit' },
  { n: 'Ribbed Knit Top & Skirt Set', cat: 'western-wear', price: 2899, colors: ['blush', 'lilac', 'charcoal'], pattern: 'stripe', fabric: 'Stretch rib knit', desc: 'A soft two-piece in stretch knit that holds its shape through the day.', low: true },
  // Dresses
  { n: 'Midi Wrap Dress', cat: 'dresses', price: 2999, was: 3699, colors: ['wine', 'sage', 'sky'], pattern: 'floral', fabric: 'Viscose crepe', desc: 'An adjustable wrap bodice and flowing midi skirt that flatters every figure. Fully lined.', best: true, feat: true },
  { n: 'Tiered Maxi Dress', cat: 'dresses', price: 3499, colors: ['terracotta', 'ivory', 'indigo'], pattern: 'dots', fabric: 'Cotton voile', desc: 'Tiers of airy voile create movement and volume. Easy for travel and long afternoons.', isNew: true },
  { n: 'Fit & Flare Day Dress', cat: 'dresses', price: 2499, colors: ['blush', 'champagne', 'lilac'], pattern: 'plain', fabric: 'Poly crepe', desc: 'A clean V-neckline, defined waist and softly flared skirt with hidden side pockets.' },
  { n: 'Shirt Dress with Belt', cat: 'dresses', price: 3199, was: 3899, colors: ['ivory', 'sage', 'charcoal'], pattern: 'stripe', fabric: 'Cotton poplin', desc: 'A modern shirt dress with a removable belt, crisp collar and a graceful midi length.' },
  // Occasion wear
  { n: 'Velvet & Zari Lehenga', cat: 'occasion-wear', price: 18999, was: 22999, colors: ['maroon', 'emerald', 'indigo'], pattern: 'butti', fabric: 'Velvet with zari embroidery', desc: 'A statement bridal-guest lehenga with a heavy hem, structured choli and sheer dupatta.', free: true, feat: true, best: true, collection: 'festive-edit' },
  { n: 'Pastel Organza Lehenga', cat: 'occasion-wear', price: 14999, colors: ['blush', 'sky', 'lilac'], pattern: 'floral', fabric: 'Organza with sequin detailing', desc: 'Light as air with a voluminous skirt and delicate sequin florals. Made for day celebrations.', isNew: true, collection: 'festive-edit' },
  { n: 'Satin Evening Gown', cat: 'occasion-wear', price: 9999, was: 12499, colors: ['wine', 'indigo', 'champagne'], pattern: 'plain', fabric: 'Duchess satin', desc: 'A sculpted bodice and sweeping skirt in lustrous satin. Elegant simplicity for evening events.', feat: true },
  { n: 'Sequin Cocktail Gown', cat: 'occasion-wear', price: 11499, colors: ['emerald', 'charcoal', 'rose'], pattern: 'dots', fabric: 'Sequin mesh, fully lined', desc: 'Shimmering tonal sequins and a flattering floor-length cut for cocktail evenings.', low: true },
  { n: 'Indo-western Draped Gown', cat: 'occasion-wear', price: 8499, colors: ['teal', 'rose', 'mustard'], pattern: 'butti', fabric: 'Crepe with pre-draped dupatta', desc: 'A modern fusion silhouette with an integrated draped panel and gold-edged border.', isNew: true },
]

function buildProduct(s: Seed, i: number): Product {
  const colors = s.colors.map((k) => C[k])
  const sizes = s.free ? SIZE_SETS.free : SIZE_SETS.apparel
  const variants = buildVariants(sizes, colors, i + 1, s.low)
  const first = colors[0].hex
  const views = ['front', 'detail', 'styled', 'flat'] as const
  return {
    id: `p${String(i + 1).padStart(3, '0')}`,
    name: s.n,
    slug: slugify(s.n),
    category: s.cat,
    description: s.desc,
    fabric: s.fabric,
    care: s.cat === 'sarees' && s.fabric.toLowerCase().includes('silk') ? CARE_SILK : s.fabric.toLowerCase().includes('cotton') ? CARE_COTTON : CARE_DEFAULT,
    price: s.price,
    compareAtPrice: s.was,
    images: views.map((view) => makeArt({ category: s.cat, pattern: s.pattern, view, hex: first })),
    colors,
    sizes,
    variants,
    stock: variants.reduce((n, v) => n + v.stock, 0),
    isNew: !!s.isNew,
    isFeatured: !!s.feat,
    isBestseller: !!s.best,
    collection: s.collection,
  }
}

export const SEED_PRODUCTS: Product[] = SEEDS.map(buildProduct)
