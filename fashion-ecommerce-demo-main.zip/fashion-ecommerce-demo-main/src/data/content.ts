import { makeArt } from '../lib/art'
import type { CategorySlug } from '../types'

/** Art direction for the homepage category tiles. */
export const CATEGORY_ART: Record<CategorySlug, string> = {
  sarees: makeArt({ category: 'sarees', pattern: 'butti', view: 'styled', hex: '#1F5B4A' }),
  kurtis: makeArt({ category: 'kurtis', pattern: 'floral', view: 'styled', hex: '#C98B9A' }),
  'ethnic-sets': makeArt({ category: 'ethnic-sets', pattern: 'floral', view: 'styled', hex: '#9AAA8A' }),
  'western-wear': makeArt({ category: 'western-wear', pattern: 'plain', view: 'styled', hex: '#2C3E6B' }),
  dresses: makeArt({ category: 'dresses', pattern: 'plain', view: 'styled', hex: '#7A1F2B' }),
  'occasion-wear': makeArt({ category: 'occasion-wear', pattern: 'butti', view: 'styled', hex: '#B9593A' }),
}

export const VALUES = [
  { title: 'Craftsmanship', body: 'Fabrics chosen for hand-feel and longevity, with finishing details you notice only up close.' },
  { title: 'Confidence', body: 'Silhouettes cut to flatter many figures, so you can stop adjusting and start enjoying the moment.' },
  { title: 'Elegance', body: 'A restrained palette and quiet embellishment. Pieces that never shout, and never date.' },
  { title: 'Comfort', body: 'Breathable weaves and thoughtful linings, designed for Indian weather and long celebrations.' },
]

export const PAGES: Record<string, { title: string; sections: { h: string; p: string }[] }> = {
  about: {
    title: 'About Srivel Fashion House',
    sections: [
      { h: 'Our story', p: 'Srivel Fashion House is a placeholder brand created for this demonstration. Replace this text with your own story: who you are, where your pieces come from, and what makes your boutique different.' },
      { h: 'What we make', p: 'Sarees, kurtis, ethnic sets, western wear, dresses and occasion wear, designed for Indian women and the way they dress today.' },
      { h: 'Our promise', p: 'Considered fabrics, honest sizing information and a personal service by WhatsApp.' },
    ],
  },
  contact: {
    title: 'Contact us',
    sections: [
      { h: 'WhatsApp', p: 'Orders and queries are handled over WhatsApp. The number in this demo is an editable placeholder — set yours in src/config.ts.' },
      { h: 'Email', p: 'hello@your-brand.example (placeholder). Replace with your own address.' },
      { h: 'Hours', p: 'Monday to Saturday, 10:00 – 19:00 IST (sample hours).' },
    ],
  },
  shipping: {
    title: 'Shipping policy',
    sections: [
      { h: 'Delivery time', p: 'Sample policy: orders are typically delivered in 4–7 business days across India after confirmation.' },
      { h: 'Charges', p: 'Sample policy: free shipping on orders above ₹2,999; a flat ₹99 applies below that. Edit these rules in src/config.ts.' },
      { h: 'Cash on Delivery', p: 'Cash on Delivery is available on eligible pin codes. Orders are confirmed by our team before dispatch.' },
    ],
  },
  returns: {
    title: 'Return policy',
    sections: [
      { h: 'Returns & exchanges', p: 'Sample policy: unused items with tags can be exchanged within 7 days of delivery. Sarees and customised pieces are final sale.' },
      { h: 'How to request', p: 'Message us on WhatsApp with your order number and a photo of the item.' },
      { h: 'Refunds', p: 'Sample policy: approved refunds are processed to the original payment method, or as store credit.' },
    ],
  },
  privacy: {
    title: 'Privacy policy',
    sections: [
      { h: 'This demo', p: 'This demonstration stores your cart, wishlist and simulated orders only in your own browser (localStorage). Nothing is sent to a server.' },
      { h: 'In production', p: 'Replace this page with your real privacy policy before launch, covering what personal data you collect and how it is used.' },
    ],
  },
}
