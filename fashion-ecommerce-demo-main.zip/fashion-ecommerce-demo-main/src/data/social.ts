import { makeArt, type ArtPattern, type ArtView } from '../lib/art'
import type { CategorySlug, CustomerPhoto, InstagramItem, MediaRef } from '../types'

/**
 * DEMO SEED DATA. Every item here is a generated illustration labelled `isDemo`.
 * None of it is a real Instagram post, a real customer, or a real review.
 * Real content is added in /admin-demo/instagram and /admin-demo/customers.
 */

const art = (category: CategorySlug, pattern: ArtPattern, view: ArtView, hex: string): MediaRef => ({
  source: 'art',
  kind: 'image',
  value: makeArt({ category, pattern, view, hex }),
})
const at = (n: number) => new Date(Date.UTC(2026, 0, 1, 10, n)).toISOString()

export const SEED_INSTAGRAM: InstagramItem[] = [
  { id: 'ig-1', type: 'post', media: art('occasion-wear', 'butti', 'styled', '#7A1F2B'), caption: 'Festive evenings in velvet and zari', order: 1, active: true, isDemo: true, createdAt: at(1) },
  { id: 'ig-2', type: 'post', media: art('kurtis', 'dots', 'flat', '#A9BFD6'), caption: 'Block prints, softly pressed', order: 2, active: true, isDemo: true, createdAt: at(2) },
  { id: 'ig-3', type: 'reel', media: art('sarees', 'butti', 'front', '#1F5B4A'), caption: 'How to drape a Banarasi in minutes', order: 3, active: true, isDemo: true, createdAt: at(3) },
  { id: 'ig-4', type: 'post', media: art('dresses', 'floral', 'styled', '#B9593A'), caption: 'Terracotta and tiered voile', order: 4, active: true, isDemo: true, createdAt: at(4) },
  { id: 'ig-5', type: 'post', media: art('ethnic-sets', 'floral', 'front', '#E5BDB8'), caption: 'Blush sharara sets', order: 5, active: true, isDemo: true, createdAt: at(5) },
  { id: 'ig-6', type: 'post', media: art('sarees', 'stripe', 'detail', '#27696B'), caption: 'Temple border, up close', order: 6, active: true, isDemo: true, createdAt: at(6) },
  { id: 'ig-7', type: 'reel', media: art('western-wear', 'plain', 'styled', '#2C3E6B'), caption: 'Desk to dinner in one co-ord', order: 7, active: true, isDemo: true, createdAt: at(7) },
  { id: 'ig-8', type: 'post', media: art('dresses', 'plain', 'front', '#D8C3A0'), caption: 'Champagne, always', order: 8, active: true, isDemo: true, createdAt: at(8) },
  { id: 'ig-9', type: 'post', media: art('kurtis', 'floral', 'styled', '#9AAA8A'), caption: 'Sage linen for slow Sundays', order: 9, active: true, isDemo: true, createdAt: at(9) },
]

/** Placeholder delivery photos: no review text is ever pre-written. */
export const SEED_CUSTOMERS: CustomerPhoto[] = [
  { id: 'cp-1', photo: art('sarees', 'butti', 'front', '#7A1F2B'), displayName: 'Demo A.', city: 'Sample City', productName: 'Banarasi Zari Silk Saree', consentGiven: false, privacyChecked: false, order: 1, visible: true, isDemo: true, createdAt: at(1) },
  { id: 'cp-2', photo: art('kurtis', 'floral', 'flat', '#C98B9A'), displayName: 'Demo B.', city: 'Sample City', productName: 'Chikankari Straight Kurti', consentGiven: false, privacyChecked: false, order: 2, visible: true, isDemo: true, createdAt: at(2) },
  { id: 'cp-3', photo: art('dresses', 'dots', 'styled', '#1F5B4A'), displayName: 'Demo C.', city: 'Sample City', productName: 'Midi Wrap Dress', consentGiven: false, privacyChecked: false, order: 3, visible: true, isDemo: true, createdAt: at(3) },
  { id: 'cp-4', photo: art('occasion-wear', 'butti', 'front', '#5E1A24'), displayName: 'Demo D.', city: 'Sample City', productName: 'Velvet & Zari Lehenga', consentGiven: false, privacyChecked: false, order: 4, visible: true, isDemo: true, createdAt: at(4) },
  { id: 'cp-5', photo: art('ethnic-sets', 'plain', 'styled', '#9AAA8A'), displayName: 'Demo E.', city: 'Sample City', productName: 'Embroidered Kurta Pant Set', consentGiven: false, privacyChecked: false, order: 5, visible: true, isDemo: true, createdAt: at(5) },
  { id: 'cp-6', photo: art('western-wear', 'stripe', 'flat', '#2C3E6B'), displayName: 'Demo F.', city: 'Sample City', productName: 'Satin Co-ord Set', consentGiven: false, privacyChecked: false, order: 6, visible: true, isDemo: true, createdAt: at(6) },
]
