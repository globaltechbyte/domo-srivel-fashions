import type { Order, OrderStatus, StatusEvent } from '../types'

/**
 * Illustrative sample orders so the admin demo and tracking page have content on first load.
 * All customers, mobiles, couriers and tracking numbers are FICTIONAL.
 */
const HOUR = 3_600_000
const created = (daysAgo: number, hoursOffset: number) => Date.now() - daysAgo * 24 * HOUR - hoursOffset * HOUR

/** Builds a status history from [status, hours-after-creation] pairs. */
function history(createdMs: number, steps: [OrderStatus, number][]): StatusEvent[] {
  return steps.map(([status, h]) => ({ status, at: new Date(createdMs + h * HOUR).toISOString() }))
}

const iso = (ms: number) => new Date(ms).toISOString()

const c1 = created(0, 2)
const c2 = created(1, 5)
const c3 = created(2, 3)
const c4 = created(4, 1)
const c5 = created(6, 6)
const c6 = created(8, 4)
const cTest = created(3, 2)

export const DEMO_TEST_ORDER = { ref: 'AUR-DEMO-TEST01', mobile: '9000000000' }

export const SAMPLE_ORDERS: Order[] = [
  {
    id: 'demo-test', ref: DEMO_TEST_ORDER.ref, createdAt: iso(cTest), isSample: true, isDemoTest: true, method: 'cod',
    customer: { fullName: 'Demo Tester', mobile: DEMO_TEST_ORDER.mobile, address1: '1, Demo Lane', address2: 'Test Nagar', city: 'Bengaluru', state: 'Karnataka', pincode: '560001', landmark: '' },
    lines: [
      { productId: 'p002', name: 'Kanjivaram Temple Border Saree', size: 'Free Size', color: 'Maroon', qty: 1, unitPrice: 12999 },
      { productId: 'p010', name: 'Pintuck Cotton Kurti', size: 'M', color: 'Lilac', qty: 1, unitPrice: 1299 },
    ],
    subtotal: 14298, shipping: 0, total: 14298, status: 'Shipped', paymentStatus: 'COD – Pending',
    history: history(cTest, [['Pending Confirmation', 0], ['Confirmed', 3], ['Packed', 20], ['Shipped', 30]]),
    shippingInfo: { courierName: 'Sample Courier Express', trackingNumber: 'SCX-DEMO-0001', trackingUrl: 'https://example.com/track/SCX-DEMO-0001' },
  },
  {
    id: 'sample-1', ref: 'AUR-DEMO-100241', createdAt: iso(c1), isSample: true, method: 'cod',
    customer: { fullName: 'Sample Customer A', mobile: '9000000001', address1: '12, Sample Residency', address2: 'Sample Road', city: 'Bengaluru', state: 'Karnataka', pincode: '560001', landmark: 'Near sample park' },
    lines: [{ productId: 'p001', name: 'Banarasi Zari Silk Saree', size: 'Free Size', color: 'Wine', qty: 1, unitPrice: 8499 }],
    subtotal: 8499, shipping: 0, total: 8499, status: 'Pending Confirmation', paymentStatus: 'COD – Pending',
    history: history(c1, [['Pending Confirmation', 0]]),
  },
  {
    id: 'sample-2', ref: 'AUR-DEMO-100238', createdAt: iso(c2), isSample: true, method: 'whatsapp',
    customer: { fullName: 'Sample Customer B', mobile: '9000000002', address1: '45, Sample Heights', address2: '', city: 'Mumbai', state: 'Maharashtra', pincode: '400001', landmark: '' },
    lines: [
      { productId: 'p006', name: 'Chikankari Straight Kurti', size: 'M', color: 'Ivory', qty: 2, unitPrice: 1899 },
      { productId: 'p007', name: 'Block Print A-line Kurti', size: 'M', color: 'Indigo', qty: 1, unitPrice: 1499 },
    ],
    subtotal: 5297, shipping: 0, total: 5297, status: 'Confirmed', paymentStatus: 'Not applicable',
    history: history(c2, [['Pending Confirmation', 0], ['Confirmed', 4]]),
  },
  {
    id: 'sample-3', ref: 'AUR-DEMO-100230', createdAt: iso(c3), isSample: true, method: 'cod',
    customer: { fullName: 'Sample Customer C', mobile: '9000000003', address1: '7, Sample Enclave', address2: 'Sector 9', city: 'Jaipur', state: 'Rajasthan', pincode: '302001', landmark: 'Opp. sample market' },
    lines: [{ productId: 'p019', name: 'Midi Wrap Dress', size: 'S', color: 'Sage', qty: 1, unitPrice: 2999 }],
    subtotal: 2999, shipping: 0, total: 2999, status: 'Shipped', paymentStatus: 'COD – Pending',
    history: history(c3, [['Pending Confirmation', 0], ['Confirmed', 2], ['Packed', 18], ['Shipped', 26]]),
    shippingInfo: { courierName: 'Sample Courier Express', trackingNumber: 'SCX-DEMO-0002', trackingUrl: 'https://example.com/track/SCX-DEMO-0002' },
  },
  {
    id: 'sample-4', ref: 'AUR-DEMO-100219', createdAt: iso(c4), isSample: true, method: 'cod',
    customer: { fullName: 'Sample Customer D', mobile: '9000000004', address1: '88, Sample Villas', address2: '', city: 'Chennai', state: 'Tamil Nadu', pincode: '600001', landmark: '' },
    lines: [{ productId: 'p011', name: 'Embroidered Kurta Pant Set', size: 'L', color: 'Dusty Rose', qty: 1, unitPrice: 3499 }],
    subtotal: 3499, shipping: 0, total: 3499, status: 'Delivered', paymentStatus: 'COD – Collected',
    history: history(c4, [['Pending Confirmation', 0], ['Confirmed', 3], ['Packed', 22], ['Shipped', 30], ['Delivered', 78]]),
    shippingInfo: { courierName: 'Demo Parcel Service', trackingNumber: 'DPS-DEMO-7781' },
  },
  {
    id: 'sample-5', ref: 'AUR-DEMO-100207', createdAt: iso(c5), isSample: true, method: 'cod',
    customer: { fullName: 'Sample Customer E', mobile: '9000000005', address1: '3, Sample Gardens', address2: 'Phase 2', city: 'Hyderabad', state: 'Telangana', pincode: '500001', landmark: '' },
    lines: [{ productId: 'p015', name: 'Tailored Wide-leg Trousers Set', size: 'M', color: 'Charcoal', qty: 1, unitPrice: 3299 }],
    subtotal: 3299, shipping: 0, total: 3299, status: 'Cancelled', paymentStatus: 'COD – Pending',
    history: history(c5, [['Pending Confirmation', 0], ['Confirmed', 5], ['Cancelled', 9]]),
  },
  {
    id: 'sample-6', ref: 'AUR-DEMO-100198', createdAt: iso(c6), isSample: true, method: 'whatsapp',
    customer: { fullName: 'Sample Customer F', mobile: '9000000006', address1: '21, Sample Court', address2: '', city: 'Pune', state: 'Maharashtra', pincode: '411001', landmark: 'Behind sample mall' },
    lines: [{ productId: 'p003', name: 'Chanderi Pastel Saree', size: 'Free Size', color: 'Blush', qty: 1, unitPrice: 4299 }],
    subtotal: 4299, shipping: 0, total: 4299, status: 'Packed', paymentStatus: 'Not applicable',
    history: history(c6, [['Pending Confirmation', 0], ['Confirmed', 3], ['Packed', 27]]),
  },
]
