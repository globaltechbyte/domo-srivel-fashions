// ─────────────────────────────────────────────────────────────
//  EDIT HERE — brand identity, contact details and store rules
// ─────────────────────────────────────────────────────────────

export const BRAND = {
  name: 'Srivel Fashion House',
  tagline: "Women's Fashion",
  /** Shown in footer and static pages. Replace with real details. */
  email: 'srivel_fashionhouse@gmail.com',
  city: 'Chennai, India',
  instagramHandle: '@srivel_fashionhouse',
  instagramUrl: 'https://www.instagram.com/srivel_fashionhouse/',
}

export const INSTAGRAM_IS_PLACEHOLDER = !BRAND.instagramUrl || BRAND.instagramUrl === 'https://www.instagram.com/your_handle/'

/**
 * PLACEHOLDER WhatsApp Business number, country code first, digits only.
 * This is NOT a live number. Replace it before going live, e.g. '919876543210'.
 */
export const WHATSAPP_NUMBER = '918667491936'
export const WHATSAPP_IS_PLACEHOLDER = WHATSAPP_NUMBER === '918667491936'

export const SHIPPING = {
  /** Orders at or above this subtotal ship free (sample rule). */
  freeAbove: 2999,
  flatRate: 99,
  /** Shown on product pages. */
  eta: '4–7 business days',
}

export const ANNOUNCEMENT = 'Complimentary shipping on selected orders  |  New Collection Now Live'

/** Prefix used for all localStorage keys, so the demo never collides with other apps. */
export const STORAGE_PREFIX = 'srivel-fashionhouse-demo'
