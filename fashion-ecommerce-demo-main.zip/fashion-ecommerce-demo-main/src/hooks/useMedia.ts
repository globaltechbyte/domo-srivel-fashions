import { useEffect, useRef, useState } from 'react'
import { getMedia } from '../lib/idb'
import type { MediaRef } from '../types'

/** True once the element has come within `margin` of the viewport (and stays true). */
export function useInView<T extends Element>(margin = '240px') {
  const ref = useRef<T>(null)
  const [seen, setSeen] = useState(() => typeof IntersectionObserver === 'undefined')
  useEffect(() => {
    const el = ref.current
    if (seen || !el) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setSeen(true)
          io.disconnect()
        }
      },
      { rootMargin: margin },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [seen, margin])
  return [ref, seen] as const
}

// Shared object URLs for IndexedDB blobs: one URL per key, revoked when the last user unmounts.
const urlCache = new Map<string, { url: string; users: number }>()

export type MediaStatus = 'idle' | 'loading' | 'ready' | 'missing'

/**
 * Resolves a MediaRef to something an <img>/<video> can use.
 * `art` refs are rendered by <ProductArt/> instead, so they resolve to null here.
 */
export function useMediaSrc(media: MediaRef | undefined, enabled = true) {
  const [state, setState] = useState<{ key: string; src: string | null; status: MediaStatus }>({ key: '', src: null, status: 'idle' })
  const key = media ? `${media.source}:${media.value}` : ''

  useEffect(() => {
    if (!media || !enabled || media.source === 'art') return
    if (media.source === 'url') {
      setState({ key, src: media.value, status: 'ready' })
      return
    }
    let cancelled = false
    const id = media.value
    const cached = urlCache.get(id)
    if (cached) {
      cached.users++
      setState({ key, src: cached.url, status: 'ready' })
    } else {
      setState({ key, src: null, status: 'loading' })
      void getMedia(id).then((blob) => {
        if (cancelled) return
        if (!blob) return setState({ key, src: null, status: 'missing' })
        const hit = urlCache.get(id)
        const entry = hit ?? { url: URL.createObjectURL(blob), users: 0 }
        entry.users++
        urlCache.set(id, entry)
        setState({ key, src: entry.url, status: 'ready' })
      })
    }
    return () => {
      cancelled = true
      const entry = urlCache.get(id)
      if (!entry) return
      entry.users--
      if (entry.users <= 0) {
        // Defer so quick remounts (e.g. opening a lightbox) reuse the same URL.
        setTimeout(() => {
          const e = urlCache.get(id)
          if (e && e.users <= 0) {
            URL.revokeObjectURL(e.url)
            urlCache.delete(id)
          }
        }, 4000)
      }
    }
  }, [key, enabled, media])

  if (!media || media.source === 'art') return { src: null, status: 'idle' as MediaStatus }
  if (state.key !== key) return { src: null, status: (enabled ? 'loading' : 'idle') as MediaStatus }
  return { src: state.src, status: state.status }
}
