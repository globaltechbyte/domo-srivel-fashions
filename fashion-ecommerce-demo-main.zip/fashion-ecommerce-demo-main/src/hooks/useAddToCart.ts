import { useCallback } from 'react'
import { useCart } from '../store/cart'
import { useUI } from '../store/ui'
import type { Product } from '../types'

/** Adds a variant to the cart and reports the outcome with a toast. */
export function useAddToCart() {
  const add = useCart((s) => s.add)
  const openDrawer = useCart((s) => s.openDrawer)
  const toast = useUI((s) => s.toast)

  return useCallback(
    (product: Product, size: string, color: string, qty = 1) => {
      const res = add(product, size, color, qty)
      if (res.ok) {
        toast(`${product.name} added to your bag`, 'success', { label: 'View bag', onClick: openDrawer })
      } else {
        toast(res.reason ?? 'Could not add this item.', 'error')
      }
      return res.ok
    },
    [add, openDrawer, toast],
  )
}
