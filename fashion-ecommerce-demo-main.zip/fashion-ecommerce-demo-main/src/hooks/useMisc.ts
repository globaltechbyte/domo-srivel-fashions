import { useEffect, useState } from 'react'

/** Simulates a short loading period so skeletons are visible (demo-only). */
export function useSimulatedLoading(ms = 450, key: string = '') {
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), ms)
    return () => clearTimeout(t)
  }, [ms, key])
  return loading
}

export function useScrolled(threshold = 12) {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > threshold)
    on()
    window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [threshold])
  return scrolled
}

export function useDocumentTitle(title: string) {
  useEffect(() => {
    document.title = title ? `${title} — Srivel Fashion House` : "Srivel Fashion House — Women's Fashion"
  }, [title])
}
