import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'

const KEY = 'aurelle-demo:intro-seen'

function alreadySeen() {
  try {
    return sessionStorage.getItem(KEY) === '1'
  } catch {
    return false
  }
}

/** Branded intro shown once per browser session. */
export function Loader() {
  const [show, setShow] = useState(() => !alreadySeen())

  useEffect(() => {
    if (!show) return
    const t = setTimeout(() => {
      setShow(false)
      try {
        sessionStorage.setItem(KEY, '1')
      } catch {
        /* ignore */
      }
    }, 1500)
    return () => clearTimeout(t)
  }, [show])

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-[200] grid place-items-center bg-ivory"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
          role="status"
          aria-label="Loading Srivel Fashion House"
        >
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
              className="font-brand px-6 text-3xl font-semibold tracking-[-0.025em] text-charcoal md:text-4xl"
            >
              Srivel Fashion House
            </motion.div>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="mt-3 text-[11px] uppercase tracking-[0.3em] text-rose"
            >
              Women's Fashion
            </motion.p>
            <div className="mx-auto mt-8 h-px w-40 overflow-hidden bg-line">
              <motion.div className="h-full origin-left bg-rose" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 1.3, ease: 'easeInOut' }} />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
