import { ShoppingBag } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useCart, useCartLines } from '../../store/cart'
import { CartLineItem, ShippingProgress, SummaryRows } from '../product/CartParts'
import { Button } from '../ui/Button'
import { Overlay } from '../ui/Overlay'

export function CartDrawer() {
  const open = useCart((s) => s.drawerOpen)
  const close = useCart((s) => s.closeDrawer)
  const { lines, subtotal, shipping, total, count } = useCartLines()
  const navigate = useNavigate()
  const go = (to: string) => {
    close()
    navigate(to)
  }

  return (
    <Overlay
      open={open}
      onClose={close}
      mode="drawer"
      title={count ? `Your bag (${count})` : 'Your bag'}
      widthClass="max-w-[440px]"
      footer={
        lines.length > 0 && (
          <div className="space-y-4">
            <ShippingProgress subtotal={subtotal} />
            <SummaryRows subtotal={subtotal} shipping={shipping} total={total} />
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" onClick={() => go('/cart')}>
                View bag
              </Button>
              <Button onClick={() => go('/checkout')}>Checkout</Button>
            </div>
          </div>
        )
      }
    >
      {lines.length === 0 ? (
        <div className="flex h-full flex-col items-center justify-center px-8 py-16 text-center">
          <div className="mb-6 grid size-24 place-items-center rounded-full bg-rose-mist text-rose">
            <ShoppingBag size={36} strokeWidth={1.3} />
          </div>
          <h3 className="text-3xl">Your bag is empty</h3>
          <p className="mt-3 text-ink-soft">Discover pieces made to be lived in and loved.</p>
          <Button className="mt-8" onClick={() => go('/shop')}>
            Start shopping
          </Button>
        </div>
      ) : (
        <ul className="divide-y divide-line px-5 md:px-6">
          {lines.map((l) => (
            <CartLineItem key={l.key} line={l} onNavigate={close} />
          ))}
        </ul>
      )}
    </Overlay>
  )
}
