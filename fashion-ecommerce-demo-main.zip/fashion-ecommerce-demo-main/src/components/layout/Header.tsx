import { AnimatePresence, motion } from 'motion/react'
import { Heart, Menu, PackageSearch, Search, ShoppingBag } from 'lucide-react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { ANNOUNCEMENT } from '../../config'
import { useScrolled } from '../../hooks/useMisc'
import { cn } from '../../lib/utils'
import { useCart, useCartLines } from '../../store/cart'
import { useUI, useWishlist } from '../../store/ui'
import { Wordmark } from '../ui/primitives'
import { MobileNav } from './MobileNav'

export const NAV_LINKS = [
  { label: 'Home', to: '/' },
  { label: 'New Arrivals', to: '/shop?new=1&sort=newest' },
  { label: 'Sarees', to: '/shop?category=sarees' },
  { label: 'Kurtis', to: '/shop?category=kurtis' },
  { label: 'Dresses', to: '/shop?category=dresses' },
  { label: 'Collections', to: '/collections' },
]

export function AnnouncementBar() {
  return (
    <div className="bg-charcoal text-center text-[12px] tracking-[0.08em] text-white/90">
      <p className="mx-auto max-w-full px-4 py-2.5">
        {ANNOUNCEMENT.split('|').map((part, i) => (
          <span key={i} className={i > 0 ? 'hidden sm:inline' : ''}>
            {i > 0 && <span className="mx-3 opacity-50">|</span>}
            {part.trim()}
          </span>
        ))}
      </p>
    </div>
  )
}

function CartButton() {
  const { count } = useCartLines()
  const pulse = useCart((s) => s.pulse)
  const open = useCart((s) => s.openDrawer)
  return (
    <button onClick={open} aria-label={`Open bag, ${count} item${count === 1 ? '' : 's'}`} className="relative grid size-11 place-items-center rounded-full transition-colors hover:bg-sand">
      <motion.span key={pulse} initial={pulse ? { scale: 0.85 } : false} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500, damping: 14 }} className="grid place-items-center">
        <ShoppingBag size={21} strokeWidth={1.6} />
      </motion.span>
      <AnimatePresence>
        {count > 0 && (
          <motion.span
            key={count}
            initial={{ scale: 0.4, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.4, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 520, damping: 18 }}
            className="absolute right-0.5 top-0.5 grid min-w-[18px] place-items-center rounded-full bg-rose px-1 text-[10px] font-semibold leading-[18px] text-white"
          >
            {count}
          </motion.span>
        )}
      </AnimatePresence>
    </button>
  )
}

export function Header() {
  const scrolled = useScrolled()
  const setSearch = useUI((s) => s.setSearchOpen)
  const setNav = useUI((s) => s.setNavOpen)
  const wishCount = useWishlist((s) => s.ids.length)
  const { pathname, search } = useLocation()

  const isActive = (to: string) => {
    const [path, qs] = to.split('?')
    if (path !== pathname) return false
    if (!qs) return !search || path !== '/shop'
    const want = new URLSearchParams(qs)
    const have = new URLSearchParams(search)
    for (const [k, v] of want) if (k !== 'sort' && have.get(k) !== v) return false
    return true
  }

  return (
    <>
      <AnnouncementBar />
      <header
        className={cn(
          'sticky top-0 z-50 border-b transition-[background-color,border-color,box-shadow,backdrop-filter] duration-300',
          scrolled ? 'border-line bg-ivory/90 shadow-[0_6px_24px_-16px_rgba(37,33,31,.25)] backdrop-blur-md' : 'border-transparent bg-ivory',
        )}
      >
        <div className="container-x grid h-14 grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] items-center gap-2 md:h-16">
          {/* left: hamburger (mobile) / nav (desktop) */}
          <div className="flex items-center">
            <button onClick={() => setNav(true)} aria-label="Open menu" className="-ml-2 grid size-11 place-items-center rounded-full hover:bg-sand lg:hidden">
              <Menu size={22} strokeWidth={1.6} />
            </button>
          </div>

          <Link to="/" aria-label="Srivel Fashion House — home" className="justify-self-center">
            <Wordmark className="max-w-[150px] text-[1rem] sm:max-w-none sm:text-[1.3rem] lg:text-[1.5rem]" />
          </Link>

          <div className="flex items-center justify-end gap-0.5 [&>button]:shrink-0 [&>a]:shrink-0">
            <button onClick={() => setSearch(true)} aria-label="Search" className="grid size-11 place-items-center rounded-full hover:bg-sand">
              <Search size={21} strokeWidth={1.6} />
            </button>
            <NavLink to="/track-order" aria-label="Track order" title="Track order" className="hidden size-11 place-items-center rounded-full hover:bg-sand sm:grid">
              <PackageSearch size={21} strokeWidth={1.6} />
            </NavLink>
            <NavLink to="/wishlist" aria-label={`Wishlist, ${wishCount} saved`} className="relative hidden size-11 place-items-center rounded-full hover:bg-sand sm:grid">
              <Heart size={21} strokeWidth={1.6} />
              {wishCount > 0 && <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-rose" />}
            </NavLink>
            <CartButton />
          </div>
        </div>
        <nav aria-label="Primary" className="container-x hidden justify-center gap-8 border-t border-line/60 py-1 lg:flex xl:gap-12">
          {NAV_LINKS.map((l) => (
            <HeaderLink key={l.label} {...l} active={isActive(l.to)} />
          ))}
        </nav>
      </header>
      <MobileNav />
    </>
  )
}

function HeaderLink({ label, to, active }: { label: string; to: string; active: boolean }) {
  return (
    <Link
      to={to}
      aria-current={active ? 'page' : undefined}
      className="group relative whitespace-nowrap py-2 text-[13px] font-medium uppercase tracking-[0.14em] text-charcoal/90 transition-colors hover:text-rose"
    >
      {label}
      <span
        className={cn(
          'absolute inset-x-0 -bottom-0.5 h-px origin-left bg-rose transition-transform duration-300',
          active ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100',
        )}
      />
    </Link>
  )
}
