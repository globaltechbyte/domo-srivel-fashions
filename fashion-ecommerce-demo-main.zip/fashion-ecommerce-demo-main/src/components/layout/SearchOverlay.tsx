import { AnimatePresence, motion } from 'motion/react'
import { Search, X } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { categoryLabel } from '../../data/products'
import { recolor } from '../../lib/art'
import { formatPrice } from '../../lib/utils'
import { useCatalog } from '../../store/catalog'
import { useUI } from '../../store/ui'
import { FashionImage } from '../ui/FashionImage'

export function SearchOverlay() {
  const open = useUI((s) => s.searchOpen)
  const setOpen = useUI((s) => s.setSearchOpen)
  const products = useCatalog((s) => s.products)
  const [q, setQ] = useState('')
  const input = useRef<HTMLInputElement>(null)
  const navigate = useNavigate()

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => input.current?.focus(), 80)
      document.documentElement.style.overflow = 'hidden'
      const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
      document.addEventListener('keydown', onKey)
      return () => {
        clearTimeout(t)
        document.documentElement.style.overflow = ''
        document.removeEventListener('keydown', onKey)
      }
    }
    setQ('')
  }, [open, setOpen])

  const results = useMemo(() => {
    const term = q.trim().toLowerCase()
    if (!term) return []
    return products
      .filter((p) => p.name.toLowerCase().includes(term) || categoryLabel(p.category).toLowerCase().includes(term))
      .slice(0, 6)
  }, [q, products])

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const term = q.trim()
    setOpen(false)
    navigate(term ? `/shop?q=${encodeURIComponent(term)}` : '/shop')
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[90] flex flex-col bg-ivory"
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.25 }}
          role="dialog"
          aria-modal="true"
          aria-label="Search"
        >
          <div className="container-x flex items-center gap-3 border-b border-line py-4">
            <form onSubmit={submit} className="flex flex-1 items-center gap-3" role="search">
              <Search size={22} className="shrink-0 text-ink-soft" />
              <input
                ref={input}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search sarees, kurtis, dresses…"
                aria-label="Search products"
                className="h-12 w-full bg-transparent font-serif text-2xl outline-none placeholder:text-ink-soft/60 md:text-3xl"
              />
            </form>
            <button onClick={() => setOpen(false)} aria-label="Close search" className="grid size-12 place-items-center rounded-full hover:bg-sand">
              <X size={22} />
            </button>
          </div>
          <div className="container-x flex-1 overflow-y-auto py-8">
            {q.trim() === '' ? (
              <div>
                <p className="eyebrow mb-4">Popular searches</p>
                <div className="flex flex-wrap gap-2">
                  {['Silk saree', 'Kurti', 'Lehenga', 'Co-ord set', 'Wrap dress'].map((t) => (
                    <button key={t} onClick={() => setQ(t)} className="min-h-11 border border-line bg-white px-4 text-sm transition-colors hover:border-charcoal">
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            ) : results.length === 0 ? (
              <p className="text-ink-soft">No pieces match “{q}”. Try a different word, like “saree” or “dress”.</p>
            ) : (
              <>
                <ul className="grid gap-1 md:grid-cols-2">
                  {results.map((p) => (
                    <li key={p.id}>
                      <Link
                        to={`/product/${p.slug}`}
                        onClick={() => setOpen(false)}
                        className="flex items-center gap-4 p-2 transition-colors hover:bg-sand"
                      >
                        <div className="w-16 shrink-0 overflow-hidden bg-sand">
                          <div className="aspect-[3/4]">
                            <FashionImage src={recolor(p.images[0], p.colors[0].hex)} alt="" category={p.category} />
                          </div>
                        </div>
                        <div>
                          <p className="text-[15px]">{p.name}</p>
                          <p className="text-sm text-ink-soft">
                            {categoryLabel(p.category)} · {formatPrice(p.price)}
                          </p>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
                <button onClick={submit} className="mt-6 text-sm underline underline-offset-4 hover:text-rose">
                  See all results for “{q}”
                </button>
              </>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
