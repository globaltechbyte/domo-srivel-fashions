import { Link } from 'react-router-dom'
import { BRAND, WHATSAPP_IS_PLACEHOLDER, WHATSAPP_NUMBER } from '../../config'
import { FacebookIcon, InstagramIcon, PinterestIcon, WhatsAppIcon, YoutubeIcon } from '../ui/BrandIcons'
import { Wordmark } from '../ui/primitives'

const col = 'space-y-1'
const link = 'inline-flex min-h-9 items-center text-[15px] text-white/70 transition-colors hover:text-white'

export function Footer() {
  return (
    <footer className="mt-24 bg-charcoal text-white md:mt-32">
      <div className="container-x grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div className="max-w-sm">
          <Wordmark light />
          <p className="mt-5 text-[15px] leading-relaxed text-white/70">
            A modern boutique of sarees, kurtis, ethnic sets and occasion wear, designed for the way you live and celebrate.
          </p>
          <div className="mt-6 flex gap-1">
            {[
              { l: 'Instagram', i: <InstagramIcon /> },
              { l: 'Facebook', i: <FacebookIcon /> },
              { l: 'Pinterest', i: <PinterestIcon /> },
              { l: 'YouTube', i: <YoutubeIcon /> },
            ].map((s) => (
              <a key={s.l} href="#social" onClick={(e) => e.preventDefault()} aria-label={`${s.l} (placeholder link)`} className="grid size-11 place-items-center rounded-full text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                {s.i}
              </a>
            ))}
          </div>
        </div>

        <nav aria-label="Shop" className={col}>
          <p className="eyebrow mb-3 !text-white/50">Shop</p>
          <ul>
            {[
              ['New Arrivals', '/shop?new=1&sort=newest'],
              ['Sarees', '/shop?category=sarees'],
              ['Kurtis', '/shop?category=kurtis'],
              ['Ethnic Sets', '/shop?category=ethnic-sets'],
              ['Western Wear', '/shop?category=western-wear'],
              ['Dresses', '/shop?category=dresses'],
              ['Occasion Wear', '/shop?category=occasion-wear'],
            ].map(([t, to]) => (
              <li key={t}><Link to={to} className={link}>{t}</Link></li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Information" className={col}>
          <p className="eyebrow mb-3 !text-white/50">Information</p>
          <ul>
            {[
              ['Track order', '/track-order'],
              ['About', '/pages/about'],
              ['Contact', '/pages/contact'],
              ['Shipping policy', '/pages/shipping'],
              ['Return policy', '/pages/returns'],
              ['Privacy policy', '/pages/privacy'],
              ['Admin demo', '/admin-demo'],
            ].map(([t, to]) => (
              <li key={t}><Link to={to} className={link}>{t}</Link></li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="eyebrow mb-3 !text-white/50">Contact</p>
          <ul className="space-y-2 text-[15px] text-white/70">
            <li>{BRAND.email}</li>
            <li>{BRAND.city}</li>
            <li className="flex items-center gap-2">
              <WhatsAppIcon />
              <span>{WHATSAPP_IS_PLACEHOLDER ? 'WhatsApp: add your number' : `+${WHATSAPP_NUMBER}`}</span>
            </li>
          </ul>
          <p className="mt-4 text-[13px] leading-relaxed text-white/50">Contact details are editable placeholders (see src/config.ts).</p>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-x flex flex-col gap-2 py-6 text-[13px] text-white/50 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} {BRAND.name}. Demo storefront — no real orders or payments are processed.</p>
          <p>Cash on Delivery & WhatsApp ordering</p>
        </div>
      </div>
    </footer>
  )
}
