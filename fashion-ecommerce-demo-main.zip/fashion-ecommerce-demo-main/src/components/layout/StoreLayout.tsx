import { motion } from 'motion/react'
import { useEffect } from 'react'
import { useLocation, useOutlet } from 'react-router-dom'
import { QuickView } from '../product/QuickView'
import { Toaster } from '../ui/Toaster'
import { CartDrawer } from './CartDrawer'
import { Footer } from './Footer'
import { Header } from './Header'
import { Loader } from './Loader'
import { SearchOverlay } from './SearchOverlay'
import { useCart } from '../../store/cart'
import { useUI } from '../../store/ui'

export function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' })
  }, [pathname])
  return null
}

/** Closes transient layers when the route changes. */
function useCloseOnNavigate() {
  const { pathname } = useLocation()
  const closeCart = useCart((s) => s.closeDrawer)
  const setNav = useUI((s) => s.setNavOpen)
  const setSearch = useUI((s) => s.setSearchOpen)
  const setQuick = useUI((s) => s.setQuickView)
  useEffect(() => {
    closeCart()
    setNav(false)
    setSearch(false)
    setQuick(null)
  }, [pathname, closeCart, setNav, setSearch, setQuick])
}

export function StoreLayout() {
  const location = useLocation()
  const outlet = useOutlet()
  useCloseOnNavigate()

  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#main" className="sr-only z-[300] bg-white px-4 py-3 focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
        Skip to content
      </a>
      <Loader />
      <Header />
      <motion.main
        id="main"
        key={location.pathname}
        className="flex-1"
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
      >
        {outlet}
      </motion.main>
      <Footer />
      <CartDrawer />
      <SearchOverlay />
      <QuickView />
      <Toaster />
    </div>
  )
}
