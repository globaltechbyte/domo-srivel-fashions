import { motion } from 'motion/react'
import { ArrowUpRight, Heart, LayoutDashboard, PackageSearch } from 'lucide-react'
import { Link } from 'react-router-dom'
import { CATEGORIES } from '../../data/products'
import { useUI } from '../../store/ui'
import { Overlay } from '../ui/Overlay'
import { WhatsAppIcon } from '../ui/BrandIcons'
import { WHATSAPP_IS_PLACEHOLDER } from '../../config'

const MAIN = [
  { label: 'Home', to: '/' },
  { label: 'New Arrivals', to: '/shop?new=1&sort=newest' },
  { label: 'Collections', to: '/collections' },
  { label: 'Shop All', to: '/shop' },
]

export function MobileNav() {
  const open = useUI((s) => s.navOpen)
  const setOpen = useUI((s) => s.setNavOpen)
  const close = () => setOpen(false)

  return (
    <Overlay open={open} onClose={close} mode="drawer-left" title="Menu" widthClass="max-w-[360px]">
      <nav aria-label="Mobile" className="flex flex-col px-6 py-6">
        <ul className="space-y-1">
          {MAIN.map((l, i) => (
            <motion.li key={l.label} initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.08 + i * 0.05, duration: 0.3 }}>
              <Link to={l.to} onClick={close} className="flex min-h-12 items-center font-serif text-3xl">
                {l.label}
              </Link>
            </motion.li>
          ))}
        </ul>
        <p className="eyebrow mb-3 mt-8">Shop by category</p>
        <ul className="grid grid-cols-2 gap-x-4">
          {CATEGORIES.map((c, i) => (
            <motion.li key={c.slug} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25 + i * 0.04 }}>
              <Link to={`/shop?category=${c.slug}`} onClick={close} className="flex min-h-11 items-center text-[15px] text-ink-soft hover:text-rose">
                {c.label}
              </Link>
            </motion.li>
          ))}
        </ul>
        <div className="mt-8 space-y-1 border-t border-line pt-6 text-[15px]">
          <Link to="/track-order" onClick={close} className="flex min-h-11 items-center gap-3 hover:text-rose">
            <PackageSearch size={18} /> Track order
          </Link>
          <Link to="/wishlist" onClick={close} className="flex min-h-11 items-center gap-3 hover:text-rose">
            <Heart size={18} /> Wishlist
          </Link>
          <Link to="/pages/contact" onClick={close} className="flex min-h-11 items-center gap-3 hover:text-rose">
            <WhatsAppIcon /> {WHATSAPP_IS_PLACEHOLDER ? 'Contact us' : 'Chat on WhatsApp'}
          </Link>
          <Link to="/admin-demo" onClick={close} className="flex min-h-11 items-center gap-3 text-ink-soft hover:text-rose">
            <LayoutDashboard size={18} /> Admin demo <ArrowUpRight size={14} />
          </Link>
        </div>
      </nav>
    </Overlay>
  )
}
