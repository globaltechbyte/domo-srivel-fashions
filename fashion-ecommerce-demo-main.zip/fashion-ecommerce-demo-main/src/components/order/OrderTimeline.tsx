import { motion } from 'motion/react'
import { Ban, Check } from 'lucide-react'
import { STATUS_COPY, type TimelineStep } from '../../lib/tracking'
import { cn, formatDate } from '../../lib/utils'

const EASE = [0.22, 1, 0.36, 1] as const

const stateLabel = { done: 'Completed', current: 'Current step', upcoming: 'Upcoming', cancelled: 'Cancelled' } as const

/** Animated vertical tracking timeline. Pure presentation: pass steps from buildTimeline(). */
export function OrderTimeline({ steps }: { steps: TimelineStep[] }) {
  return (
    <ol className="relative" aria-label="Order progress">
      {steps.map((step, i) => {
        const last = i === steps.length - 1
        const copy = STATUS_COPY[step.status]
        const active = step.state === 'current'
        const reached = step.state !== 'upcoming'
        const cancelled = step.state === 'cancelled'
        // The connector below a node is "filled" only if the next step has been reached.
        const next = steps[i + 1]
        const filled = !!next && next.state !== 'upcoming'

        return (
          <motion.li
            key={step.status}
            className="relative flex gap-4 pb-9 last:pb-0 md:gap-5"
            aria-current={active ? 'step' : undefined}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.45, delay: 0.12 + i * 0.09, ease: EASE }}
          >
            <div className="relative flex w-10 shrink-0 flex-col items-center">
              <span className="relative z-10 grid size-10 place-items-center">
                {active && <span className="absolute inset-0 rounded-full bg-rose/25 motion-safe:animate-ping" aria-hidden="true" />}
                <motion.span
                  initial={{ scale: 0.6 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 380, damping: 18, delay: 0.2 + i * 0.09 }}
                  className={cn(
                    'relative grid size-9 place-items-center rounded-full border-2 transition-colors',
                    cancelled && 'border-bad bg-bad text-white',
                    step.state === 'done' && 'border-rose bg-rose text-white',
                    active && 'border-rose bg-white text-rose',
                    step.state === 'upcoming' && 'border-line bg-ivory text-ink-soft/60',
                  )}
                >
                  {cancelled ? <Ban size={16} /> : step.state === 'done' ? <Check size={17} strokeWidth={2.5} /> : <span className="text-sm font-medium">{i + 1}</span>}
                </motion.span>
              </span>
              {!last && (
                <span className="absolute left-1/2 top-10 -ml-px h-[calc(100%-2.5rem+2.25rem)] w-0.5 bg-line" aria-hidden="true">
                  <motion.span
                    className="block h-full w-full origin-top bg-rose"
                    initial={{ scaleY: 0 }}
                    animate={{ scaleY: filled ? 1 : 0 }}
                    transition={{ duration: 0.55, delay: 0.35 + i * 0.12, ease: EASE }}
                  />
                </span>
              )}
            </div>

            <div className={cn('min-w-0 flex-1 pt-1.5', !reached && 'opacity-60')}>
              <div className="flex flex-wrap items-baseline justify-between gap-x-4">
                <h3 className={cn('font-sans text-base font-medium tracking-normal', cancelled && 'text-bad')}>
                  {copy.title}
                  <span className="sr-only"> — {stateLabel[step.state]}</span>
                </h3>
                {step.at && <time dateTime={step.at} className="text-[13px] text-ink-soft tabular-nums">{formatDate(step.at)}</time>}
              </div>
              {reached ? (
                <p className="mt-1 text-sm leading-relaxed text-ink-soft">{copy.body}</p>
              ) : (
                <p className="mt-1 text-sm text-ink-soft">Not reached yet</p>
              )}
              {active && <span className="mt-2 inline-block bg-rose-mist px-2 py-0.5 text-[11px] font-medium uppercase tracking-[0.12em] text-rose">Current status</span>}
            </div>
          </motion.li>
        )
      })}
    </ol>
  )
}
