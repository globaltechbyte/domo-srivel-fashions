import { AnimatePresence, motion } from 'motion/react'
import { X } from 'lucide-react'
import { useEffect, useId, useRef, type ReactNode } from 'react'
import { cn } from '../../lib/utils'

let lockCount = 0
function lockScroll() {
  if (lockCount++ === 0) document.documentElement.style.overflow = 'hidden'
}
function unlockScroll() {
  if (--lockCount <= 0) {
    lockCount = 0
    document.documentElement.style.overflow = ''
  }
}

interface OverlayProps {
  open: boolean
  onClose: () => void
  title: string
  /** `dialog`: centred on desktop, bottom sheet on mobile. `drawer`: right-hand panel. `drawer-left`: left-hand panel. */
  mode?: 'dialog' | 'drawer' | 'drawer-left'
  /** Visually hide the heading (still announced to screen readers). */
  hideTitle?: boolean
  widthClass?: string
  children: ReactNode
  footer?: ReactNode
  className?: string
}

export function Overlay({
  open,
  onClose,
  title,
  mode = 'dialog',
  hideTitle,
  widthClass = 'max-w-lg',
  children,
  footer,
  className,
}: OverlayProps) {
  const titleId = useId()
  const panelRef = useRef<HTMLDivElement>(null)
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) return
    lockScroll()
    const previouslyFocused = document.activeElement as HTMLElement | null
    const t = setTimeout(() => closeRef.current?.focus(), 60)
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onClose()
      }
      if (e.key === 'Tab' && panelRef.current) {
        const f = panelRef.current.querySelectorAll<HTMLElement>(
          'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',
        )
        if (!f.length) return
        const first = f[0]
        const last = f[f.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      clearTimeout(t)
      document.removeEventListener('keydown', onKey)
      unlockScroll()
      previouslyFocused?.focus?.()
    }
  }, [open, onClose])

  const isDrawer = mode !== 'dialog'
  const fromLeft = mode === 'drawer-left'

  const panelMotion = isDrawer
    ? { initial: { x: fromLeft ? '-100%' : '100%' }, animate: { x: 0 }, exit: { x: fromLeft ? '-100%' : '100%' } }
    : { initial: { y: 36, opacity: 0 }, animate: { y: 0, opacity: 1 }, exit: { y: 24, opacity: 0 } }

  return (
    <AnimatePresence>
      {open && (
        <div
          className={cn(
            'fixed inset-0 z-[80] flex',
            isDrawer ? (fromLeft ? 'justify-start' : 'justify-end') : 'items-end justify-center md:items-center md:p-6',
          )}
        >
          <motion.div
            className="absolute inset-0 bg-charcoal/45 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            onClick={onClose}
            aria-hidden="true"
          />
          <motion.div
            ref={panelRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            {...panelMotion}
            transition={{ type: 'spring', stiffness: 380, damping: 40, mass: 0.9 }}
            className={cn(
              'relative flex flex-col bg-ivory shadow-2xl',
              isDrawer
                ? cn('h-full w-full', widthClass)
                : cn('max-h-[92dvh] w-full rounded-t-2xl md:max-h-[88dvh] md:rounded-md', widthClass),
              className,
            )}
          >
            <header className={cn('flex items-center justify-between gap-4 px-5 py-4 md:px-6', hideTitle ? 'absolute right-0 top-0 z-10' : 'border-b border-line')}>
              <h2 id={titleId} className={cn('font-serif text-2xl', hideTitle && 'sr-only')}>
                {title}
              </h2>
              <button
                ref={closeRef}
                onClick={onClose}
                aria-label={`Close ${title}`}
                className="grid size-11 place-items-center rounded-full bg-ivory/80 text-charcoal transition-colors hover:bg-sand"
              >
                <X size={20} />
              </button>
            </header>
            <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">{children}</div>
            {footer && <div className="border-t border-line bg-ivory px-5 py-4 pb-[max(1rem,env(safe-area-inset-bottom))] md:px-6">{footer}</div>}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}
