import { AnimatePresence, motion } from 'motion/react'
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useUI } from '../../store/ui'

const icons = {
  success: <CheckCircle2 size={18} className="text-emerald-300" />,
  info: <Info size={18} className="text-sky-300" />,
  error: <AlertCircle size={18} className="text-rose-300" />,
}

export function Toaster() {
  const toasts = useUI((s) => s.toasts)
  const dismiss = useUI((s) => s.dismissToast)

  return (
    <div
      aria-live="polite"
      className="pointer-events-none fixed inset-x-0 bottom-0 z-[120] flex flex-col items-center gap-2 px-4 pb-24 lg:pb-8"
    >
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: 16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, transition: { duration: 0.15 } }}
            transition={{ duration: 0.22 }}
            className="pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-md bg-charcoal px-4 py-3 text-sm text-white shadow-xl"
            role="status"
          >
            {icons[t.tone]}
            <span className="flex-1">{t.message}</span>
            {t.action &&
              (t.action.to ? (
                <Link to={t.action.to} onClick={() => dismiss(t.id)} className="font-medium underline underline-offset-4">
                  {t.action.label}
                </Link>
              ) : (
                <button
                  onClick={() => {
                    t.action?.onClick?.()
                    dismiss(t.id)
                  }}
                  className="font-medium underline underline-offset-4"
                >
                  {t.action.label}
                </button>
              ))}
            <button onClick={() => dismiss(t.id)} aria-label="Dismiss notification" className="grid size-8 place-items-center rounded-full hover:bg-white/10">
              <X size={14} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
