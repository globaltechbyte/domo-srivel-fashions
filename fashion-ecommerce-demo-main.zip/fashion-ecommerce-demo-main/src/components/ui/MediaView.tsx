import { useState } from 'react'
import { useInView, useMediaSrc } from '../../hooks/useMedia'
import { cn } from '../../lib/utils'
import { parseArt } from '../../lib/art'
import type { MediaRef } from '../../types'
import { ProductArt } from './ProductArt'

interface Props {
  media?: MediaRef
  /** Still image shown for video media (poster frame / thumbnail). */
  poster?: MediaRef
  alt: string
  /** Illustration used when there is no media or it can't be loaded. */
  fallbackArt: string
  className?: string
  /** `natural` keeps the image's own aspect ratio (masonry); `cover` fills the parent. */
  fit?: 'cover' | 'natural'
  /** Play the video inline with native controls (lightbox). Otherwise videos render as a still preview. */
  controls?: boolean
  eager?: boolean
}

/**
 * One component for every gallery image/video: generated art, external URLs and IndexedDB uploads.
 * Content only loads once it is near the viewport, shows a skeleton until ready, and falls back
 * to an illustration if a file is missing (e.g. browser storage was cleared).
 */
export function MediaView({ media, poster, alt, fallbackArt, className, fit = 'cover', controls, eager }: Props) {
  const [ref, inView] = useInView<HTMLDivElement>()
  const active = eager || inView
  const showVideo = media?.kind === 'video'
  const still = showVideo ? poster : media
  const stillSrc = useMediaSrc(still, active)
  const videoSrc = useMediaSrc(showVideo ? media : undefined, active && (!!controls || !poster))
  const [loaded, setLoaded] = useState<string | null>(null)

  const art = still?.source === 'art' ? parseArt(still.value) : null
  const fallback = parseArt(fallbackArt)
  const natural = fit === 'natural' && still?.width && still?.height
  const wrapStyle = natural ? { aspectRatio: `${still!.width} / ${still!.height}` } : undefined
  const isLoaded = loaded === (stillSrc.src ?? videoSrc.src)

  let content: React.ReactNode = null
  if (active) {
    if (art) {
      content = <ProductArt spec={art} label={alt} />
    } else if (controls && showVideo && videoSrc.src) {
      content = (
        <video src={videoSrc.src} poster={stillSrc.src ?? undefined} controls autoPlay playsInline preload="metadata" className="h-full w-full bg-black object-contain" aria-label={alt} />
      )
    } else if (stillSrc.src) {
      content = (
        <img
          src={stillSrc.src}
          alt={alt}
          loading={eager ? 'eager' : 'lazy'}
          decoding="async"
          onLoad={() => setLoaded(stillSrc.src)}
          className={cn('h-full w-full object-cover transition-opacity duration-500', isLoaded ? 'opacity-100' : 'opacity-0')}
        />
      )
    } else if (showVideo && videoSrc.src) {
      // No poster: let the browser paint the first frame (#t makes iOS show one).
      content = (
        <video
          src={`${videoSrc.src}#t=0.1`}
          preload="metadata"
          muted
          playsInline
          tabIndex={-1}
          aria-label={alt}
          onLoadedData={() => setLoaded(videoSrc.src)}
          className={cn('h-full w-full object-cover transition-opacity duration-500', isLoaded ? 'opacity-100' : 'opacity-0')}
        />
      )
    } else if ((stillSrc.status === 'missing' || videoSrc.status === 'missing' || !media) && fallback) {
      content = <ProductArt spec={fallback} label={alt} />
    }
  }

  const inlineVideo = !!controls && showVideo && !!videoSrc.src
  const ready = !!art || !!(content && (inlineVideo || isLoaded || (!stillSrc.src && !videoSrc.src)))

  return (
    <div ref={ref} style={wrapStyle} className={cn('relative overflow-hidden bg-sand', natural ? 'w-full' : 'h-full w-full', className)}>
      {!ready && <div className="skeleton absolute inset-0" aria-hidden="true" />}
      {content}
    </div>
  )
}
