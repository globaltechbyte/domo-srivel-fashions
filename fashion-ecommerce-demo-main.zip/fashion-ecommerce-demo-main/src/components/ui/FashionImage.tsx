import { useMemo, useState } from 'react'
import { useMediaSrc } from '../../hooks/useMedia'
import { fallbackArt, parseArt } from '../../lib/art'
import type { CategorySlug } from '../../types'
import { ProductArt } from './ProductArt'

interface Props {
  src: string
  alt: string
  category: CategorySlug
  className?: string
  eager?: boolean
}

/**
 * Renders either a generated `art:` illustration or a real photo URL.
 * If a real photo fails to load, it silently falls back to an on-brand illustration.
 */
export function FashionImage({ src, alt, category, className = '', eager }: Props) {
  const [failed, setFailed] = useState<string | null>(null)
  const media = useMemo(() => src.startsWith('upload:') ? { source: 'upload' as const, kind: 'image' as const, value: src.slice(7) } : undefined, [src])
  const resolved = useMediaSrc(media)
  const art = parseArt(src) ?? (failed === src || resolved.status === 'missing' ? parseArt(fallbackArt(category, src)) : null)

  if (art) return <ProductArt spec={art} label={alt} className={className} />
  if (media && !resolved.src) return <div className={`skeleton h-full w-full ${className}`} aria-label={`Loading ${alt || 'product image'}`} />

  return (
    <img
      src={media ? resolved.src! : src}
      alt={alt}
      loading={eager ? 'eager' : 'lazy'}
      decoding="async"
      onError={() => setFailed(src)}
      className={`block h-full w-full object-cover ${className}`}
    />
  )
}
