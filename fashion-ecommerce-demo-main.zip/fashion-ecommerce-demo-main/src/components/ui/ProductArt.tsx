import { useId } from 'react'
import { darken, lighten, luminance, mix, type ArtPattern, type ArtSpec } from '../../lib/art'
import type { CategorySlug } from '../../types'

/* Stylised garment silhouettes drawn in a 600×800 box, centred on x=300. */

const SHAPES: Record<CategorySlug, string> = {
  // kurti — A-line tunic, 3/4 sleeves, V-neck
  kurtis:
    'M240 160 L270 148 Q300 218 330 148 L360 160 L432 218 L406 336 L373 310 L380 650 L220 650 L227 310 L194 336 L168 218 Z',
  // dress — fit & flare
  dresses:
    'M262 150 Q300 205 338 150 L372 166 L360 276 Q356 296 372 306 C440 470 488 600 506 702 L94 702 C112 600 160 470 228 306 Q244 296 240 276 L228 166 Z',
  // gown — long, full sweep
  'occasion-wear':
    'M232 330 L368 330 C440 450 520 620 556 722 L44 722 C80 620 160 450 232 330 Z',
  // western co-ord: wide-leg trousers
  'western-wear':
    'M236 330 L364 330 L436 722 L316 722 L300 470 L284 722 L164 722 Z',
  // ethnic set: long kurta
  'ethnic-sets':
    'M240 160 L270 148 Q300 212 330 148 L360 160 L424 214 L402 322 L372 300 L384 600 L216 600 L228 300 L198 322 L176 214 Z',
  // saree skirt (pleated drape)
  sarees:
    'M222 372 Q300 392 378 372 L424 722 L176 722 Z',
}

const GOLD = '#C9A45C'

function patternDef(id: string, kind: ArtPattern, base: string, scale = 1) {
  const dark = darken(base, 0.28)
  const light = lighten(base, 0.45)
  const size = 28 * scale
  switch (kind) {
    case 'stripe':
      return (
        <pattern id={id} width={14 * scale} height="10" patternUnits="userSpaceOnUse">
          <rect width={2 * scale} height="10" fill={light} opacity=".45" />
        </pattern>
      )
    case 'dots':
      return (
        <pattern id={id} width={size} height={size} patternUnits="userSpaceOnUse">
          <circle cx={size / 2} cy={size / 2} r={2.6 * scale} fill={light} opacity=".6" />
        </pattern>
      )
    case 'floral':
      return (
        <pattern id={id} width={size * 1.6} height={size * 1.6} patternUnits="userSpaceOnUse">
          <g transform={`translate(${size * 0.8} ${size * 0.8}) scale(${scale})`} fill={light} opacity=".55">
            <circle cx="0" cy="-6" r="4" />
            <circle cx="0" cy="6" r="4" />
            <circle cx="-6" cy="0" r="4" />
            <circle cx="6" cy="0" r="4" />
            <circle cx="0" cy="0" r="2.4" fill={dark} opacity=".7" />
          </g>
        </pattern>
      )
    case 'butti':
      return (
        <pattern id={id} width={size * 1.5} height={size * 1.5} patternUnits="userSpaceOnUse">
          <g transform={`translate(${size * 0.75} ${size * 0.75}) scale(${scale})`} fill={GOLD} opacity=".85">
            <path d="M0 -7 L5 0 L0 7 L-5 0 Z" />
            <circle cx="0" cy="0" r="1.6" fill={darken(base, 0.4)} />
          </g>
        </pattern>
      )
    default:
      return (
        <pattern id={id} width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="6" height="3" fill={light} opacity=".14" />
        </pattern>
      )
  }
}

interface GarmentProps {
  spec: ArtSpec
  uid: string
}

function Defs({ spec, uid }: GarmentProps) {
  const c = spec.hex
  return (
    <defs>
      {patternDef(`${uid}-pat`, spec.pattern, c, spec.view === 'detail' ? 2.6 : 1)}
      <linearGradient id={`${uid}-shade`} x1="0" x2="1" y1="0" y2="0">
        <stop offset="0" stopColor="#000" stopOpacity=".22" />
        <stop offset=".28" stopColor="#fff" stopOpacity=".1" />
        <stop offset=".55" stopColor="#000" stopOpacity="0" />
        <stop offset="1" stopColor="#000" stopOpacity=".26" />
      </linearGradient>
      <linearGradient id={`${uid}-drop`} x1="0" x2="0" y1="0" y2="1">
        <stop offset="0" stopColor="#fff" stopOpacity=".18" />
        <stop offset="1" stopColor="#000" stopOpacity=".18" />
      </linearGradient>
    </defs>
  )
}

/** A filled shape with pattern + soft shading layers. */
function Cloth({ d, fill, uid, patterned = true }: { d: string; fill: string; uid: string; patterned?: boolean }) {
  return (
    <>
      <path d={d} fill={fill} />
      {patterned && <path d={d} fill={`url(#${uid}-pat)`} />}
      <path d={d} fill={`url(#${uid}-shade)`} />
      <path d={d} fill={`url(#${uid}-drop)`} />
    </>
  )
}

function Garment({ spec, uid }: GarmentProps) {
  const c = spec.hex
  const dark = darken(c, 0.35)
  const clip = `${uid}-clip`
  const stroke = darken(c, 0.5)

  switch (spec.category) {
    case 'kurtis':
      return (
        <g>
          <Cloth d={SHAPES.kurtis} fill={c} uid={uid} />
          <clipPath id={clip}><path d={SHAPES.kurtis} /></clipPath>
          <g clipPath={`url(#${clip})`}>
            <rect x="150" y="618" width="300" height="34" fill={GOLD} opacity=".9" />
            <rect x="150" y="626" width="300" height="3" fill={darken(c, .4)} opacity=".5" />
          </g>
          <path d="M270 148 Q300 218 330 148" fill="none" stroke={GOLD} strokeWidth="3" strokeDasharray="1 5" strokeLinecap="round" />
          <path d="M300 216 L300 420" stroke={stroke} strokeOpacity=".4" strokeWidth="2" />
          {[250, 290, 330, 370].map((y) => <circle key={y} cx="300" cy={y} r="3.4" fill={GOLD} />)}
          <path d="M220 650 L227 560 M380 650 L373 560" stroke={stroke} strokeOpacity=".35" strokeWidth="2" />
        </g>
      )
    case 'dresses':
      return (
        <g>
          <Cloth d={SHAPES.dresses} fill={c} uid={uid} />
          <clipPath id={clip}><path d={SHAPES.dresses} /></clipPath>
          <g clipPath={`url(#${clip})`}>
            <rect x="200" y="290" width="200" height="22" fill={dark} opacity=".85" />
          </g>
          <path d="M262 150 Q300 205 338 150" fill="none" stroke={GOLD} strokeWidth="3" strokeLinecap="round" />
          {[-3, -2, -1, 0, 1, 2, 3].map((i) => (
            <path key={i} d={`M${300 + i * 14} 312 Q${300 + i * 34} 520 ${300 + i * 66} 702`} fill="none" stroke={stroke} strokeOpacity=".18" strokeWidth="2" />
          ))}
        </g>
      )
    case 'occasion-wear': {
      // lehenga: choli + heavy-border skirt + sheer dupatta
      const choli =
        'M255 150 Q300 180 345 150 L402 192 L388 258 L364 248 L368 338 L232 338 L236 248 L212 258 L198 192 Z'
      return (
        <g>
          <Cloth d={SHAPES['occasion-wear']} fill={c} uid={uid} />
          <clipPath id={clip}><path d={SHAPES['occasion-wear']} /></clipPath>
          <g clipPath={`url(#${clip})`}>
            <rect x="20" y="660" width="560" height="70" fill={GOLD} opacity=".92" />
            <rect x="20" y="676" width="560" height="6" fill={darken(c, 0.4)} opacity=".6" />
            <rect x="20" y="700" width="560" height="4" fill={darken(c, 0.4)} opacity=".6" />
            <rect x="20" y="560" width="560" height="14" fill={GOLD} opacity=".7" />
          </g>
          {[-4, -3, -2, -1, 0, 1, 2, 3, 4].map((i) => (
            <path key={i} d={`M${300 + i * 12} 338 Q${300 + i * 36} 520 ${300 + i * 60} 722`} fill="none" stroke={stroke} strokeOpacity=".16" strokeWidth="2" />
          ))}
          <Cloth d={choli} fill={darken(c, 0.18)} uid={uid} />
          <path d="M255 150 Q300 180 345 150" fill="none" stroke={GOLD} strokeWidth="3" />
          <rect x="232" y="328" width="136" height="10" fill={GOLD} />
          {/* sheer dupatta */}
          <path d="M238 156 C 300 210 420 300 470 560 L430 566 C 400 380 320 270 238 156 Z" fill={lighten(c, 0.55)} opacity=".6" />
          <path d="M238 156 C 300 210 420 300 470 560" fill="none" stroke={GOLD} strokeWidth="3" opacity=".8" />
        </g>
      )
    }
    case 'western-wear': {
      const top =
        'M255 150 Q300 176 345 150 L404 190 L388 258 L364 248 L366 338 L234 338 L236 248 L212 258 L196 190 Z'
      return (
        <g>
          <Cloth d={SHAPES['western-wear']} fill={darken(c, 0.12)} uid={uid} patterned={false} />
          <path d="M300 470 L284 722 M300 470 L316 722" stroke={stroke} strokeOpacity=".3" strokeWidth="2" />
          <rect x="236" y="326" width="128" height="16" fill={darken(c, 0.4)} />
          <rect x="294" y="326" width="12" height="16" fill={GOLD} />
          <Cloth d={top} fill={lighten(c, 0.35)} uid={uid} />
          <path d="M255 150 Q300 176 345 150" fill="none" stroke={darken(c, 0.3)} strokeWidth="3" />
          <path d="M300 176 L300 330" stroke={darken(c, 0.3)} strokeOpacity=".3" strokeWidth="2" />
        </g>
      )
    }
    case 'ethnic-sets': {
      const pants = 'M232 560 L368 560 L378 722 L312 722 L300 640 L288 722 L222 722 Z'
      return (
        <g>
          <Cloth d={pants} fill={lighten(c, 0.28)} uid={uid} patterned={false} />
          <rect x="226" y="700" width="152" height="22" fill={GOLD} opacity=".85" />
          <Cloth d={SHAPES['ethnic-sets']} fill={c} uid={uid} />
          <clipPath id={clip}><path d={SHAPES['ethnic-sets']} /></clipPath>
          <g clipPath={`url(#${clip})`}>
            <rect x="150" y="566" width="300" height="34" fill={GOLD} opacity=".9" />
          </g>
          <path d="M270 148 Q300 212 330 148" fill="none" stroke={GOLD} strokeWidth="3" strokeDasharray="1 5" strokeLinecap="round" />
          {/* dupatta */}
          <path d="M236 158 L270 150 C 330 220 400 300 420 560 L372 566 C 356 400 310 290 236 158 Z" fill={lighten(c, 0.5)} opacity=".92" />
          <path d="M236 158 C 310 290 356 400 372 566" fill="none" stroke={GOLD} strokeWidth="3.5" />
        </g>
      )
    }
    default: {
      // sarees — dress-form with blouse, pleated drape and pallu
      const blouse =
        'M250 164 Q300 188 350 164 L368 214 L360 272 L346 384 L254 384 L240 272 L232 214 Z'
      const pallu = 'M238 158 L276 150 L402 372 L440 722 L376 722 L354 410 Z'
      return (
        <g>
          <Cloth d={SHAPES.sarees} fill={c} uid={uid} />
          {[-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5].map((i) => (
            <path key={i} d={`M${300 + i * 12} 384 L${300 + i * 20} 722`} stroke={stroke} strokeOpacity=".22" strokeWidth="2" />
          ))}
          <clipPath id={clip}><path d={SHAPES.sarees} /></clipPath>
          <g clipPath={`url(#${clip})`}>
            <rect x="160" y="672" width="300" height="50" fill={GOLD} opacity=".92" />
            <rect x="160" y="684" width="300" height="4" fill={darken(c, 0.4)} opacity=".55" />
          </g>
          <Cloth d={blouse} fill={darken(c, 0.3)} uid={uid} patterned={false} />
          <path d="M250 164 Q300 188 350 164" fill="none" stroke={GOLD} strokeWidth="2.5" />
          <Cloth d={pallu} fill={c} uid={uid} />
          <path d="M276 150 L402 372 L440 722" fill="none" stroke={GOLD} strokeWidth="5" />
          <path d="M238 158 L354 410 L376 722" fill="none" stroke={GOLD} strokeWidth="2" opacity=".7" />
        </g>
      )
    }
  }
}

/** Neck stub / hanger drawn behind the garment. */
function Support({ category, tone }: { category: CategorySlug; tone: string }) {
  const metal = mix(tone, '#7b6d60', 0.6)
  if (category === 'sarees') {
    return (
      <g>
        <rect x="288" y="104" width="24" height="64" rx="10" fill="#e6d9cb" />
        <circle cx="300" cy="100" r="9" fill="#d9c9b8" />
      </g>
    )
  }
  return (
    <g stroke={metal} strokeWidth="3" fill="none" strokeLinecap="round">
      <path d="M300 112 L212 168 M300 112 L388 168" />
      <path d="M300 112 L300 92 Q300 74 316 74" />
    </g>
  )
}

function Backdrop({ spec, uid }: GarmentProps) {
  const c = spec.hex
  const v = spec.view
  const bgTop = v === 'styled' ? mix(c, '#2a1f1c', 0.55) : lighten(c, 0.86)
  const bgBottom = v === 'styled' ? mix(c, '#2a1f1c', 0.35) : lighten(c, 0.7)
  const arch = v === 'styled' ? lighten(c, 0.12) : lighten(c, 0.93)
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-bg`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={bgTop} />
          <stop offset="1" stopColor={bgBottom} />
        </linearGradient>
        <radialGradient id={`${uid}-glow`} cx=".5" cy=".4" r=".6">
          <stop offset="0" stopColor="#fff" stopOpacity={v === 'styled' ? 0.14 : 0.5} />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="600" height="800" fill={`url(#${uid}-bg)`} />
      {v !== 'flat' && (
        <path d="M95 800 V340 A205 205 0 0 1 505 340 V800 Z" fill={arch} opacity={v === 'styled' ? 0.35 : 0.75} />
      )}
      <rect width="600" height="800" fill={`url(#${uid}-glow)`} />
      <ellipse cx="300" cy="752" rx="230" ry="16" fill="#000" opacity={v === 'styled' ? 0.3 : 0.1} />
    </g>
  )
}

/** Close-up fabric view: large pattern, soft folds, zari border. */
function Detail({ spec, uid }: GarmentProps) {
  const c = spec.hex
  const full = 'M0 0 H600 V800 H0 Z'
  return (
    <g>
      <rect width="600" height="800" fill={c} />
      <rect width="600" height="800" fill={`url(#${uid}-pat)`} />
      {[0, 1, 2, 3].map((i) => (
        <path
          key={i}
          d={`M${-40 + i * 170} 0 C ${60 + i * 170} 260 ${-30 + i * 170} 520 ${90 + i * 170} 800 L${190 + i * 170} 800 C ${70 + i * 170} 520 ${160 + i * 170} 260 ${60 + i * 170} 0 Z`}
          fill={i % 2 ? '#000' : '#fff'}
          opacity={i % 2 ? 0.1 : 0.08}
        />
      ))}
      <rect x="0" y="620" width="600" height="86" fill={GOLD} opacity=".92" />
      <rect x="0" y="640" width="600" height="6" fill={darken(c, 0.45)} opacity=".5" />
      <rect x="0" y="672" width="600" height="6" fill={darken(c, 0.45)} opacity=".5" />
      <rect x="0" y="706" width="600" height="94" fill={darken(c, 0.15)} opacity=".9" />
      <path d={full} fill={`url(#${uid}-shade)`} />
    </g>
  )
}

export function ProductArt({
  spec,
  label,
  className = '',
}: {
  spec: ArtSpec
  label: string
  className?: string
}) {
  const uid = useId().replace(/:/g, '')
  const { view } = spec
  const isLight = luminance(spec.hex) > 0.7

  return (
    <svg
      viewBox="0 0 600 800"
      preserveAspectRatio="xMidYMid slice"
      role="img"
      aria-label={label}
      className={`block h-full w-full ${className}`}
    >
      <Defs spec={spec} uid={uid} />
      {view === 'detail' ? (
        <Detail spec={spec} uid={uid} />
      ) : (
        <>
          <Backdrop spec={spec} uid={uid} />
          <g
            transform={
              view === 'styled'
                ? 'translate(-36 -48) scale(1.12)'
                : view === 'flat'
                  ? 'translate(60 120) rotate(-7 300 400) scale(.88)'
                  : undefined
            }
          >
            {view !== 'flat' && <Support category={spec.category} tone={spec.hex} />}
            <Garment spec={spec} uid={uid} />
            {isLight && (
              <path d={SHAPES[spec.category]} fill="none" stroke="#000" strokeOpacity=".08" strokeWidth="2" />
            )}
          </g>
          {view === 'flat' && (
            <g opacity=".9">
              <circle cx="92" cy="690" r="34" fill="none" stroke={GOLD} strokeWidth="6" />
              <circle cx="92" cy="690" r="22" fill="none" stroke={GOLD} strokeWidth="2" opacity=".6" />
            </g>
          )}
        </>
      )}
    </svg>
  )
}

/** Wide editorial scene for the homepage hero. */
export function HeroArt({ className = '', viewBox = '0 0 1600 900' }: { className?: string; viewBox?: string }) {
  const uid = useId().replace(/:/g, '')
  const a: ArtSpec = { category: 'sarees', pattern: 'butti', view: 'front', hex: '#8E5362' }
  const b: ArtSpec = { category: 'occasion-wear', pattern: 'floral', view: 'front', hex: '#B8864E' }
  const c: ArtSpec = { category: 'dresses', pattern: 'plain', view: 'front', hex: '#E8D9C5' }
  return (
    <svg
      viewBox={viewBox}
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      className={`block h-full w-full ${className}`}
    >
      <defs>
        <linearGradient id={`${uid}-sky`} x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stopColor="#3a1f29" />
          <stop offset=".55" stopColor="#6d3a4b" />
          <stop offset="1" stopColor="#b98a8f" />
        </linearGradient>
        <radialGradient id={`${uid}-halo`} cx=".72" cy=".42" r=".5">
          <stop offset="0" stopColor="#f3d9c7" stopOpacity=".55" />
          <stop offset="1" stopColor="#f3d9c7" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="1600" height="900" fill={`url(#${uid}-sky)`} />
      <rect width="1600" height="900" fill={`url(#${uid}-halo)`} />
      {/* arches */}
      <path d="M760 900 V380 A260 260 0 0 1 1280 380 V900 Z" fill="#f3e3d6" opacity=".16" />
      <path d="M830 900 V400 A190 190 0 0 1 1210 400 V900 Z" fill="#f3e3d6" opacity=".12" />
      <path d="M1250 900 V470 A180 180 0 0 1 1610 470 V900 Z" fill="#f3e3d6" opacity=".1" />
      {/* hanging rail */}
      <path d="M700 118 H1600" stroke="#d9b98a" strokeWidth="4" opacity=".7" />
      {/* garments */}
      <g transform="translate(790 20) scale(1.12)"><Defs spec={a} uid={`${uid}a`} /><Support category="sarees" tone="#8E5362" /><Garment spec={a} uid={`${uid}a`} /></g>
      <g transform="translate(1110 150) scale(.92)"><Defs spec={b} uid={`${uid}b`} /><Support category="occasion-wear" tone="#B8864E" /><Garment spec={b} uid={`${uid}b`} /></g>
      <g transform="translate(1290 230) scale(.74)"><Defs spec={c} uid={`${uid}c`} /><Support category="dresses" tone="#E8D9C5" /><Garment spec={c} uid={`${uid}c`} /></g>
      {/* floor */}
      <rect y="820" width="1600" height="80" fill="#2a1820" opacity=".45" />
      <ellipse cx="1000" cy="826" rx="300" ry="18" fill="#000" opacity=".25" />
      {/* gold fine lines */}
      <path d="M0 640 C 300 600 520 700 760 660" fill="none" stroke="#d9b98a" strokeOpacity=".35" />
      <path d="M0 660 C 300 620 520 720 760 680" fill="none" stroke="#d9b98a" strokeOpacity=".2" />
    </svg>
  )
}
