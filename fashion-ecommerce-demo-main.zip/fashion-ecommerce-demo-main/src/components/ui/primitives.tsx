import { motion } from 'motion/react'
import { Minus, Plus } from 'lucide-react'
import type { ReactNode } from 'react'
import { cn, discountPercent, formatPrice } from '../../lib/utils'
import type { Product } from '../../types'

/** Fade-and-rise on scroll into view. Respects reduced motion via <MotionConfig>. */
export function Reveal({
  children,
  delay = 0,
  className,
  y = 22,
}: {
  children: ReactNode
  delay?: number
  className?: string
  y?: number
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '0px 0px -8% 0px' }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}

export function SectionHeading({
  eyebrow,
  title,
  action,
  align = 'left',
}: {
  eyebrow?: string
  title: string
  action?: ReactNode
  align?: 'left' | 'center'
}) {
  return (
    <div className={cn('mb-8 flex gap-6 md:mb-12', align === 'center' ? 'flex-col items-center text-center' : 'items-end justify-between')}>
      <div>
        {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
        <h2 className="text-[2.1rem] md:text-5xl">{title}</h2>
      </div>
      {action}
    </div>
  )
}

export function QuantityStepper({
  value,
  onChange,
  max = 99,
  compact,
}: {
  value: number
  onChange: (n: number) => void
  max?: number
  compact?: boolean
}) {
  const btn = cn('grid place-items-center transition-colors hover:bg-sand disabled:opacity-35 disabled:hover:bg-transparent', compact ? 'size-10' : 'size-12')
  return (
    <div className="inline-flex items-center border border-line bg-white" role="group" aria-label="Quantity">
      <button className={btn} onClick={() => onChange(value - 1)} aria-label="Decrease quantity" disabled={value <= 1}>
        <Minus size={16} />
      </button>
      <span className="min-w-8 text-center text-sm font-medium tabular-nums" aria-live="polite">
        {value}
      </span>
      <button className={btn} onClick={() => onChange(value + 1)} aria-label="Increase quantity" disabled={value >= max}>
        <Plus size={16} />
      </button>
    </div>
  )
}

export function Price({ product, size = 'md' }: { product: Pick<Product, 'price' | 'compareAtPrice'>; size?: 'md' | 'lg' }) {
  const off = discountPercent(product)
  return (
    <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
      <span className={cn('font-medium tabular-nums', size === 'lg' ? 'text-2xl' : 'text-[15px]')}>{formatPrice(product.price)}</span>
      {off > 0 && (
        <>
          <span className={cn('text-ink-soft line-through tabular-nums', size === 'lg' ? 'text-base' : 'text-[13px]')}>
            {formatPrice(product.compareAtPrice!)}
          </span>
          <span className={cn('font-medium text-rose', size === 'lg' ? 'text-sm' : 'text-xs')}>{off}% off</span>
        </>
      )}
    </div>
  )
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton', className)} aria-hidden="true" />
}

export function ProductCardSkeleton() {
  return (
    <div aria-hidden="true">
      <Skeleton className="aspect-[3/4] w-full" />
      <Skeleton className="mt-4 h-4 w-3/4" />
      <Skeleton className="mt-2 h-4 w-1/3" />
    </div>
  )
}

export function EmptyState({
  title,
  body,
  action,
  icon,
}: {
  title: string
  body: string
  action?: ReactNode
  icon?: ReactNode
}) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 py-16 text-center">
      <div className="mb-6 grid size-20 place-items-center rounded-full bg-rose-mist text-rose">{icon}</div>
      <h3 className="text-3xl">{title}</h3>
      <p className="mt-3 text-ink-soft">{body}</p>
      {action && <div className="mt-8">{action}</div>}
    </div>
  )
}

/** Brand wordmark. */
export function Wordmark({ className, light }: { className?: string; light?: boolean }) {
  return (
    <span className={cn('font-brand block max-w-[200px] text-center text-[1.1rem] font-semibold leading-tight tracking-[-0.025em] sm:max-w-none sm:text-[1.3rem] lg:text-[1.5rem]', light ? 'text-white' : 'text-charcoal', className)}>
      Srivel Fashion House
    </span>
  )
}

/** Accessible on/off switch. */
export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className="group inline-grid min-h-11 min-w-12 place-items-center disabled:opacity-50"
    >
      <span className={cn('relative block h-6 w-11 rounded-full transition-colors duration-200', checked ? 'bg-rose' : 'bg-charcoal/25')}>
        <span className={cn('absolute left-0.5 top-0.5 size-5 rounded-full bg-white shadow transition-transform duration-200', checked && 'translate-x-5')} />
      </span>
    </button>
  )
}
