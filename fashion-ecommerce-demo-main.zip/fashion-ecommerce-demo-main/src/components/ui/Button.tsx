import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from 'react'
import { Link, type LinkProps } from 'react-router-dom'
import { cn } from '../../lib/utils'

type Variant = 'primary' | 'dark' | 'outline' | 'ghost' | 'light'
type Size = 'md' | 'lg' | 'sm'

const base =
  'inline-flex items-center justify-center gap-2 font-medium tracking-[0.04em] transition-[background-color,color,border-color,transform,box-shadow] duration-200 ease-out active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 select-none whitespace-nowrap'

const variants: Record<Variant, string> = {
  primary: 'bg-rose text-white hover:bg-rose-deep',
  dark: 'bg-charcoal text-white hover:bg-black',
  outline: 'border border-charcoal/80 text-charcoal hover:bg-charcoal hover:text-white',
  ghost: 'text-charcoal hover:bg-sand',
  light: 'bg-white text-charcoal hover:bg-sand',
}
const sizes: Record<Size, string> = {
  sm: 'min-h-10 px-4 text-[13px]',
  md: 'min-h-12 px-6 text-sm',
  lg: 'min-h-14 px-8 text-sm uppercase tracking-[0.14em]',
}

interface Common {
  variant?: Variant
  size?: Size
  className?: string
  children: ReactNode
}

export function Button({
  variant = 'primary',
  size = 'md',
  className,
  children,
  ...rest
}: Common & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button type="button" className={cn(base, variants[variant], sizes[size], className)} {...rest}>
      {children}
    </button>
  )
}

export function ButtonLink({
  variant = 'primary',
  size = 'md',
  className,
  children,
  ...rest
}: Common & LinkProps) {
  return (
    <Link className={cn(base, variants[variant], sizes[size], className)} {...rest}>
      {children}
    </Link>
  )
}

/** Styled external link. Always opens safely in a new tab. */
export function ButtonAnchor({
  variant = 'primary',
  size = 'md',
  className,
  children,
  ...rest
}: Common & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'target' | 'rel'>) {
  return (
    <a target="_blank" rel="noopener noreferrer" className={cn(base, variants[variant], sizes[size], className)} {...rest}>
      {children}
    </a>
  )
}
