import { motion } from 'motion/react'
import { Eye, ShoppingBag } from 'lucide-react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAddToCart } from '../../hooks/useAddToCart'
import { recolor } from '../../lib/art'
import { productHoverPhoto } from '../../lib/productPhotos'
import { discountPercent } from '../../lib/utils'
import { useUI } from '../../store/ui'
import type { Product } from '../../types'
import { FashionImage } from '../ui/FashionImage'
import { Price } from '../ui/primitives'
import { ColorSwatches, WishlistButton } from './parts'

export function ProductCard({ product, priority }: { product: Product; priority?: boolean }) {
  const [color, setColor] = useState(product.colors[0]?.name ?? '')
  const setQuickView = useUI((s) => s.setQuickView)
  const addToCart = useAddToCart()
  const hex = product.colors.find((c) => c.name === color)?.hex ?? product.colors[0]?.hex
  const soldOut = product.stock <= 0
  const off = discountPercent(product)
  const hoverPhoto = productHoverPhoto(product.images)

  const tint = (src: string) => (hex ? recolor(src, hex) : src)
  const quickAdd = () => {
    if (product.sizes.length === 1) addToCart(product, product.sizes[0], color)
    else setQuickView(product.slug)
  }

  return (
    <motion.article
      className="group relative"
      whileHover="hover"
      initial="rest"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-sand">
        <Link to={`/product/${product.slug}`} aria-label={`${product.name}, view details`} className="block h-full">
          <motion.div
            className="absolute inset-0"
            variants={{ rest: { scale: 1 }, hover: { scale: 1.05 } }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          >
            <FashionImage src={tint(product.images[0])} alt={product.name} category={product.category} eager={priority} />
          </motion.div>
          {hoverPhoto && (
            <div className="absolute inset-0 opacity-0 transition-opacity duration-500 [@media(hover:hover)]:group-hover:opacity-100">
              <FashionImage src={tint(hoverPhoto)} alt="" category={product.category} />
            </div>
          )}
        </Link>

        <div className="pointer-events-none absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {product.isNew && <span className="bg-white px-2.5 py-1 text-[11px] font-medium uppercase tracking-[0.14em]">New</span>}
          {off > 0 && <span className="bg-rose px-2.5 py-1 text-[11px] font-medium uppercase tracking-[0.1em] text-white">{off}% off</span>}
          {soldOut && <span className="bg-charcoal px-2.5 py-1 text-[11px] font-medium uppercase tracking-[0.1em] text-white">Sold out</span>}
        </div>

        <WishlistButton productId={product.id} name={product.name} className="absolute right-2 top-2" />

        {/* Touch: always-visible quick actions. Hover devices: slide-up bar. */}
        <div className="absolute inset-x-0 bottom-0 hidden translate-y-full gap-px transition-transform duration-300 ease-out [@media(hover:hover)]:flex [@media(hover:hover)]:group-hover:translate-y-0 [@media(hover:hover)]:group-focus-within:translate-y-0">
          <button
            onClick={() => setQuickView(product.slug)}
            className="flex min-h-12 flex-1 items-center justify-center gap-2 bg-white/95 text-[13px] font-medium backdrop-blur transition-colors hover:bg-white"
          >
            <Eye size={16} /> Quick view
          </button>
          <button
            onClick={quickAdd}
            disabled={soldOut}
            className="flex min-h-12 flex-1 items-center justify-center gap-2 bg-charcoal text-[13px] font-medium text-white transition-colors hover:bg-rose disabled:opacity-60"
          >
            <ShoppingBag size={16} /> {product.sizes.length === 1 ? 'Add to bag' : 'Select size'}
          </button>
        </div>
        <button
          onClick={quickAdd}
          disabled={soldOut}
          aria-label={`Quick add ${product.name}`}
          className="absolute bottom-2 right-2 grid size-11 place-items-center rounded-full bg-white/95 shadow-sm backdrop-blur disabled:opacity-60 [@media(hover:hover)]:hidden"
        >
          <ShoppingBag size={18} />
        </button>
      </div>

      <div className="mt-4 space-y-1.5">
        <h3 className="font-sans text-[15px] font-normal leading-snug tracking-normal">
          <Link to={`/product/${product.slug}`} className="hover:text-rose">
            {product.name}
          </Link>
        </h3>
        <Price product={product} />
        <ColorSwatches colors={product.colors} selected={color} onSelect={setColor} />
      </div>
    </motion.article>
  )
}
