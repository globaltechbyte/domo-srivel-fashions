import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAddToCart } from '../../hooks/useAddToCart'
import { recolor } from '../../lib/art'
import { stockFor } from '../../lib/utils'
import { useCatalog } from '../../store/catalog'
import { useUI } from '../../store/ui'
import type { Product } from '../../types'
import { Button } from '../ui/Button'
import { FashionImage } from '../ui/FashionImage'
import { Overlay } from '../ui/Overlay'
import { Price } from '../ui/primitives'
import { ColorSwatches } from './parts'
import { SizeSelector } from './SizeSelector'

function QuickViewBody({ product, onClose }: { product: Product; onClose: () => void }) {
  const addToCart = useAddToCart()
  const [color, setColor] = useState(product.colors[0]?.name ?? '')
  const [size, setSize] = useState(product.sizes.length === 1 ? product.sizes[0] : '')
  const [error, setError] = useState(false)
  const hex = product.colors.find((c) => c.name === color)?.hex

  const available = size ? stockFor(product, size, color) : 0
  const handleAdd = () => {
    if (!size) {
      setError(true)
      return
    }
    if (addToCart(product, size, color)) onClose()
  }

  return (
    <div className="grid gap-0 md:grid-cols-2">
      <div className="aspect-[4/5] md:aspect-auto md:min-h-[460px]">
        <FashionImage src={hex ? recolor(product.images[0], hex) : product.images[0]} alt={product.name} category={product.category} eager />
      </div>
      <div className="flex flex-col gap-5 p-5 md:p-8">
        <div>
          <h3 className="font-serif text-3xl">{product.name}</h3>
          <div className="mt-2">
            <Price product={product} size="lg" />
          </div>
        </div>
        <p className="line-clamp-3 text-sm text-ink-soft">{product.description}</p>
        <div>
          <p className="mb-2 text-sm">
            Colour: <span className="font-medium">{color}</span>
          </p>
          <ColorSwatches
            colors={product.colors}
            selected={color}
            onSelect={(c) => {
              setColor(c)
              if (size && stockFor(product, size, c) <= 0) setSize('')
            }}
            size="lg"
          />
        </div>
        <div>
          <p className="mb-2 text-sm">
            Size: <span className="font-medium">{size || 'Select a size'}</span>
          </p>
          <SizeSelector
            product={product}
            color={color}
            selected={size}
            onSelect={(s) => {
              setSize(s)
              setError(false)
            }}
            error={error}
          />
          {error && (
            <p role="alert" className="mt-2 text-sm text-bad">
              Please select a size to continue.
            </p>
          )}
          {size && available <= 3 && available > 0 && <p className="mt-2 text-sm text-warn">Only {available} left</p>}
        </div>
        <div className="mt-auto flex flex-col gap-3">
          <Button onClick={handleAdd} size="lg" disabled={product.stock <= 0}>
            {product.stock <= 0 ? 'Sold out' : 'Add to bag'}
          </Button>
          <Link to={`/product/${product.slug}`} onClick={onClose} className="text-center text-sm underline underline-offset-4 hover:text-rose">
            View full details
          </Link>
        </div>
      </div>
    </div>
  )
}

export function QuickView() {
  const slug = useUI((s) => s.quickViewSlug)
  const setQuickView = useUI((s) => s.setQuickView)
  const products = useCatalog((s) => s.products)
  const product = products.find((p) => p.slug === slug)
  const [shown, setShown] = useState<Product | undefined>(undefined)

  // keep content mounted during the exit animation
  useEffect(() => {
    if (product) setShown(product)
  }, [product])

  const close = () => setQuickView(null)

  return (
    <Overlay open={!!product} onClose={close} title={shown ? `Quick view: ${shown.name}` : 'Quick view'} hideTitle widthClass="max-w-3xl" className="md:overflow-hidden">
      {shown && <QuickViewBody key={shown.id} product={shown} onClose={close} />}
    </Overlay>
  )
}
