import { cn, stockFor } from '../../lib/utils'
import type { Product } from '../../types'

export function SizeSelector({
  product,
  color,
  selected,
  onSelect,
  error,
}: {
  product: Product
  color: string
  selected: string
  onSelect: (size: string) => void
  error?: boolean
}) {
  return (
    <div
      role="radiogroup"
      aria-label="Size"
      aria-invalid={error}
      className={cn('flex flex-wrap gap-2 rounded-sm', error && 'ring-1 ring-bad/60 ring-offset-8 ring-offset-ivory')}
    >
      {product.sizes.map((size) => {
        const stock = stockFor(product, size, color)
        const active = selected === size
        return (
          <button
            key={size}
            role="radio"
            aria-checked={active}
            disabled={stock <= 0}
            onClick={() => onSelect(size)}
            className={cn(
              'relative min-h-12 min-w-14 border px-4 text-sm transition-[background-color,color,border-color] duration-200',
              active ? 'border-charcoal bg-charcoal text-white' : 'border-line bg-white hover:border-charcoal',
              stock <= 0 && 'text-ink-soft/50 line-through hover:border-line',
            )}
          >
            {size}
            {stock > 0 && stock <= 3 && !active && (
              <span className="absolute -right-1 -top-1 size-2.5 rounded-full bg-warn" title={`Only ${stock} left`} />
            )}
          </button>
        )
      })}
    </div>
  )
}
