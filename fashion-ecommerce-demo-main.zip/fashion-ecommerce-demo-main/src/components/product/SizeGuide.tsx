import { Overlay } from '../ui/Overlay'

const ROWS = [
  ['XS', '32', '26', '35', '6'],
  ['S', '34', '28', '37', '8'],
  ['M', '36', '30', '39', '10'],
  ['L', '38', '32', '41', '12'],
  ['XL', '40', '34', '43', '14'],
  ['XXL', '42', '36', '45', '16'],
]

export function SizeGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Overlay open={open} onClose={onClose} title="Size guide" widthClass="max-w-xl">
      <div className="space-y-5 p-5 md:p-6">
        <p className="text-sm text-ink-soft">
          Body measurements in inches. If you are between sizes, we recommend sizing up for a relaxed fit. Sample chart — replace with your
          own measurements.
        </p>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[420px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-charcoal/70 text-[11px] uppercase tracking-[0.14em] text-ink-soft">
                <th className="py-3 font-medium">Size</th>
                <th className="py-3 font-medium">Bust</th>
                <th className="py-3 font-medium">Waist</th>
                <th className="py-3 font-medium">Hip</th>
                <th className="py-3 font-medium">UK</th>
              </tr>
            </thead>
            <tbody>
              {ROWS.map((r) => (
                <tr key={r[0]} className="border-b border-line">
                  {r.map((c, i) => (
                    <td key={i} className={i === 0 ? 'py-3 font-medium' : 'py-3 tabular-nums'}>
                      {c}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="rounded-sm bg-sand p-4 text-sm text-ink-soft">
          <p className="font-medium text-charcoal">Sarees & lehengas</p>
          <p className="mt-1">Sarees are free size (approx. 5.5 m with a 0.8 m unstitched blouse piece). Lehenga waists are adjustable with drawstrings.</p>
        </div>
        <div>
          <p className="mb-2 font-medium">How to measure</p>
          <ul className="list-disc space-y-1 pl-5 text-sm text-ink-soft">
            <li>Bust: around the fullest part, keeping the tape level.</li>
            <li>Waist: around the narrowest part of your natural waist.</li>
            <li>Hip: around the fullest part of your hips.</li>
          </ul>
        </div>
      </div>
    </Overlay>
  )
}
