import { ZoomIn } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { recolor } from '../../lib/art'
import { cn } from '../../lib/utils'
import type { Product } from '../../types'
import { FashionImage } from '../ui/FashionImage'
import { Overlay } from '../ui/Overlay'

export function Gallery({ product, hex }: { product: Product; hex?: string }) {
  const images = product.images.map((src) => (hex ? recolor(src, hex) : src))
  const [active, setActive] = useState(0)
  const [zoomOpen, setZoomOpen] = useState(false)
  const [zoomed, setZoomed] = useState(false)
  const [origin, setOrigin] = useState('50% 50%')
  const [hovering, setHovering] = useState(false)
  const scroller = useRef<HTMLDivElement>(null)

  useEffect(() => setActive(0), [product.id])

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    setOrigin(`${((e.clientX - r.left) / r.width) * 100}% ${((e.clientY - r.top) / r.height) * 100}%`)
  }

  const onScroll = () => {
    const el = scroller.current
    if (!el) return
    setActive(Math.round(el.scrollLeft / el.clientWidth))
  }

  const goTo = (i: number) => {
    setActive(i)
    const el = scroller.current
    if (el && el.offsetParent) el.scrollTo({ left: i * el.clientWidth, behavior: 'smooth' })
  }

  return (
    <div className="lg:flex lg:gap-4">
      {/* Desktop thumbnails */}
      <div className="hidden flex-col gap-3 lg:flex" role="tablist" aria-label="Product images">
        {images.map((src, i) => (
          <button
            key={i}
            role="tab"
            aria-selected={active === i}
            aria-label={`Image ${i + 1}`}
            onClick={() => setActive(i)}
            className={cn('aspect-[3/4] w-20 overflow-hidden border transition-colors', active === i ? 'border-charcoal' : 'border-transparent opacity-75 hover:opacity-100')}
          >
            <FashionImage src={src} alt="" category={product.category} />
          </button>
        ))}
      </div>

      <div className="min-w-0 flex-1">
        {/* Mobile: swipeable */}
        <div
          ref={scroller}
          onScroll={onScroll}
          className="hide-scrollbar -mx-4 flex snap-x snap-mandatory overflow-x-auto md:mx-0 lg:hidden"
          role="region"
          aria-label="Product image gallery, swipe to browse"
        >
          {images.map((src, i) => (
            <button
              key={i}
              onClick={() => setZoomOpen(true)}
              aria-label={`Zoom image ${i + 1}`}
              className="aspect-[4/5] w-full shrink-0 snap-center overflow-hidden bg-sand md:aspect-[3/4]"
            >
              <FashionImage src={src} alt={`${product.name} — view ${i + 1}`} category={product.category} eager={i === 0} />
            </button>
          ))}
        </div>
        <div className="mt-3 flex justify-center gap-2 lg:hidden" aria-hidden="true">
          {images.map((_, i) => (
            <button key={i} onClick={() => goTo(i)} tabIndex={-1} className={cn('h-1.5 rounded-full transition-all duration-300', active === i ? 'w-6 bg-charcoal' : 'w-1.5 bg-charcoal/25')} />
          ))}
        </div>

        {/* Desktop: hover zoom */}
        <div
          className="relative hidden aspect-[3/4] cursor-zoom-in overflow-hidden bg-sand lg:block"
          onMouseMove={onMove}
          onMouseEnter={() => setHovering(true)}
          onMouseLeave={() => setHovering(false)}
          onClick={() => setZoomOpen(true)}
        >
          <div
            className="h-full w-full transition-transform duration-300 ease-out will-change-transform"
            style={{ transform: hovering ? 'scale(1.8)' : 'scale(1)', transformOrigin: origin }}
          >
            <FashionImage src={images[active]} alt={`${product.name} — view ${active + 1}`} category={product.category} eager />
          </div>
          <span className="pointer-events-none absolute bottom-4 right-4 flex items-center gap-2 bg-white/90 px-3 py-2 text-xs backdrop-blur">
            <ZoomIn size={14} /> Hover to zoom, click to enlarge
          </span>
        </div>
      </div>

      <Overlay open={zoomOpen} onClose={() => { setZoomOpen(false); setZoomed(false) }} title="Enlarged image" widthClass="max-w-2xl">
        <div
          className={cn('relative aspect-[3/4] overflow-hidden bg-sand', zoomed ? 'cursor-zoom-out' : 'cursor-zoom-in')}
          onClick={(e) => {
            const r = e.currentTarget.getBoundingClientRect()
            setOrigin(`${((e.clientX - r.left) / r.width) * 100}% ${((e.clientY - r.top) / r.height) * 100}%`)
            setZoomed((z) => !z)
          }}
          onMouseMove={zoomed ? onMove : undefined}
        >
          <div className="h-full w-full transition-transform duration-300 ease-out" style={{ transform: zoomed ? 'scale(2.2)' : 'scale(1)', transformOrigin: origin }}>
            <FashionImage src={images[active]} alt={product.name} category={product.category} />
          </div>
        </div>
        <p className="px-5 py-3 text-center text-xs text-ink-soft">{zoomed ? 'Click to zoom out' : 'Click to zoom in'}</p>
      </Overlay>
    </div>
  )
}
