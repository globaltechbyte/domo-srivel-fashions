import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import type { Product } from '../../types'
import { ProductCard } from './ProductCard'

export function ProductCarousel({ products }: { products: Product[] }) {
  const ref = useRef<HTMLDivElement>(null)
  const [edge, setEdge] = useState({ start: true, end: false })

  const update = useCallback(() => {
    const el = ref.current
    if (!el) return
    setEdge({ start: el.scrollLeft < 8, end: el.scrollLeft + el.clientWidth >= el.scrollWidth - 8 })
  }, [])

  useEffect(() => {
    update()
    window.addEventListener('resize', update)
    return () => window.removeEventListener('resize', update)
  }, [update, products.length])

  const scrollBy = (dir: 1 | -1) => {
    const el = ref.current
    if (!el) return
    el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: 'smooth' })
  }

  return (
    <div className="relative">
      <div
        ref={ref}
        onScroll={update}
        className="hide-scrollbar -mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth px-4 pb-2 md:-mx-8 md:gap-6 md:px-8 xl:-mx-12 xl:px-12"
        tabIndex={0}
        role="region"
        aria-label="Bestsellers carousel"
      >
        {products.map((p, i) => (
          <div key={p.id} className="w-[64vw] max-w-[300px] shrink-0 snap-start sm:w-[38vw] md:w-[26vw] xl:w-[22vw]">
            <ProductCard product={p} priority={i < 3} />
          </div>
        ))}
      </div>
      <div className="mt-6 hidden justify-end gap-2 md:flex">
        <button
          onClick={() => scrollBy(-1)}
          disabled={edge.start}
          aria-label="Previous products"
          className="grid size-12 place-items-center rounded-full border border-line bg-white transition-colors hover:bg-charcoal hover:text-white disabled:opacity-40 disabled:hover:bg-white disabled:hover:text-charcoal"
        >
          <ChevronLeft size={20} />
        </button>
        <button
          onClick={() => scrollBy(1)}
          disabled={edge.end}
          aria-label="Next products"
          className="grid size-12 place-items-center rounded-full border border-line bg-white transition-colors hover:bg-charcoal hover:text-white disabled:opacity-40 disabled:hover:bg-white disabled:hover:text-charcoal"
        >
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  )
}
