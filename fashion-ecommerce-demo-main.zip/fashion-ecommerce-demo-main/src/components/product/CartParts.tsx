import { Trash2 } from 'lucide-react'
import { Link } from 'react-router-dom'
import { SHIPPING } from '../../config'
import { recolor } from '../../lib/art'
import { cn, formatPrice } from '../../lib/utils'
import { useCart, type CartLine } from '../../store/cart'
import { FashionImage } from '../ui/FashionImage'
import { QuantityStepper } from '../ui/primitives'

export function CartLineItem({ line, onNavigate, large }: { line: CartLine; onNavigate?: () => void; large?: boolean }) {
  const setQty = useCart((s) => s.setQty)
  const remove = useCart((s) => s.remove)
  const hex = line.product.colors.find((c) => c.name === line.color)?.hex
  const img = hex ? recolor(line.product.images[0], hex) : line.product.images[0]
  const over = line.qty > line.maxQty

  return (
    <li className="flex gap-4 py-5">
      <Link
        to={`/product/${line.product.slug}`}
        onClick={onNavigate}
        className={cn('shrink-0 overflow-hidden bg-sand', large ? 'w-28 md:w-32' : 'w-24')}
        aria-label={line.product.name}
      >
        <div className="aspect-[3/4]">
          <FashionImage src={img} alt={line.product.name} category={line.product.category} />
        </div>
      </Link>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <Link to={`/product/${line.product.slug}`} onClick={onNavigate} className="line-clamp-2 text-[15px] hover:text-rose">
              {line.product.name}
            </Link>
            <p className="mt-1 flex items-center gap-2 text-[13px] text-ink-soft">
              <span className="inline-block size-3 rounded-full border border-black/10" style={{ background: hex }} />
              {line.color} · Size {line.size}
            </p>
          </div>
          <p className="shrink-0 text-[15px] font-medium tabular-nums">{formatPrice(line.lineTotal)}</p>
        </div>
        <p className="mt-0.5 text-[13px] text-ink-soft tabular-nums">{formatPrice(line.unitPrice)} each</p>
        {over && <p className="mt-1 text-[13px] text-bad">Only {line.maxQty} available — please reduce quantity.</p>}
        <div className="mt-auto flex items-center justify-between pt-3">
          <QuantityStepper value={line.qty} onChange={(n) => setQty(line.key, n)} max={Math.max(line.maxQty, 1)} compact />
          <button
            onClick={() => remove(line.key)}
            aria-label={`Remove ${line.product.name} from bag`}
            className="flex min-h-11 items-center gap-1.5 px-2 text-[13px] text-ink-soft transition-colors hover:text-bad"
          >
            <Trash2 size={15} /> Remove
          </button>
        </div>
      </div>
    </li>
  )
}

export function ShippingProgress({ subtotal }: { subtotal: number }) {
  const remaining = SHIPPING.freeAbove - subtotal
  const pct = Math.min(100, (subtotal / SHIPPING.freeAbove) * 100)
  return (
    <div>
      <p className="text-[13px]">
        {remaining > 0 ? (
          <>
            Add <span className="font-medium">{formatPrice(remaining)}</span> more for free shipping
          </>
        ) : (
          <span className="font-medium text-ok">You've unlocked free shipping</span>
        )}
      </p>
      <div className="mt-2 h-1 w-full overflow-hidden bg-line">
        <div className="h-full origin-left bg-rose transition-transform duration-500 ease-out" style={{ transform: `scaleX(${pct / 100})` }} />
      </div>
    </div>
  )
}

export function SummaryRows({ subtotal, shipping, total }: { subtotal: number; shipping: number; total: number }) {
  return (
    <dl className="space-y-2.5 text-sm">
      <div className="flex justify-between">
        <dt className="text-ink-soft">Subtotal</dt>
        <dd className="tabular-nums">{formatPrice(subtotal)}</dd>
      </div>
      <div className="flex justify-between">
        <dt className="text-ink-soft">Shipping (sample)</dt>
        <dd className="tabular-nums">{shipping === 0 ? 'Free' : formatPrice(shipping)}</dd>
      </div>
      <div className="flex justify-between border-t border-line pt-3 text-base font-medium">
        <dt>Total</dt>
        <dd className="tabular-nums">{formatPrice(total)}</dd>
      </div>
    </dl>
  )
}
