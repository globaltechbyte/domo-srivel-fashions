import { AnimatePresence, motion } from 'motion/react'
import { Heart } from 'lucide-react'
import { cn } from '../../lib/utils'
import { useUI, useWishlist } from '../../store/ui'
import type { ColorOption } from '../../types'

export function ColorSwatches({
  colors,
  selected,
  onSelect,
  size = 'sm',
}: {
  colors: ColorOption[]
  selected?: string
  onSelect?: (name: string) => void
  size?: 'sm' | 'lg'
}) {
  return (
    <div className="flex flex-wrap items-center gap-2" role={onSelect ? 'radiogroup' : undefined} aria-label="Colour">
      {colors.map((c) => {
        const active = selected === c.name
        const dim = size === 'lg' ? 'size-9' : 'size-5'
        const inner = (
          <span
            className={cn('block rounded-full border border-black/10', size === 'lg' ? 'size-7' : 'size-4')}
            style={{ background: c.hex }}
          />
        )
        if (!onSelect) {
          return (
            <span key={c.name} title={c.name} className="grid place-items-center">
              {inner}
            </span>
          )
        }
        return (
          <button
            key={c.name}
            role="radio"
            aria-checked={active}
            aria-label={c.name}
            title={c.name}
            onClick={(e) => {
              e.preventDefault()
              onSelect(c.name)
            }}
            className={cn(
              'grid place-items-center rounded-full border transition-[border-color,transform] duration-200',
              size === 'lg' ? 'size-11 ' : dim,
              active ? 'border-charcoal' : 'border-transparent hover:border-line',
            )}
          >
            {inner}
          </button>
        )
      })}
    </div>
  )
}

export function WishlistButton({ productId, name, className }: { productId: string; name: string; className?: string }) {
  const liked = useWishlist((s) => s.ids.includes(productId))
  const toggle = useWishlist((s) => s.toggle)
  const toast = useUI((s) => s.toast)

  return (
    <button
      onClick={(e) => {
        e.preventDefault()
        e.stopPropagation()
        const added = toggle(productId)
        toast(added ? `${name} saved to wishlist` : `${name} removed from wishlist`, 'info', added ? { label: 'View', to: '/wishlist' } : undefined)
      }}
      aria-pressed={liked}
      aria-label={liked ? `Remove ${name} from wishlist` : `Add ${name} to wishlist`}
      className={cn('grid size-11 place-items-center rounded-full bg-white/90 text-charcoal shadow-sm backdrop-blur transition-colors hover:bg-white', className)}
    >
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={liked ? 'on' : 'off'}
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.6, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 500, damping: 22 }}
          className="grid place-items-center"
        >
          <Heart size={18} className={liked ? 'fill-rose text-rose' : ''} />
        </motion.span>
      </AnimatePresence>
    </button>
  )
}
