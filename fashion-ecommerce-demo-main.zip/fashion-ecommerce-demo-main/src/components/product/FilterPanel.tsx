import { AnimatePresence, motion } from 'motion/react'
import { ChevronDown } from 'lucide-react'
import { useState, type ReactNode } from 'react'
import { CATEGORIES } from '../../data/products'
import { cn, formatPrice } from '../../lib/utils'
import type { CategorySlug } from '../../types'

export interface Filters {
  category: CategorySlug | ''
  sizes: string[]
  colors: string[]
  min: number
  max: number
}

function Section({ title, children, defaultOpen = true }: { title: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="border-b border-line py-5">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex min-h-9 w-full items-center justify-between text-[13px] font-medium uppercase tracking-[0.14em]"
      >
        {title}
        <ChevronDown size={18} className={cn('transition-transform duration-300', open && 'rotate-180')} />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="pt-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export function FilterPanel({
  filters,
  onChange,
  bounds,
  sizes,
  colors,
  counts,
}: {
  filters: Filters
  onChange: (f: Partial<Filters>) => void
  bounds: { min: number; max: number }
  sizes: string[]
  colors: { name: string; hex: string }[]
  counts: Record<string, number>
}) {
  const toggle = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v])

  return (
    <div>
      <Section title="Category">
        <ul className="space-y-0.5">
          {[{ slug: '' as const, label: 'All pieces' }, ...CATEGORIES].map((c) => {
            const active = filters.category === c.slug
            return (
              <li key={c.slug || 'all'}>
                <button
                  onClick={() => onChange({ category: c.slug })}
                  aria-pressed={active}
                  className={cn('flex min-h-11 w-full items-center justify-between text-left text-[15px] transition-colors hover:text-rose', active && 'font-medium text-rose')}
                >
                  {c.label}
                  <span className="text-xs text-ink-soft tabular-nums">{counts[c.slug || 'all'] ?? 0}</span>
                </button>
              </li>
            )
          })}
        </ul>
      </Section>

      <Section title="Price">
        <div className="px-1">
          <div className="mb-1 flex justify-between text-sm tabular-nums">
            <span>{formatPrice(filters.min)}</span>
            <span>{formatPrice(filters.max)}</span>
          </div>
          <label className="sr-only" htmlFor="price-min">Minimum price</label>
          <input
            id="price-min"
            type="range"
            className="range"
            min={bounds.min}
            max={bounds.max}
            step={500}
            value={filters.min}
            onChange={(e) => onChange({ min: Math.min(Number(e.target.value), filters.max - 500) })}
          />
          <label className="sr-only" htmlFor="price-max">Maximum price</label>
          <input
            id="price-max"
            type="range"
            className="range"
            min={bounds.min}
            max={bounds.max}
            step={500}
            value={filters.max}
            onChange={(e) => onChange({ max: Math.max(Number(e.target.value), filters.min + 500) })}
          />
        </div>
      </Section>

      <Section title="Size">
        <div className="flex flex-wrap gap-2">
          {sizes.map((s) => {
            const active = filters.sizes.includes(s)
            return (
              <button
                key={s}
                aria-pressed={active}
                onClick={() => onChange({ sizes: toggle(filters.sizes, s) })}
                className={cn('min-h-11 min-w-12 border px-3 text-sm transition-colors', active ? 'border-charcoal bg-charcoal text-white' : 'border-line bg-white hover:border-charcoal')}
              >
                {s}
              </button>
            )
          })}
        </div>
      </Section>

      <Section title="Colour">
        <div className="flex flex-wrap gap-1">
          {colors.map((c) => {
            const active = filters.colors.includes(c.name)
            return (
              <button
                key={c.name}
                aria-pressed={active}
                aria-label={c.name}
                title={c.name}
                onClick={() => onChange({ colors: toggle(filters.colors, c.name) })}
                className={cn('grid size-11 place-items-center rounded-full border transition-colors', active ? 'border-charcoal' : 'border-transparent hover:border-line')}
              >
                <span className="block size-7 rounded-full border border-black/10" style={{ background: c.hex }} />
              </button>
            )
          })}
        </div>
      </Section>
    </div>
  )
}
