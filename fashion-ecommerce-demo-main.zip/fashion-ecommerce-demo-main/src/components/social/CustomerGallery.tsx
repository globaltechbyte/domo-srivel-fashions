import { motion } from 'motion/react'
import { Camera, Maximize2, ShieldCheck } from 'lucide-react'
import { useMemo, useState } from 'react'
import { fallbackArt } from '../../lib/art'
import { HOME_CUSTOMER_LIMIT, publicCustomerPhotos } from '../../lib/social'
import { useSocial } from '../../store/social'
import type { CustomerPhoto } from '../../types'
import { MediaView } from '../ui/MediaView'
import { Reveal } from '../ui/primitives'
import { Lightbox, type LightboxItem } from './Lightbox'

/** Aspect ratios for generated placeholders, so the masonry has natural rhythm. Real photos use their own ratio. */
const ART_ASPECTS = ['4 / 5', '1 / 1', '3 / 4', '5 / 6', '4 / 5', '1 / 1']

const subject = (c: CustomerPhoto) => `${c.displayName} from ${c.city}, wearing ${c.productName}${c.isDemo ? ' (demo example)' : ''}`

function Card({ c, index, onOpen }: { c: CustomerPhoto; index: number; onOpen: () => void }) {
  const hasDims = !!(c.photo.width && c.photo.height)
  return (
    <motion.figure
      className="group mb-3 break-inside-avoid bg-white md:mb-5"
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 320, damping: 26 }}
    >
      <button type="button" onClick={onOpen} aria-label={`View photo: ${subject(c)}`} className="relative block w-full overflow-hidden text-left">
        <div style={hasDims ? undefined : { aspectRatio: ART_ASPECTS[index % ART_ASPECTS.length] }}>
          <motion.div className={hasDims ? '' : 'h-full'} whileHover={{ scale: 1.05 }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}>
            <MediaView media={c.photo} alt={`${c.productName}, shared by ${c.displayName}`} fallbackArt={fallbackArt('kurtis', c.id)} fit={hasDims ? 'natural' : 'cover'} />
          </motion.div>
        </div>
        <span className="absolute right-2.5 top-2.5 grid size-9 place-items-center rounded-full bg-white/90 text-charcoal opacity-100 shadow-sm backdrop-blur transition-opacity md:opacity-0 md:group-hover:opacity-100 md:group-focus-within:opacity-100" aria-hidden="true">
          <Maximize2 size={16} />
        </span>
        {c.isDemo && <span className="absolute left-2.5 top-2.5 bg-white/90 px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.12em] text-ink-soft">Demo example</span>}
      </button>
      <figcaption className="space-y-1 p-4">
        <p className="text-[15px] font-medium">{c.displayName} <span className="font-normal text-ink-soft">· {c.city}</span></p>
        <p className="text-[13px] text-ink-soft">{c.productName}</p>
        {c.review && !c.isDemo && <blockquote className="line-clamp-4 pt-1 font-serif text-[1.15rem] leading-snug">“{c.review}”</blockquote>}
      </figcaption>
    </motion.figure>
  )
}

export function CustomerGallery() {
  const all = useSocial((s) => s.customers)
  const items = useMemo(() => publicCustomerPhotos(all).slice(0, HOME_CUSTOMER_LIMIT), [all])
  const [open, setOpen] = useState<number | null>(null)
  const allDemo = items.length > 0 && items.every((c) => c.isDemo)
  const someDemo = items.some((c) => c.isDemo)

  const lightboxItems: LightboxItem[] = items.map((c) => ({
    id: c.id,
    media: c.photo,
    alt: subject(c),
    fallbackArt: fallbackArt('kurtis', c.id),
    details: (
      <>
        <p className="eyebrow !text-[#e2b6c0]">{c.isDemo ? 'Demo example' : 'Shared by a customer'}</p>
        <p className="mt-3 font-serif text-4xl leading-tight">{c.displayName}</p>
        <p className="mt-1 text-white/70">{c.city}</p>
        <p className="mt-4 text-sm text-white/85">{c.productName}</p>
        {c.review && !c.isDemo && <p className="mt-4 font-serif text-2xl leading-snug">“{c.review}”</p>}
        {c.isDemo ? (
          <p className="mt-5 text-[13px] text-white/60">A generated placeholder. It is not a real customer or review.</p>
        ) : (
          <p className="mt-5 flex items-center gap-2 text-[13px] text-white/60"><ShieldCheck size={15} aria-hidden="true" /> Shared with the customer&rsquo;s permission</p>
        )}
      </>
    ),
  }))

  return (
    <section className="mt-24 bg-sand py-20 md:mt-32 md:py-28" aria-labelledby="loved-h">
      <div className="container-x">
        <div className="mb-10 flex flex-col items-center text-center md:mb-14">
          <p className="eyebrow mb-3">Happy customers</p>
          <h2 id="loved-h" className="text-[2.1rem] md:text-5xl">Loved by Our Customers</h2>
          <p className="mt-4 max-w-md text-ink-soft">Delivery moments shared by the women who wear us, published with their permission.</p>
        </div>

        {items.length === 0 ? (
          <div className="mx-auto flex max-w-md flex-col items-center py-8 text-center">
            <div className="mb-5 grid size-16 place-items-center rounded-full bg-white text-rose"><Camera size={26} strokeWidth={1.4} aria-hidden="true" /></div>
            <h3 className="text-3xl">Customer photos will appear here</h3>
            <p className="mt-2 text-ink-soft">We share photos only when customers have agreed to it.</p>
          </div>
        ) : (
          <>
            <div className="columns-2 gap-3 md:columns-3 md:gap-5 lg:columns-4">
              {items.map((c, i) => (
                <Reveal key={c.id} delay={(i % 4) * 0.06} y={18}>
                  <Card c={c} index={i} onOpen={() => setOpen(i)} />
                </Reveal>
              ))}
            </div>
            {someDemo && (
              <p className="mx-auto mt-8 max-w-lg text-center text-[13px] text-ink-soft" role="note">
                {allDemo
                  ? 'Demo examples: these placeholder photos show how this section will look. They are not real customers or reviews.'
                  : 'Items marked “Demo example” are placeholders, not real customers or reviews.'}
              </p>
            )}
          </>
        )}
      </div>
      <Lightbox items={lightboxItems} index={open} onClose={() => setOpen(null)} onIndex={setOpen} />
    </section>
  )
}
