import { AnimatePresence, motion } from 'motion/react'
import { ChevronLeft, ChevronRight, ExternalLink, X } from 'lucide-react'
import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import type { MediaRef } from '../../types'
import { MediaView } from '../ui/MediaView'

export interface LightboxItem {
  id: string
  media?: MediaRef
  poster?: MediaRef
  alt: string
  fallbackArt: string
  /** Text block shown beside/below the media. */
  details: ReactNode
  link?: { href: string; label: string }
}

/** Fullscreen viewer with keyboard (←/→/Esc), button and swipe navigation, and a focus trap. */
export function Lightbox({ items, index, onClose, onIndex }: { items: LightboxItem[]; index: number | null; onClose: () => void; onIndex: (i: number) => void }) {
  const open = index !== null && !!items[index]
  const [dir, setDir] = useState(1)
  const panel = useRef<HTMLDivElement>(null)
  const closeBtn = useRef<HTMLButtonElement>(null)
  const count = items.length

  const go = useCallback(
    (d: 1 | -1) => {
      if (index === null || count < 2) return
      setDir(d)
      onIndex((index + d + count) % count)
    },
    [index, count, onIndex],
  )

  useEffect(() => {
    if (!open) return
    const prevFocus = document.activeElement as HTMLElement | null
    document.documentElement.style.overflow = 'hidden'
    const t = setTimeout(() => closeBtn.current?.focus(), 50)
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      else if (e.key === 'ArrowRight') go(1)
      else if (e.key === 'ArrowLeft') go(-1)
      else if (e.key === 'Tab' && panel.current) {
        const f = panel.current.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),video[controls]')
        if (!f.length) return
        const first = f[0]
        const last = f[f.length - 1]
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      clearTimeout(t)
      document.documentElement.style.overflow = ''
      document.removeEventListener('keydown', onKey)
      prevFocus?.focus?.()
    }
  }, [open, onClose, go])

  const item = open && index !== null ? items[index] : null

  return (
    <AnimatePresence>
      {open && item && (
        <motion.div
          ref={panel}
          role="dialog"
          aria-modal="true"
          aria-label={item.alt}
          className="fixed inset-0 z-[100] flex flex-col bg-charcoal/95 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.22 }}
        >
          <div className="flex items-center justify-between px-4 py-3 text-white md:px-8">
            <p className="text-sm tabular-nums text-white/70" aria-live="polite">{index! + 1} / {count}</p>
            <button ref={closeBtn} onClick={onClose} aria-label="Close viewer" className="grid size-12 place-items-center rounded-full hover:bg-white/10">
              <X size={24} />
            </button>
          </div>

          <div className="relative flex min-h-0 flex-1 flex-col items-center justify-center gap-4 px-4 pb-6 md:flex-row md:gap-10 md:px-24">
            <AnimatePresence mode="wait" custom={dir}>
              <motion.div
                key={item.id}
                custom={dir}
                variants={{ enter: (d: number) => ({ opacity: 0, x: d * 40 }), center: { opacity: 1, x: 0 }, exit: (d: number) => ({ opacity: 0, x: d * -40 }) }}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.25}
                onDragEnd={(_, i) => { if (i.offset.x < -70) go(1); else if (i.offset.x > 70) go(-1) }}
                className="flex min-h-0 w-full max-w-4xl flex-1 flex-col items-center justify-center gap-5 md:flex-row"
              >
                <div className="relative aspect-[4/5] max-h-[70dvh] w-full max-w-[460px] overflow-hidden bg-sand md:max-h-[78dvh]">
                  <MediaView media={item.media} poster={item.poster} alt={item.alt} fallbackArt={item.fallbackArt} controls eager />
                </div>
                <div className="w-full max-w-sm text-white">
                  {item.details}
                  {item.link && (
                    <a href={item.link.href} target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex min-h-11 items-center gap-2 border border-white/60 px-5 text-sm font-medium transition-colors hover:bg-white hover:text-charcoal">
                      {item.link.label} <ExternalLink size={15} aria-hidden="true" />
                    </a>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>

            {count > 1 && (
              <>
                <button onClick={() => go(-1)} aria-label="Previous" className="absolute left-2 top-1/2 hidden size-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-white hover:text-charcoal md:grid md:left-6">
                  <ChevronLeft size={24} />
                </button>
                <button onClick={() => go(1)} aria-label="Next" className="absolute right-2 top-1/2 hidden size-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-white hover:text-charcoal md:grid md:right-6">
                  <ChevronRight size={24} />
                </button>
              </>
            )}
          </div>

          {count > 1 && (
            <div className="flex justify-center gap-3 pb-5 md:hidden">
              <button onClick={() => go(-1)} aria-label="Previous" className="grid size-12 place-items-center rounded-full bg-white/10 text-white"><ChevronLeft size={22} /></button>
              <button onClick={() => go(1)} aria-label="Next" className="grid size-12 place-items-center rounded-full bg-white/10 text-white"><ChevronRight size={22} /></button>
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
