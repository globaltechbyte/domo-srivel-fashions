import { motion } from 'motion/react'
import { ImageOff, Play } from 'lucide-react'
import { useMemo, useState } from 'react'
import { BRAND, INSTAGRAM_IS_PLACEHOLDER } from '../../config'
import { HOME_INSTAGRAM_LIMIT, publicInstagram } from '../../lib/social'
import { cn } from '../../lib/utils'
import { fallbackArt } from '../../lib/art'
import { useSocial } from '../../store/social'
import type { InstagramItem } from '../../types'
import { ButtonAnchor } from '../ui/Button'
import { InstagramIcon } from '../ui/BrandIcons'
import { MediaView } from '../ui/MediaView'
import { Reveal } from '../ui/primitives'
import { Lightbox, type LightboxItem } from './Lightbox'

const EASE = [0.22, 1, 0.36, 1] as const

/** First tile is the editorial "feature" tile once there are enough items to balance the grid. */
const isFeature = (i: number, total: number) => i === 0 && total >= 6

function tileLabel(i: InstagramItem) {
  const what = i.type === 'reel' || i.media?.kind === 'video' ? 'video' : 'photo'
  return `${i.caption || 'Instagram ' + what}${i.isDemo ? ' (demo example)' : ''}`
}

function Tile({ item, index, total, onOpen }: { item: InstagramItem; index: number; total: number; onOpen: () => void }) {
  const feature = isFeature(index, total)
  const isVideo = item.type === 'reel' || item.media?.kind === 'video'
  // Real Instagram content links out; uploads and demo items open the in-page viewer.
  const external = !!item.instagramUrl
  const cls = cn(
    'group relative block w-full overflow-hidden bg-sand text-left',
    feature ? 'aspect-[16/10] md:aspect-auto md:h-full' : 'aspect-square',
  )

  const inner = (
    <>
      <motion.div
        className="absolute inset-0"
        whileHover={{ scale: 1.06 }}
        transition={{ duration: 0.7, ease: EASE }}
      >
        <MediaView
          media={item.media}
          poster={item.thumbnail}
          alt={tileLabel(item)}
          fallbackArt={fallbackArt('dresses', item.id)}
        />
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal/65 via-transparent to-charcoal/10 opacity-70 transition-opacity duration-300 md:opacity-0 md:group-hover:opacity-100 md:group-focus-visible:opacity-100" />
      {item.caption && (
        <p className={cn('absolute inset-x-0 bottom-0 p-3 text-[13px] leading-snug text-white md:translate-y-2 md:p-5 md:text-sm md:opacity-0 md:transition-all md:duration-300 md:group-hover:translate-y-0 md:group-hover:opacity-100', feature ? 'md:text-base' : 'line-clamp-2')}>
          {item.caption}
        </p>
      )}
      {isVideo && (
        <span className="absolute left-1/2 top-1/2 grid size-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white/85 text-charcoal shadow-lg backdrop-blur transition-transform duration-300 group-hover:scale-110 md:size-14" aria-hidden="true">
          <Play size={20} className="ml-0.5 fill-current" />
        </span>
      )}
      <span className="absolute right-2.5 top-2.5 grid size-8 place-items-center rounded-full bg-white/85 text-charcoal backdrop-blur" aria-hidden="true">
        <InstagramIcon width={16} height={16} />
      </span>
      {item.isDemo && <span className="absolute left-2.5 top-2.5 bg-white/90 px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.12em] text-ink-soft">Demo</span>}
    </>
  )

  return external ? (
    <a href={item.instagramUrl} target="_blank" rel="noopener noreferrer" className={cls} aria-label={`${tileLabel(item)} — opens on Instagram in a new tab`}>
      {inner}
    </a>
  ) : (
    <button type="button" onClick={onOpen} className={cls} aria-label={`${tileLabel(item)} — open preview`}>
      {inner}
    </button>
  )
}

export function InstagramGallery() {
  const all = useSocial((s) => s.instagram)
  const items = useMemo(() => publicInstagram(all).slice(0, HOME_INSTAGRAM_LIMIT), [all])
  const [open, setOpen] = useState<number | null>(null)
  const anyDemo = items.some((i) => i.isDemo)

  const lightboxItems: LightboxItem[] = items.map((i) => ({
    id: i.id,
    media: i.media,
    poster: i.thumbnail,
    alt: tileLabel(i),
    fallbackArt: fallbackArt('dresses', i.id),
    details: (
      <>
        <p className="eyebrow !text-[#e2b6c0]">{i.type === 'reel' ? 'Reel' : 'Instagram'}{i.isDemo ? ' · Demo example' : ''}</p>
        <p className="mt-3 font-serif text-3xl leading-tight">{i.caption || 'Styled on Instagram'}</p>
        {i.isDemo && <p className="mt-3 text-sm text-white/65">A generated placeholder. Real posts and reels link to Instagram.</p>}
      </>
    ),
    link: i.instagramUrl ? { href: i.instagramUrl, label: 'View on Instagram' } : undefined,
  }))

  return (
    <section className="container-x pt-24 md:pt-32" aria-labelledby="ig-h">
      <div className="mb-8 flex flex-col items-center text-center md:mb-12">
        <p className="eyebrow mb-3">{BRAND.instagramHandle}</p>
        <h2 id="ig-h" className="text-[2.1rem] md:text-5xl">Styled on Instagram</h2>
        <p className="mt-4 max-w-md text-ink-soft">Looks, drapes and behind-the-scenes moments from our feed.</p>
      </div>

      {items.length === 0 ? (
        <div className="mx-auto flex max-w-md flex-col items-center py-10 text-center">
          <div className="mb-5 grid size-16 place-items-center rounded-full bg-rose-mist text-rose"><ImageOff size={26} strokeWidth={1.4} aria-hidden="true" /></div>
          <h3 className="text-3xl">Our feed is coming soon</h3>
          <p className="mt-2 text-ink-soft">Check back shortly, or follow along on Instagram.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4 md:gap-3">
          {items.map((item, i) => (
            <Reveal key={item.id} delay={(i % 4) * 0.05} className={cn(isFeature(i, items.length) && 'col-span-2 md:row-span-2')}>
              <Tile item={item} index={i} total={items.length} onOpen={() => setOpen(i)} />
            </Reveal>
          ))}
        </div>
      )}

      <div className="mt-10 flex flex-col items-center gap-3 text-center">
        <ButtonAnchor href={BRAND.instagramUrl} size="lg" variant="dark">
          <InstagramIcon /> Follow Us on Instagram
          <span className="sr-only">(opens Instagram in a new tab)</span>
        </ButtonAnchor>
        {(anyDemo || INSTAGRAM_IS_PLACEHOLDER) && (
          <p className="max-w-md text-[13px] text-ink-soft">
            {anyDemo && 'Demo gallery: these are generated sample images, not real posts. '}
            {INSTAGRAM_IS_PLACEHOLDER && 'Set your profile link in src/config.ts.'}
          </p>
        )}
      </div>

      <Lightbox items={lightboxItems} index={open} onClose={() => setOpen(null)} onIndex={setOpen} />
    </section>
  )
}
