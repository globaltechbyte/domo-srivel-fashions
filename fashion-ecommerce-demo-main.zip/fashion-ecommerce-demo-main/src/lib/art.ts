import type { CategorySlug } from '../types'

/**
 * Generated "image" tokens. Format:  art:<category>:<pattern>:<view>:<hex>
 * Any product image string that starts with `art:` is rendered by <ProductArt />.
 * Replace with real photo URLs at any time — see data/products.ts.
 */
export type ArtPattern = 'plain' | 'stripe' | 'dots' | 'floral' | 'butti'
export type ArtView = 'front' | 'detail' | 'styled' | 'flat'

export interface ArtSpec {
  category: CategorySlug
  pattern: ArtPattern
  view: ArtView
  hex: string
}

export const makeArt = (s: ArtSpec) =>
  `art:${s.category}:${s.pattern}:${s.view}:${s.hex.replace('#', '')}`

export function parseArt(src: string): ArtSpec | null {
  if (!src.startsWith('art:')) return null
  const [, category, pattern, view, hex] = src.split(':')
  if (!category || !pattern || !view || !hex) return null
  return {
    category: category as CategorySlug,
    pattern: pattern as ArtPattern,
    view: view as ArtView,
    hex: `#${hex}`,
  }
}

/** Re-tint an art token to a different colour (used when a colour swatch is picked). */
export function recolor(src: string, hex: string): string {
  const spec = parseArt(src)
  return spec ? makeArt({ ...spec, hex }) : src
}

/** Deterministic art token used when a real image URL fails to load. */
export function fallbackArt(category: CategorySlug, seed: string): string {
  const patterns: ArtPattern[] = ['plain', 'stripe', 'dots', 'floral', 'butti']
  let h = 0
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0
  return makeArt({ category, pattern: patterns[h % patterns.length], view: 'front', hex: '#C98B9A' })
}

/* ── colour maths ─────────────────────────────────────────── */
export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '')
  const f = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  const n = parseInt(f, 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}
const toHex = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0')
export const rgbToHex = (r: number, g: number, b: number) => `#${toHex(r)}${toHex(g)}${toHex(b)}`

export function mix(a: string, b: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(a)
  const [r2, g2, b2] = hexToRgb(b)
  return rgbToHex(r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t)
}
export const lighten = (hex: string, t: number) => mix(hex, '#ffffff', t)
export const darken = (hex: string, t: number) => mix(hex, '#1a1210', t)

export function luminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map((v) => {
    const c = v / 255
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
  })
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
