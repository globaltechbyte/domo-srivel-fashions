import { BRAND, WHATSAPP_NUMBER } from '../config'
import type { CustomerDetails, OrderLine } from '../types'
import { formatPrice } from './utils'

interface MessageInput {
  ref?: string
  lines: OrderLine[]
  subtotal: number
  shipping: number
  total: number
  customer?: CustomerDetails
}

export function buildWhatsAppMessage(m: MessageInput): string {
  const rows = m.lines.map(
    (l, i) =>
      `${i + 1}. ${l.name}\n    Size: ${l.size} | Colour: ${l.color} | Qty: ${l.qty}\n    ${formatPrice(l.unitPrice)} x ${l.qty} = ${formatPrice(l.unitPrice * l.qty)}`,
  )
  const parts = [
    `Hello ${BRAND.name}! I'd like to place an order.`,
    m.ref ? `\nDemo order ref: ${m.ref}` : '',
    '\n*Items*',
    rows.join('\n'),
    `\nSubtotal: ${formatPrice(m.subtotal)}`,
    `Shipping: ${m.shipping === 0 ? 'Free' : formatPrice(m.shipping)}`,
    `*Total: ${formatPrice(m.total)}*`,
  ]
  if (m.customer) {
    const c = m.customer
    const addr = [c.address1, c.address2, c.landmark && `Landmark: ${c.landmark}`, `${c.city}, ${c.state} - ${c.pincode}`]
      .filter(Boolean)
      .join(', ')
    parts.push('\n*Delivery details*', `Name: ${c.fullName}`, `Mobile: ${c.mobile}`, `Address: ${addr}`)
  }
  parts.push('\nPlease confirm availability and payment details. Thank you!')
  return parts.filter((p) => p !== '').join('\n')
}

export function whatsappUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`
}
