/**
 * Minimal IndexedDB wrapper for demo-uploaded media. Files never go into localStorage.
 * Everything here is best-effort: if IndexedDB is unavailable (private mode, blocked storage)
 * callers get a clear error from putMedia and graceful nulls from the readers.
 */

const DB_NAME = 'aurelle-demo-media'
const STORE = 'blobs'

export class MediaStorageError extends Error {}

interface StoredMedia {
  id: string
  blob: Blob
  type: string
  size: number
  createdAt: number
}

let dbPromise: Promise<IDBDatabase> | null = null

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new MediaStorageError("This browser can't store uploads (IndexedDB is unavailable). Use an image URL instead."))
      return
    }
    const req = indexedDB.open(DB_NAME, 1)
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'id' })
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(new MediaStorageError('Could not open browser storage for uploads.'))
    req.onblocked = () => reject(new MediaStorageError('Browser storage is blocked by another tab. Close other tabs and retry.'))
  })
  // allow a retry after failure
  dbPromise.catch(() => (dbPromise = null))
  return dbPromise
}

function tx<T>(mode: IDBTransactionMode, run: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(STORE, mode)
        const req = run(t.objectStore(STORE))
        t.oncomplete = () => resolve(req.result)
        t.onabort = () => reject(t.error ?? req.error)
        t.onerror = () => reject(t.error ?? req.error)
      }),
  )
}

const newId = () => `m-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`

export async function putMedia(blob: Blob): Promise<string> {
  const id = newId()
  const record: StoredMedia = { id, blob, type: blob.type, size: blob.size, createdAt: Date.now() }
  try {
    await tx('readwrite', (s) => s.put(record))
    return id
  } catch (e) {
    if (e instanceof MediaStorageError) throw e
    const quota = e instanceof DOMException && e.name === 'QuotaExceededError'
    throw new MediaStorageError(
      quota ? 'Browser storage is full. Delete some uploads or use smaller files.' : 'Could not save the upload in this browser.',
    )
  }
}

export async function getMedia(id: string): Promise<Blob | null> {
  try {
    const rec = await tx<StoredMedia | undefined>('readonly', (s) => s.get(id))
    return rec?.blob ?? null
  } catch {
    return null
  }
}

export async function deleteMedia(ids: string[]): Promise<void> {
  if (ids.length === 0) return
  try {
    const db = await openDb()
    await new Promise<void>((resolve) => {
      const t = db.transaction(STORE, 'readwrite')
      const s = t.objectStore(STORE)
      ids.forEach((id) => s.delete(id))
      t.oncomplete = () => resolve()
      t.onerror = () => resolve()
      t.onabort = () => resolve()
    })
  } catch {
    /* nothing stored, nothing to delete */
  }
}

/** Total size of everything this demo has stored in IndexedDB. */
export async function mediaUsage(): Promise<{ count: number; bytes: number } | null> {
  try {
    const all = await tx<StoredMedia[]>('readonly', (s) => s.getAll())
    return { count: all.length, bytes: all.reduce((n, r) => n + r.size, 0) }
  } catch {
    return null
  }
}

/** Browser-wide quota (approximate; browsers round and cap these numbers). */
export async function storageEstimate(): Promise<{ usage: number; quota: number } | null> {
  try {
    const e = await navigator.storage?.estimate?.()
    return e?.quota ? { usage: e.usage ?? 0, quota: e.quota } : null
  } catch {
    return null
  }
}
