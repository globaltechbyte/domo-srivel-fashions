import { MOBILE_RE } from './utils'
import type { Order, OrderStatus, ShippingInfo, StatusEvent } from '../types'

/** The happy path, in order. Cancelled is handled separately. */
export const ORDER_FLOW: OrderStatus[] = ['Pending Confirmation', 'Confirmed', 'Packed', 'Shipped', 'Delivered']
export const ALL_STATUSES: OrderStatus[] = [...ORDER_FLOW, 'Cancelled']

/** Valid status transitions. Delivered and Cancelled are terminal. */
const NEXT: Record<OrderStatus, OrderStatus[]> = {
  'Pending Confirmation': ['Confirmed', 'Cancelled'],
  Confirmed: ['Packed', 'Cancelled'],
  Packed: ['Shipped', 'Cancelled'],
  Shipped: ['Delivered'],
  Delivered: [],
  Cancelled: [],
}

export const nextStatuses = (from: OrderStatus): OrderStatus[] => NEXT[from]
export const canTransition = (from: OrderStatus, to: OrderStatus) => NEXT[from].includes(to)
export const isTerminal = (s: OrderStatus) => NEXT[s].length === 0

/** Customer-facing copy for each step. Deliberately avoids implying real fulfilment. */
export const STATUS_COPY: Record<OrderStatus, { title: string; body: string }> = {
  'Pending Confirmation': { title: 'Order received', body: 'Waiting for the store to review and confirm your order.' },
  Confirmed: { title: 'Order confirmed', body: 'The store has confirmed availability and your order details.' },
  Packed: { title: 'Packed', body: 'Your items have been packed and are ready for pick-up by the courier.' },
  Shipped: { title: 'Shipped', body: 'Your order has been handed to the courier and is on its way.' },
  Delivered: { title: 'Delivered', body: 'Your order has been delivered. We hope you love it.' },
  Cancelled: { title: 'Cancelled', body: 'This order was cancelled.' },
}

/* ── tracking URL safety ───────────────────────────────────── */

/**
 * Returns a normalised URL only if it is a plain http(s) link; otherwise null.
 * Rejects javascript:, data:, vbscript:, credentials-in-URL and absurdly long values.
 */
export function safeTrackingUrl(raw: string | undefined | null): string | null {
  const value = (raw ?? '').trim()
  if (!value || value.length > 500) return null
  let url: URL
  try {
    url = new URL(value)
  } catch {
    return null
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return null
  if (url.username || url.password) return null
  if (!url.hostname.includes('.')) return null
  return url.toString()
}

export interface ShippingErrors {
  courierName?: string
  trackingNumber?: string
  trackingUrl?: string
}

export function validateShippingInfo(info: ShippingInfo): ShippingErrors {
  const e: ShippingErrors = {}
  if ((info.courierName ?? '').trim().length > 60) e.courierName = 'Courier name must be 60 characters or fewer.'
  if ((info.trackingNumber ?? '').trim().length > 60) e.trackingNumber = 'Tracking number must be 60 characters or fewer.'
  if ((info.trackingUrl ?? '').trim() && !safeTrackingUrl(info.trackingUrl)) e.trackingUrl = 'Enter a full http:// or https:// link, e.g. https://courier.example/track/123.'
  return e
}

export function cleanShippingInfo(info: ShippingInfo): ShippingInfo | undefined {
  const courierName = (info.courierName ?? '').trim()
  const trackingNumber = (info.trackingNumber ?? '').trim()
  const trackingUrl = safeTrackingUrl(info.trackingUrl) ?? ''
  if (!courierName && !trackingNumber && !trackingUrl) return undefined
  return {
    ...(courierName && { courierName }),
    ...(trackingNumber && { trackingNumber }),
    ...(trackingUrl && { trackingUrl }),
  }
}

/* ── privacy: mask personal data on the public tracking page ── */

export const maskName = (full: string) => {
  const [first = '', ...rest] = full.trim().split(/\s+/)
  const initial = rest.length ? ` ${rest[rest.length - 1][0].toUpperCase()}.` : ''
  return `${first}${initial}`
}
export const maskMobile = (m: string) => `${'•'.repeat(Math.max(m.length - 2, 0))}${m.slice(-2)}`
export const maskPincode = (p: string) => `${p.slice(0, 3)}•••`

/* ── lookup ────────────────────────────────────────────────── */

export const normalizeRef = (v: string) => v.trim().toUpperCase().replace(/\s+/g, '')
export const normalizeMobile = (v: string) => v.replace(/[\s-]/g, '').replace(/^(\+?91)(?=\d{10}$)/, '')

export interface TrackInput {
  ref: string
  mobile: string
}
export interface TrackErrors {
  ref?: string
  mobile?: string
}

export function validateTrackInput(i: TrackInput): TrackErrors {
  const e: TrackErrors = {}
  if (!/^AUR-DEMO-[A-Z0-9]{4,10}$/.test(normalizeRef(i.ref))) e.ref = 'Enter your order ID, e.g. AUR-DEMO-123456.'
  if (!MOBILE_RE.test(normalizeMobile(i.mobile))) e.mobile = 'Enter the 10-digit mobile number used for the order.'
  return e
}

/** Both the order ID and the mobile number must match. */
export function findOrder(orders: Order[], input: TrackInput): Order | undefined {
  const ref = normalizeRef(input.ref)
  const mobile = normalizeMobile(input.mobile)
  return orders.find((o) => normalizeRef(o.ref) === ref && normalizeMobile(o.customer.mobile) === mobile)
}

/* ── history & timeline ────────────────────────────────────── */

export const lastEventFor = (history: StatusEvent[], status: OrderStatus) =>
  [...history].reverse().find((e) => e.status === status)

export type StepState = 'done' | 'current' | 'upcoming' | 'cancelled'
export interface TimelineStep {
  status: OrderStatus
  state: StepState
  at?: string
}

/**
 * Builds the vertical timeline. For cancelled orders, only the steps that were reached
 * are shown, followed by a Cancelled node; future steps are omitted.
 */
export function buildTimeline(order: Pick<Order, 'status' | 'history'>): TimelineStep[] {
  if (order.status === 'Cancelled') {
    const reached = ORDER_FLOW.filter((s) => lastEventFor(order.history, s))
    return [
      ...reached.map<TimelineStep>((s) => ({ status: s, state: 'done', at: lastEventFor(order.history, s)?.at })),
      { status: 'Cancelled', state: 'cancelled', at: lastEventFor(order.history, 'Cancelled')?.at },
    ]
  }
  const idx = ORDER_FLOW.indexOf(order.status)
  return ORDER_FLOW.map<TimelineStep>((s, i) => ({
    status: s,
    // A delivered order is complete, so its final step is "done" rather than "current".
    state: i < idx || (i === idx && s === 'Delivered') ? 'done' : i === idx ? 'current' : 'upcoming',
    at: lastEventFor(order.history, s)?.at,
  }))
}

/** Appends a status change to an order, returning a new order (pure). */
export function applyTransition(order: Order, to: OrderStatus, at = new Date().toISOString()): Order {
  let paymentStatus = order.paymentStatus
  if (order.method === 'cod') {
    if (to === 'Delivered') paymentStatus = 'COD – Collected'
    else if (paymentStatus === 'COD – Collected') paymentStatus = 'COD – Pending'
  }
  return { ...order, status: to, paymentStatus, history: [...order.history, { status: to, at }] }
}

/** Orders saved before tracking existed have no history; synthesise a minimal one. */
export function ensureHistory(order: Order): Order {
  if (Array.isArray(order.history) && order.history.length > 0) return order
  return { ...order, history: [{ status: order.status, at: order.createdAt }] }
}
