/** The third photo is the styled hover view; two-photo products use their second view. */
export function productHoverPhoto(images: readonly string[]): string | undefined {
  return images[2] || images[1]
}

export const PRODUCT_PHOTO_LABELS = ['Cover', 'Detail', 'Hover', 'Extra'] as const
