import { describe, expect, it } from 'vitest'
import { acceptFor, detectPrivateData, formatBytes, MEDIA_LIMITS, parseInstagramUrl, safeMediaUrl, uploadKeys, validateDisplayName, validateFile } from './media'

describe('parseInstagramUrl', () => {
  it.each([
    ['https://www.instagram.com/p/CxYz123AbC/', 'post', 'CxYz123AbC'],
    ['https://instagram.com/reel/Cw9_abc-12/?igsh=tracking123', 'reel', 'Cw9_abc-12'],
    ['http://www.instagram.com/reels/AbCdE12345', 'reel', 'AbCdE12345'],
    ['instagram.com/tv/ZZZZZ99999/', 'reel', 'ZZZZZ99999'],
    ['  https://www.instagram.com/some.user/p/AAAAA11111/  ', 'post', 'AAAAA11111'],
  ])('accepts %s', (url, type, code) => {
    const r = parseInstagramUrl(url)
    expect(r?.type).toBe(type)
    expect(r?.code).toBe(code)
    expect(r?.url).toMatch(/^https:\/\/www\.instagram\.com\/(p|reel)\/[A-Za-z0-9_-]+\/$/)
    expect(r?.url).not.toContain('?')
  })
  it.each([
    '', 'not a url', 'https://www.instagram.com/', 'https://www.instagram.com/someuser/', 'https://evil.example/p/AAAAA11111/',
    'https://instagram.com.evil.example/p/AAAAA11111/', 'javascript:alert(1)', 'https://www.instagram.com/p/ab/', 'https://www.instagram.com/stories/user/123/',
  ])('rejects %s', (url) => expect(parseInstagramUrl(url)).toBeNull())
})

describe('safeMediaUrl', () => {
  it('allows https/http and site-relative paths', () => {
    expect(safeMediaUrl('https://cdn.example.com/a.jpg')).toBe('https://cdn.example.com/a.jpg')
    expect(safeMediaUrl('/gallery/a.jpg')).toBe('/gallery/a.jpg')
  })
  it.each(['javascript:alert(1)', 'data:image/svg+xml,<svg/>', '//evil.example/a.jpg', 'ftp://x.example/a.jpg', 'https://u:p@x.example/a.jpg', '/\\evil.example', '', 'blob:https://x.example/1'])('rejects %s', (v) =>
    expect(safeMediaUrl(v)).toBeNull(),
  )
})

describe('validateFile', () => {
  const f = (type: string, size: number) => ({ type, size, name: 'x' })
  it('accepts supported images and videos within limits', () => {
    expect(validateFile(f('image/jpeg', 1000), ['image'])).toBeNull()
    expect(validateFile(f('video/mp4', 1000), ['image', 'video'])).toBeNull()
  })
  it('rejects oversize files with the size in the message', () => {
    expect(validateFile(f('image/png', MEDIA_LIMITS.imageBytes + 1), ['image'])).toMatch(/5\.0 MB or smaller/)
    expect(validateFile(f('video/mp4', MEDIA_LIMITS.videoBytes + 1), ['video'])).toMatch(/smaller/)
  })
  it('rejects unsupported or disallowed kinds', () => {
    expect(validateFile(f('application/pdf', 10), ['image'])).toMatch(/Unsupported/)
    expect(validateFile(f('image/svg+xml', 10), ['image'])).toMatch(/Unsupported/) // SVG can carry script
    expect(validateFile(f('video/mp4', 10), ['image'])).toMatch(/Unsupported/)
    expect(validateFile(f('image/gif', 10), ['image', 'video'])).toMatch(/Unsupported/)
  })
  it('builds an accept attribute', () => {
    expect(acceptFor(['image'])).toContain('image/webp')
    expect(acceptFor(['image'])).not.toContain('video')
    expect(acceptFor(['image', 'video'])).toContain('video/mp4')
  })
})

describe('detectPrivateData', () => {
  it.each([
    ['Call me on 9876543210', 'phone'],
    ['my number is +91 98765 43210', 'phone'],
    ['write to me at riya@example.com', 'email'],
    ['see https://example.com/me', 'link'],
    ['Delivered to 110001', 'PIN'],
    ['order AUR-DEMO-123456', 'order number'],
    ['AWB: SCX12345678', 'tracking'],
    ['tracking SCX-DEMO-0001', 'tracking'],
    ['Flat no 12, Rose Apartments', 'address'],
  ])('flags %s', (text, what) => expect(detectPrivateData(text)).toContain(what))

  it.each([
    'Absolutely loved the drape and the colour',
    'Arrived in 3 days and the zari work is stunning',
    'Tracking was smooth and the packaging was lovely',
    'Size 38 fits perfectly, 5 stars',
    'Wore it to a wedding in Jaipur',
    '',
  ])('allows %s', (text) => expect(detectPrivateData(text)).toBeNull())
})

describe('validateDisplayName', () => {
  it.each(['Priya', 'P. S.', 'Priya S.', 'Ananya', 'A', 'Demo A.'])('accepts %s', (n) => expect(validateDisplayName(n)).toBeNull())
  it.each(['', 'Priya Sharma', 'Priya Kumari Sharma', 'Priya9', 'priya@x.com', 'A'.repeat(30), '9876543210'])('rejects %s', (n) => expect(validateDisplayName(n)).not.toBeNull())
})

describe('misc helpers', () => {
  it('formats bytes', () => {
    expect(formatBytes(2 * 1024 * 1024)).toBe('2.0 MB')
    expect(formatBytes(512)).toBe('1 KB')
  })
  it('collects only upload keys', () => {
    expect(
      uploadKeys(
        { source: 'upload', kind: 'image', value: 'm-1' },
        { source: 'url', kind: 'image', value: 'https://x.example/a.jpg' },
        { source: 'art', kind: 'image', value: 'art:x' },
        undefined,
        { source: 'upload', kind: 'video', value: 'm-2' },
      ),
    ).toEqual(['m-1', 'm-2'])
  })
})
