import { SHIPPING } from '../config'
import type { CustomerDetails, Product } from '../types'

export const cn = (...parts: (string | false | null | undefined)[]) => parts.filter(Boolean).join(' ')

const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })
export const formatPrice = (n: number) => inr.format(n)

export const discountPercent = (p: Pick<Product, 'price' | 'compareAtPrice'>) =>
  p.compareAtPrice && p.compareAtPrice > p.price
    ? Math.round(((p.compareAtPrice - p.price) / p.compareAtPrice) * 100)
    : 0

export const slugify = (s: string) =>
  s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

export const variantKey = (productId: string, size: string, color: string) => `${productId}|${size}|${color}`

export function shippingFor(subtotal: number): number {
  if (subtotal <= 0) return 0
  return subtotal >= SHIPPING.freeAbove ? 0 : SHIPPING.flatRate
}

export function stockFor(product: Product, size: string, color: string): number {
  return product.variants.find((v) => v.size === size && v.color === color)?.stock ?? 0
}

export const totalStock = (product: Product) => product.variants.reduce((n, v) => n + v.stock, 0)

export const LOW_STOCK_THRESHOLD = 25

/* ── validation (Indian formats) ───────────────────────────── */
export const MOBILE_RE = /^[6-9]\d{9}$/
export const PIN_RE = /^[1-9]\d{5}$/

export type FieldErrors = Partial<Record<keyof CustomerDetails, string>>

export function validateCustomer(c: CustomerDetails): FieldErrors {
  const e: FieldErrors = {}
  if (c.fullName.trim().length < 2) e.fullName = 'Please enter your full name.'
  if (!MOBILE_RE.test(c.mobile.replace(/\s|-/g, ''))) e.mobile = 'Enter a valid 10-digit Indian mobile number.'
  if (c.address1.trim().length < 5) e.address1 = 'Please enter your house / street address.'
  if (c.city.trim().length < 2) e.city = 'Please enter your city.'
  if (!c.state) e.state = 'Please select your state.'
  if (!PIN_RE.test(c.pincode.trim())) e.pincode = 'Enter a valid 6-digit PIN code.'
  return e
}

export const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana',
  'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana',
  'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Andaman & Nicobar Islands', 'Chandigarh',
  'Dadra & Nagar Haveli and Daman & Diu', 'Delhi', 'Jammu & Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry',
]

export function demoOrderRef(): string {
  const n = Math.floor(100000 + Math.random() * 900000)
  return `AUR-DEMO-${n}`
}

export const formatDate = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
