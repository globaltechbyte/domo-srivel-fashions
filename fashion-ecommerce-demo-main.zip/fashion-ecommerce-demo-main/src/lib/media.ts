import type { MediaKind, MediaRef } from '../types'
import { deleteMedia, putMedia, storageEstimate } from './idb'

/* ── limits (shown to admins) ─────────────────────────────── */
export const MEDIA_LIMITS = {
  imageBytes: 5 * 1024 * 1024,
  videoBytes: 25 * 1024 * 1024,
  /** Images are downscaled so their longest side is at most this many px. */
  maxImageDimension: 1600,
}
export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp']
export const VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime']

export const formatBytes = (n: number) =>
  n >= 1024 * 1024 * 1024 ? `${(n / 1024 ** 3).toFixed(1)} GB` : n >= 1024 * 1024 ? `${(n / 1024 ** 2).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`

/** Returns an error message, or null when the file is acceptable. */
export function validateFile(file: Pick<File, 'type' | 'size' | 'name'>, kinds: MediaKind[]): string | null {
  const isImage = IMAGE_TYPES.includes(file.type)
  const isVideo = VIDEO_TYPES.includes(file.type)
  if (isImage && kinds.includes('image')) {
    return file.size > MEDIA_LIMITS.imageBytes ? `Images must be ${formatBytes(MEDIA_LIMITS.imageBytes)} or smaller (this one is ${formatBytes(file.size)}).` : null
  }
  if (isVideo && kinds.includes('video')) {
    return file.size > MEDIA_LIMITS.videoBytes ? `Videos must be ${formatBytes(MEDIA_LIMITS.videoBytes)} or smaller (this one is ${formatBytes(file.size)}).` : null
  }
  const allowed = [kinds.includes('image') && 'JPG, PNG or WebP images', kinds.includes('video') && 'MP4, WebM or MOV videos'].filter(Boolean).join(' and ')
  return `Unsupported file type. Please choose ${allowed}.`
}

export const acceptFor = (kinds: MediaKind[]) =>
  [...(kinds.includes('image') ? IMAGE_TYPES : []), ...(kinds.includes('video') ? VIDEO_TYPES : [])].join(',')

/* ── URL safety ───────────────────────────────────────────── */

/** Accepts absolute http(s) URLs and site-relative paths ("/gallery/a.jpg"); rejects everything else. */
export function safeMediaUrl(raw: string | null | undefined): string | null {
  const v = (raw ?? '').trim()
  if (!v || v.length > 1000) return null
  if (v.startsWith('/') && !v.startsWith('//') && !v.includes('\\')) return v
  try {
    const u = new URL(v)
    if ((u.protocol !== 'https:' && u.protocol !== 'http:') || u.username || u.password || !u.hostname.includes('.')) return null
    return u.toString()
  } catch {
    return null
  }
}

export interface ParsedInstagram {
  url: string
  type: 'post' | 'reel'
  code: string
}

/**
 * Validates an Instagram post/reel link and returns a canonical form.
 * Accepts /p/, /reel/, /reels/, /tv/ (and the /username/p/… variant). Query strings are dropped.
 */
export function parseInstagramUrl(raw: string | null | undefined): ParsedInstagram | null {
  const v = (raw ?? '').trim()
  if (!v) return null
  let u: URL
  try {
    u = new URL(/^https?:\/\//i.test(v) ? v : `https://${v}`)
  } catch {
    return null
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null
  const host = u.hostname.toLowerCase()
  if (host !== 'instagram.com' && host !== 'www.instagram.com') return null
  const m = u.pathname.match(/^\/(?:[A-Za-z0-9._]+\/)?(p|reel|reels|tv)\/([A-Za-z0-9_-]{5,})\/?$/)
  if (!m) return null
  const type = m[1] === 'p' ? 'post' : 'reel'
  return { url: `https://www.instagram.com/${type === 'post' ? 'p' : 'reel'}/${m[2]}/`, type, code: m[2] }
}

/* ── privacy guards for customer-facing text ──────────────── */

const PRIVATE_PATTERNS: { re: RegExp; what: string }[] = [
  { re: /(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}\b/, what: 'a phone number' },
  { re: /\b\d{10,}\b/, what: 'a long number (phone or tracking code)' },
  { re: /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i, what: 'an email address' },
  { re: /\bhttps?:\/\/|\bwww\.\S+/i, what: 'a web link' },
  // Order numbers must be checked before PINs: "AUR-DEMO-123456" also looks like a 6-digit PIN.
  { re: /\bAUR-DEMO-[A-Z0-9]+/i, what: 'an order number' },
  { re: /\b[1-9]\d{2}\s?\d{3}\b/, what: 'a PIN code' },
  // A real code contains a digit, so ordinary sentences like "tracking was smooth" are not flagged.
  { re: /\b(?:awb|tracking|consignment|docket)\b[\s:#.-]{0,4}(?=[A-Z0-9-]*\d)[A-Z0-9-]{6,}/i, what: 'a tracking code' },
  { re: /\b(?:flat|house|plot|door)\s*(?:no\.?|number|#)\s*\d+/i, what: 'a street address' },
]

/** Returns a human-readable description of the first private-looking item in `text`, or null. */
export function detectPrivateData(text: string | null | undefined): string | null {
  const t = (text ?? '').trim()
  if (!t) return null
  for (const p of PRIVATE_PATTERNS) if (p.re.test(t)) return p.what
  return null
}

/** Customer display names must be a first name or initials, never a full name. */
export function validateDisplayName(name: string): string | null {
  const v = name.trim()
  if (v.length < 1) return 'Enter a first name or initials.'
  if (v.length > 24) return 'Keep it short: a first name or initials only.'
  if (/[0-9@/\\]/.test(v)) return 'Names can’t contain numbers or symbols.'
  const parts = v.split(/\s+/)
  if (parts.length > 3) return 'Use a first name or initials only, not a full name.'
  // A second word is only allowed when it is an initial ("Priya S.").
  if (parts.slice(1).some((p) => p.replace('.', '').length > 1)) return 'Use a first name or initials only, not a full name.'
  return detectPrivateData(v) ? 'This looks like private information.' : null
}

/* ── draft handling (what the admin form holds before saving) ─ */

export type MediaDraft =
  | { kind: 'existing'; ref: MediaRef }
  | { kind: 'file'; file: File; previewUrl: string; mediaKind: MediaKind }
  | { kind: 'url'; url: string }

export interface CommittedMedia {
  media: MediaRef
  /** Auto-generated poster frame for uploaded videos, when the browser could produce one. */
  poster?: MediaRef
}

async function readImage(file: Blob): Promise<ImageBitmap> {
  return createImageBitmap(file, { imageOrientation: 'from-image' })
}

/**
 * Downscales and re-encodes an image. Re-encoding through a canvas also strips EXIF
 * metadata (including GPS location), which is a useful privacy default.
 */
export async function compressImage(file: File): Promise<{ blob: Blob; width: number; height: number }> {
  const bmp = await readImage(file)
  const scale = Math.min(1, MEDIA_LIMITS.maxImageDimension / Math.max(bmp.width, bmp.height))
  const width = Math.max(1, Math.round(bmp.width * scale))
  const height = Math.max(1, Math.round(bmp.height * scale))
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  canvas.getContext('2d')?.drawImage(bmp, 0, 0, width, height)
  bmp.close?.()
  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, 'image/webp', 0.86))
  if (!blob) throw new Error('compress failed')
  return { blob, width, height }
}

/** Best-effort first-frame capture for a video file. Resolves null if the browser can't decode it. */
export function captureVideoFrame(file: File): Promise<{ blob: Blob; width: number; height: number } | null> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file)
    const video = document.createElement('video')
    let done = false
    const finish = (r: { blob: Blob; width: number; height: number } | null) => {
      if (done) return
      done = true
      URL.revokeObjectURL(url)
      resolve(r)
    }
    const timer = setTimeout(() => finish(null), 8000)
    video.muted = true
    video.playsInline = true
    video.preload = 'metadata'
    video.onerror = () => { clearTimeout(timer); finish(null) }
    video.onloadedmetadata = () => { video.currentTime = Math.min(0.5, (video.duration || 1) / 2) }
    video.onseeked = () => {
      const w = video.videoWidth
      const h = video.videoHeight
      if (!w || !h) { clearTimeout(timer); return finish(null) }
      const scale = Math.min(1, 1000 / Math.max(w, h))
      const canvas = document.createElement('canvas')
      canvas.width = Math.round(w * scale)
      canvas.height = Math.round(h * scale)
      canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height)
      canvas.toBlob((blob) => { clearTimeout(timer); finish(blob ? { blob, width: canvas.width, height: canvas.height } : null) }, 'image/jpeg', 0.82)
    }
    video.src = url
  })
}

/** Rejects early if the browser clearly doesn't have room for `bytes` more. */
export async function assertRoomFor(bytes: number): Promise<void> {
  const est = await storageEstimate()
  if (est && est.usage + bytes > est.quota * 0.9) throw new Error('Browser storage is nearly full. Delete some uploads or use smaller files.')
}

/**
 * Turns an admin draft into a persisted MediaRef. Uploads are written to IndexedDB;
 * existing refs and URLs are passed through untouched. Throws with a user-facing message.
 */
export async function commitDraft(draft: MediaDraft): Promise<CommittedMedia> {
  if (draft.kind === 'existing') return { media: draft.ref }
  if (draft.kind === 'url') {
    const url = safeMediaUrl(draft.url)
    if (!url) throw new Error('Enter a valid image URL (https://… or /path/photo.jpg).')
    return { media: { source: 'url', kind: 'image', value: url } }
  }

  const { file, mediaKind } = draft
  const problem = validateFile(file, [mediaKind])
  if (problem) throw new Error(problem)

  const written: string[] = []
  try {
    if (mediaKind === 'image') {
      let blob: Blob = file
      let width: number | undefined
      let height: number | undefined
      try {
        const c = await compressImage(file)
        blob = c.blob; width = c.width; height = c.height
      } catch {
        throw new Error('This image could not be read. Try a JPG, PNG or WebP file.')
      }
      await assertRoomFor(blob.size)
      const id = await putMedia(blob)
      written.push(id)
      return { media: { source: 'upload', kind: 'image', value: id, mimeType: blob.type, sizeBytes: blob.size, width, height } }
    }

    await assertRoomFor(file.size)
    const id = await putMedia(file)
    written.push(id)
    const media: MediaRef = { source: 'upload', kind: 'video', value: id, mimeType: file.type, sizeBytes: file.size }
    const frame = await captureVideoFrame(file)
    if (!frame) return { media }
    const posterId = await putMedia(frame.blob)
    written.push(posterId)
    media.width = frame.width
    media.height = frame.height
    return { media, poster: { source: 'upload', kind: 'image', value: posterId, mimeType: frame.blob.type, sizeBytes: frame.blob.size, width: frame.width, height: frame.height } }
  } catch (e) {
    await deleteMedia(written) // never leave half-saved files behind
    throw e instanceof Error ? e : new Error('Upload failed.')
  }
}

/** IndexedDB keys referenced by a set of media refs. */
export const uploadKeys = (...refs: (MediaRef | undefined)[]) =>
  refs.filter((r): r is MediaRef => !!r && r.source === 'upload').map((r) => r.value)
