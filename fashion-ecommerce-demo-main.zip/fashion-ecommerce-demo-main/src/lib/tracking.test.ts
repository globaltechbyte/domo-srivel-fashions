import { describe, expect, it } from 'vitest'
import { DEMO_TEST_ORDER, SAMPLE_ORDERS } from '../data/orders'
import type { Order } from '../types'
import {
  ALL_STATUSES, applyTransition, buildTimeline, canTransition, cleanShippingInfo, ensureHistory, findOrder, isTerminal, maskMobile, maskName,
  maskPincode, nextStatuses, normalizeMobile, safeTrackingUrl, validateShippingInfo, validateTrackInput,
} from './tracking'

const base = SAMPLE_ORDERS.find((o) => o.id === 'sample-1') as Order

describe('status transitions', () => {
  it('allows only forward steps and cancellation before shipping', () => {
    expect(canTransition('Pending Confirmation', 'Confirmed')).toBe(true)
    expect(canTransition('Pending Confirmation', 'Cancelled')).toBe(true)
    expect(canTransition('Packed', 'Shipped')).toBe(true)
    expect(canTransition('Packed', 'Cancelled')).toBe(true)
  })
  it('rejects skipping, going backwards, and cancelling after shipping', () => {
    expect(canTransition('Pending Confirmation', 'Shipped')).toBe(false)
    expect(canTransition('Confirmed', 'Pending Confirmation')).toBe(false)
    expect(canTransition('Shipped', 'Cancelled')).toBe(false)
    expect(canTransition('Shipped', 'Packed')).toBe(false)
  })
  it('treats Delivered and Cancelled as terminal', () => {
    expect(isTerminal('Delivered')).toBe(true)
    expect(isTerminal('Cancelled')).toBe(true)
    expect(nextStatuses('Delivered')).toEqual([])
    ALL_STATUSES.filter((s) => !isTerminal(s)).forEach((s) => expect(nextStatuses(s).length).toBeGreaterThan(0))
  })
})

describe('applyTransition', () => {
  it('appends a timestamped history event without mutating the original', () => {
    const next = applyTransition(base, 'Confirmed', '2026-01-01T10:00:00.000Z')
    expect(next.status).toBe('Confirmed')
    expect(next.history.at(-1)).toEqual({ status: 'Confirmed', at: '2026-01-01T10:00:00.000Z' })
    expect(next.history).toHaveLength(base.history.length + 1)
    expect(base.status).toBe('Pending Confirmation')
  })
  it('marks COD as collected on delivery', () => {
    expect(applyTransition({ ...base, status: 'Shipped' }, 'Delivered').paymentStatus).toBe('COD – Collected')
  })
  it('does not touch payment status for WhatsApp orders', () => {
    const wa = SAMPLE_ORDERS.find((o) => o.method === 'whatsapp' && o.status === 'Packed') as Order
    expect(applyTransition(wa, 'Shipped').paymentStatus).toBe('Not applicable')
  })
})

describe('safeTrackingUrl', () => {
  it('accepts normal http(s) links', () => {
    expect(safeTrackingUrl('https://courier.example/track/ABC123')).toBe('https://courier.example/track/ABC123')
    expect(safeTrackingUrl('  http://courier.example/t?id=1 ')).toBe('http://courier.example/t?id=1')
  })
  it.each([
    'javascript:alert(1)', 'JaVaScRiPt:alert(1)', 'data:text/html,<script>alert(1)</script>', 'vbscript:x', 'file:///etc/passwd',
    '//evil.example/x', '/relative/path', 'courier.example/track', 'https://user:pass@courier.example/x', 'https://localhost/x', '', '   ',
  ])('rejects %s', (v) => expect(safeTrackingUrl(v)).toBeNull())
  it('rejects overlong values', () => expect(safeTrackingUrl('https://a.example/' + 'x'.repeat(600))).toBeNull())
  it('handles undefined', () => expect(safeTrackingUrl(undefined)).toBeNull())
})

describe('shipping info', () => {
  it('validates the URL only when provided', () => {
    expect(validateShippingInfo({ courierName: 'A' })).toEqual({})
    expect(validateShippingInfo({ trackingUrl: 'javascript:1' }).trackingUrl).toBeTruthy()
  })
  it('cleans and drops empty values', () => {
    expect(cleanShippingInfo({ courierName: ' ', trackingNumber: '', trackingUrl: '' })).toBeUndefined()
    expect(cleanShippingInfo({ courierName: ' DHL ', trackingUrl: 'https://x.example/1' })).toEqual({ courierName: 'DHL', trackingUrl: 'https://x.example/1' })
  })
})

describe('customer lookup', () => {
  it('validates the order id and mobile formats', () => {
    expect(validateTrackInput({ ref: 'AUR-DEMO-123456', mobile: '9876543210' })).toEqual({})
    expect(validateTrackInput({ ref: 'abc', mobile: '123' })).toEqual({ ref: expect.any(String), mobile: expect.any(String) })
    expect(validateTrackInput({ ref: 'AUR-DEMO-123456', mobile: '1234567890' }).mobile).toBeTruthy()
  })
  it('normalises +91 / spaces / dashes', () => {
    expect(normalizeMobile('+91 90000-00000')).toBe('9000000000')
    expect(normalizeMobile('919000000000')).toBe('9000000000')
  })
  it('finds the demo test order (case/space-insensitive) only when BOTH fields match', () => {
    expect(findOrder(SAMPLE_ORDERS, DEMO_TEST_ORDER)?.isDemoTest).toBe(true)
    expect(findOrder(SAMPLE_ORDERS, { ref: ' aur-demo-test01 ', mobile: '+91 9000000000' })?.isDemoTest).toBe(true)
    expect(findOrder(SAMPLE_ORDERS, { ref: DEMO_TEST_ORDER.ref, mobile: '9999999999' })).toBeUndefined()
    expect(findOrder(SAMPLE_ORDERS, { ref: 'AUR-DEMO-000000', mobile: DEMO_TEST_ORDER.mobile })).toBeUndefined()
  })
})

describe('privacy masking', () => {
  it('shows first name and last initial only', () => {
    expect(maskName('Priya Kumari Sharma')).toBe('Priya S.')
    expect(maskName('Meera')).toBe('Meera')
  })
  it('masks all but the last two mobile digits and the PIN tail', () => {
    expect(maskMobile('9876543210')).toBe('••••••••10')
    expect(maskPincode('411001')).toBe('411•••')
  })
})

describe('buildTimeline', () => {
  it('marks earlier steps done, current step current, later upcoming', () => {
    const t = buildTimeline({ status: 'Packed', history: [] })
    expect(t.map((s) => s.state)).toEqual(['done', 'done', 'current', 'upcoming', 'upcoming'])
  })
  it('shows a delivered order as fully complete', () => {
    expect(buildTimeline({ status: 'Delivered', history: [] }).every((s) => s.state === 'done')).toBe(true)
  })
  it('shows only reached steps plus Cancelled for a cancelled order', () => {
    const cancelled = SAMPLE_ORDERS.find((o) => o.status === 'Cancelled') as Order
    const t = buildTimeline(cancelled)
    expect(t.map((s) => s.status)).toEqual(['Pending Confirmation', 'Confirmed', 'Cancelled'])
    expect(t.at(-1)?.state).toBe('cancelled')
  })
})

describe('history migration helper', () => {
  it('gives legacy orders a one-event history', () => {
    const legacy = { ...base, history: undefined } as unknown as Order
    const fixed = ensureHistory(legacy)
    expect(fixed.history).toEqual([{ status: base.status, at: base.createdAt }])
  })
  it('leaves orders that already have history alone', () => expect(ensureHistory(base)).toBe(base))
})

describe('sample data integrity', () => {
  it('has exactly one clearly marked demo test order', () => {
    expect(SAMPLE_ORDERS.filter((o) => o.isDemoTest)).toHaveLength(1)
  })
  it.each(SAMPLE_ORDERS.map((o) => [o.ref, o] as const))('%s has a coherent, ordered history ending in its status', (_ref, o) => {
    expect(o.history.at(-1)?.status).toBe(o.status)
    expect(o.history[0].status).toBe('Pending Confirmation')
    const times = o.history.map((e) => Date.parse(e.at))
    expect([...times].sort((a, b) => a - b)).toEqual(times)
    for (let i = 1; i < o.history.length; i++) expect(canTransition(o.history[i - 1].status, o.history[i].status)).toBe(true)
  })
  it('only uses safe tracking URLs', () => {
    SAMPLE_ORDERS.forEach((o) => o.shippingInfo?.trackingUrl && expect(safeTrackingUrl(o.shippingInfo.trackingUrl)).not.toBeNull())
  })
})
