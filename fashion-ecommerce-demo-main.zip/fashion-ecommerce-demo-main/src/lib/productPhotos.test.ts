import { describe, expect, it } from 'vitest'
import { productHoverPhoto } from './productPhotos'

describe('productHoverPhoto', () => {
  it('uses the styled third photo for three- and four-photo products', () => {
    expect(productHoverPhoto(['cover', 'detail', 'styled'])).toBe('styled')
    expect(productHoverPhoto(['cover', 'detail', 'styled', 'extra'])).toBe('styled')
  })
  it('uses the second photo when only two photos are available', () => {
    expect(productHoverPhoto(['upload:cover', 'upload:detail'])).toBe('upload:detail')
  })
  it('keeps single-photo products on their cover without an empty overlay', () => {
    expect(productHoverPhoto(['cover'])).toBeUndefined()
    expect(productHoverPhoto([])).toBeUndefined()
  })
})
