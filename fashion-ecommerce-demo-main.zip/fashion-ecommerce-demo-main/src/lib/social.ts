import type { CustomerPhoto, InstagramItem } from '../types'

export const HOME_INSTAGRAM_LIMIT = 9
export const HOME_CUSTOMER_LIMIT = 12

type Orderable = { order: number; createdAt: string }

export const byOrder = <T extends Orderable>(a: T, b: T) => a.order - b.order || a.createdAt.localeCompare(b.createdAt)

/** Items shown on the storefront: active only, in display order. */
export const publicInstagram = (items: InstagramItem[]) => items.filter((i) => i.active).sort(byOrder)

/**
 * PRIVACY GATE. A customer photo is public only if it is visible AND either
 * a clearly labelled demo example, or has both customer consent and the no-private-data check.
 */
export const isPublishable = (p: CustomerPhoto) => p.visible && (!!p.isDemo || (p.consentGiven && p.privacyChecked))
export const publicCustomerPhotos = (items: CustomerPhoto[]) => items.filter(isPublishable).sort(byOrder)

/** Moves an item up/down in display order and renumbers the whole list 1..n. */
export function moveItem<T extends Orderable & { id: string }>(items: T[], id: string, dir: -1 | 1): T[] {
  const sorted = [...items].sort(byOrder)
  const i = sorted.findIndex((x) => x.id === id)
  const j = i + dir
  if (i < 0 || j < 0 || j >= sorted.length) return items
  ;[sorted[i], sorted[j]] = [sorted[j], sorted[i]]
  const renumbered = new Map(sorted.map((x, k) => [x.id, k + 1]))
  return items.map((x) => ({ ...x, order: renumbered.get(x.id) ?? x.order }))
}

export const nextOrder = (items: Orderable[]) => (items.length ? Math.max(...items.map((i) => i.order)) + 1 : 1)

export function instagramKindLabel(i: InstagramItem): string {
  if (i.type === 'reel') return 'Reel'
  if (i.type === 'upload') return i.media?.kind === 'video' ? 'Uploaded video' : 'Uploaded photo'
  return 'Post'
}
