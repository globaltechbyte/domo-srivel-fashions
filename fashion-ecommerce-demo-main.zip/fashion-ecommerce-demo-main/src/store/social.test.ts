import { beforeEach, describe, expect, it, vi } from 'vitest'
import { SEED_CUSTOMERS, SEED_INSTAGRAM } from '../data/social'
import { isPublishable, moveItem, nextOrder, publicCustomerPhotos, publicInstagram } from '../lib/social'
import type { CustomerPhoto, InstagramItem } from '../types'

const deleted: string[][] = []
vi.mock('../lib/idb', () => ({
  deleteMedia: vi.fn(async (ids: string[]) => { deleted.push(ids) }),
  putMedia: vi.fn(),
  storageEstimate: vi.fn(),
  mediaUsage: vi.fn(),
  getMedia: vi.fn(),
}))

const { useSocial } = await import('./social')

const upload = (value: string) => ({ source: 'upload' as const, kind: 'image' as const, value })
const flushed = () => deleted.flat()

beforeEach(() => {
  deleted.length = 0
  useSocial.setState({ instagram: SEED_INSTAGRAM, customers: SEED_CUSTOMERS })
})

const photo = (over: Partial<CustomerPhoto> = {}): CustomerPhoto => ({
  id: 'x', photo: upload('m-photo'), displayName: 'Riya', city: 'Pune', productName: 'Midi Wrap Dress',
  consentGiven: true, privacyChecked: true, order: 1, visible: true, createdAt: '2026-01-01T00:00:00Z', ...over,
})

describe('customer photo privacy gate', () => {
  it('publishes only visible items with BOTH consent and the privacy check', () => {
    expect(isPublishable(photo())).toBe(true)
    expect(isPublishable(photo({ consentGiven: false }))).toBe(false)
    expect(isPublishable(photo({ privacyChecked: false }))).toBe(false)
    expect(isPublishable(photo({ visible: false }))).toBe(false)
  })
  it('lets clearly flagged demo examples through without consent', () => {
    expect(isPublishable(photo({ isDemo: true, consentGiven: false, privacyChecked: false }))).toBe(true)
    expect(isPublishable(photo({ isDemo: true, visible: false }))).toBe(false)
  })
  it('never exposes real photos lacking consent via the public selector', () => {
    const list = [photo({ id: 'a' }), photo({ id: 'b', consentGiven: false }), photo({ id: 'c', privacyChecked: false })]
    expect(publicCustomerPhotos(list).map((p) => p.id)).toEqual(['a'])
  })
  it('seed customer data is entirely labelled demo and contains no review text', () => {
    expect(SEED_CUSTOMERS.every((c) => c.isDemo && !c.review)).toBe(true)
    expect(SEED_INSTAGRAM.every((i) => i.isDemo && !i.instagramUrl)).toBe(true)
  })
})

describe('ordering and visibility', () => {
  it('sorts the public Instagram feed by order and hides inactive items', () => {
    const items: InstagramItem[] = [
      { ...SEED_INSTAGRAM[0], id: 'a', order: 3 },
      { ...SEED_INSTAGRAM[0], id: 'b', order: 1 },
      { ...SEED_INSTAGRAM[0], id: 'c', order: 2, active: false },
    ]
    expect(publicInstagram(items).map((i) => i.id)).toEqual(['b', 'a'])
  })
  it('moveItem swaps neighbours and renumbers 1..n', () => {
    const moved = moveItem([{ id: 'a', order: 5, createdAt: '1' }, { id: 'b', order: 9, createdAt: '2' }, { id: 'c', order: 12, createdAt: '3' }], 'c', -1)
    expect(Object.fromEntries(moved.map((m) => [m.id, m.order]))).toEqual({ a: 1, b: 3, c: 2 })
  })
  it('moveItem is a no-op at the edges', () => {
    const list = [{ id: 'a', order: 1, createdAt: '1' }, { id: 'b', order: 2, createdAt: '2' }]
    expect(moveItem(list, 'a', -1)).toBe(list)
    expect(moveItem(list, 'b', 1)).toBe(list)
  })
  it('nextOrder follows the highest order', () => {
    expect(nextOrder([])).toBe(1)
    expect(nextOrder([{ order: 4, createdAt: '' }, { order: 2, createdAt: '' }])).toBe(5)
  })
})

describe('social store', () => {
  it('adds, edits, toggles and moves Instagram items', () => {
    const s = useSocial.getState()
    s.saveInstagram({ ...SEED_INSTAGRAM[0], id: 'new', caption: 'Hello', order: 99 })
    expect(useSocial.getState().instagram.find((i) => i.id === 'new')?.caption).toBe('Hello')
    s.saveInstagram({ ...SEED_INSTAGRAM[0], id: 'new', caption: 'Edited', order: 99 })
    expect(useSocial.getState().instagram.filter((i) => i.id === 'new')).toHaveLength(1)
    s.setInstagramActive('new', false)
    expect(useSocial.getState().instagram.find((i) => i.id === 'new')?.active).toBe(false)
    s.moveInstagram('new', -1)
    expect(useSocial.getState().instagram.map((i) => i.order).sort((a, b) => a - b)).toEqual(Array.from({ length: 10 }, (_, k) => k + 1))
  })

  it('deletes the IndexedDB files of a removed item', () => {
    const s = useSocial.getState()
    s.saveInstagram({ ...SEED_INSTAGRAM[0], id: 'up', media: upload('m-video'), thumbnail: upload('m-thumb') })
    s.removeInstagram('up')
    expect(flushed()).toEqual(expect.arrayContaining(['m-video', 'm-thumb']))
    s.saveCustomer(photo({ id: 'cu' }))
    s.removeCustomer('cu')
    expect(flushed()).toContain('m-photo')
  })

  it('deletes only replaced files when an item is edited', () => {
    const s = useSocial.getState()
    s.saveCustomer(photo({ id: 'cu', photo: upload('old') }))
    deleted.length = 0
    s.saveCustomer(photo({ id: 'cu', photo: upload('new') }))
    expect(flushed()).toEqual(['old'])
    deleted.length = 0
    s.saveCustomer(photo({ id: 'cu', photo: upload('new'), city: 'Delhi' })) // unchanged media: nothing deleted
    expect(flushed()).toEqual([])
  })

  it('reset restores seeds and clears every uploaded file', () => {
    const s = useSocial.getState()
    s.saveCustomer(photo({ id: 'cu', photo: upload('m-1') }))
    s.reset()
    expect(flushed()).toContain('m-1')
    expect(useSocial.getState().customers).toEqual(SEED_CUSTOMERS)
    expect(useSocial.getState().instagram).toEqual(SEED_INSTAGRAM)
  })
})
