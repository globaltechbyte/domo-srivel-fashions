import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { safeStorage, storeKey } from '../lib/storage'

export interface Toast {
  id: number
  message: string
  tone: 'success' | 'info' | 'error'
  action?: { label: string; to?: string; onClick?: () => void }
}

interface UIState {
  toasts: Toast[]
  searchOpen: boolean
  navOpen: boolean
  quickViewSlug: string | null
  toast: (message: string, tone?: Toast['tone'], action?: Toast['action']) => void
  dismissToast: (id: number) => void
  setSearchOpen: (v: boolean) => void
  setNavOpen: (v: boolean) => void
  setQuickView: (slug: string | null) => void
}

let toastId = 1

export const useUI = create<UIState>()((set, get) => ({
  toasts: [],
  searchOpen: false,
  navOpen: false,
  quickViewSlug: null,
  toast: (message, tone = 'success', action) => {
    const id = toastId++
    set((s) => ({ toasts: [...s.toasts.slice(-2), { id, message, tone, action }] }))
    setTimeout(() => get().dismissToast(id), 3600)
  },
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
  setSearchOpen: (searchOpen) => set({ searchOpen }),
  setNavOpen: (navOpen) => set({ navOpen }),
  setQuickView: (quickViewSlug) => set({ quickViewSlug }),
}))

interface WishlistState {
  ids: string[]
  toggle: (id: string) => boolean
}

export const useWishlist = create<WishlistState>()(
  persist(
    (set, get) => ({
      ids: [],
      toggle: (id) => {
        const has = get().ids.includes(id)
        set({ ids: has ? get().ids.filter((x) => x !== id) : [...get().ids, id] })
        return !has
      },
    }),
    { name: storeKey('wishlist'), storage: createJSONStorage(() => safeStorage), version: 1 },
  ),
)
