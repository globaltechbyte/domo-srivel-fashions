import { beforeEach, describe, expect, it } from 'vitest'
import { SAMPLE_ORDERS } from '../data/orders'
import { useOrders } from './orders'

const get = (id: string) => useOrders.getState().orders.find((o) => o.id === id)!

beforeEach(() => useOrders.getState().reset())

describe('orders store: advance', () => {
  it('moves along the workflow and records history', () => {
    const before = get('sample-1').history.length
    expect(useOrders.getState().advance('sample-1', 'Confirmed')).toEqual({ ok: true })
    expect(get('sample-1').status).toBe('Confirmed')
    expect(get('sample-1').history).toHaveLength(before + 1)
  })
  it('rejects invalid transitions and leaves the order untouched', () => {
    const res = useOrders.getState().advance('sample-1', 'Delivered')
    expect(res.ok).toBe(false)
    expect(get('sample-1').status).toBe('Pending Confirmation')
    expect(get('sample-1').history).toHaveLength(1)
  })
  it('does not reopen cancelled or delivered orders', () => {
    expect(useOrders.getState().advance('sample-5', 'Confirmed').ok).toBe(false)
    expect(useOrders.getState().advance('sample-4', 'Shipped').ok).toBe(false)
  })
  it('reports unknown orders', () => expect(useOrders.getState().advance('nope', 'Confirmed').ok).toBe(false))
  it('walks a whole order from received to delivered', () => {
    for (const s of ['Confirmed', 'Packed', 'Shipped', 'Delivered'] as const) expect(useOrders.getState().advance('sample-1', s).ok).toBe(true)
    expect(get('sample-1').history.map((e) => e.status)).toEqual(['Pending Confirmation', 'Confirmed', 'Packed', 'Shipped', 'Delivered'])
    expect(get('sample-1').paymentStatus).toBe('COD – Collected')
  })
})

describe('orders store: shipping info', () => {
  it('saves courier details and drops unsafe URLs via validation', () => {
    expect(useOrders.getState().setShippingInfo('sample-6', { courierName: 'Demo Courier', trackingNumber: 'T1', trackingUrl: 'https://c.example/T1' }).ok).toBe(true)
    expect(get('sample-6').shippingInfo?.trackingUrl).toBe('https://c.example/T1')
    const bad = useOrders.getState().setShippingInfo('sample-6', { trackingUrl: 'javascript:alert(1)' })
    expect(bad.ok).toBe(false)
    expect(get('sample-6').shippingInfo?.trackingUrl).toBe('https://c.example/T1')
  })
  it('refuses to add shipping details to cancelled orders', () => {
    expect(useOrders.getState().setShippingInfo('sample-5', { courierName: 'X' }).ok).toBe(false)
  })
  it('clears shipping info when all fields are emptied', () => {
    useOrders.getState().setShippingInfo('sample-3', { courierName: '', trackingNumber: '', trackingUrl: '' })
    expect(get('sample-3').shippingInfo).toBeUndefined()
  })
})

describe('orders store: add / reset', () => {
  it('adds new orders on top and always has a history', () => {
    const o = { ...SAMPLE_ORDERS[1], id: 'new-1', ref: 'AUR-DEMO-999999', history: [] }
    useOrders.getState().add(o)
    expect(useOrders.getState().orders[0].id).toBe('new-1')
    expect(useOrders.getState().orders[0].history.length).toBeGreaterThan(0)
  })
  it('reset restores the sample data including the demo test order', () => {
    useOrders.getState().advance('sample-1', 'Confirmed')
    useOrders.getState().reset()
    expect(get('sample-1').status).toBe('Pending Confirmation')
    expect(useOrders.getState().orders.some((o) => o.isDemoTest)).toBe(true)
  })
})
