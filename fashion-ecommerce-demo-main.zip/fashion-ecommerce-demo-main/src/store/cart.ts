import { useMemo } from 'react'
import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { safeStorage, storeKey } from '../lib/storage'
import { shippingFor, stockFor, variantKey } from '../lib/utils'
import type { CartItem, Product } from '../types'
import { useCatalog } from './catalog'

interface CartState {
  items: CartItem[]
  drawerOpen: boolean
  /** bumps on every add so the badge can animate */
  pulse: number
  add: (product: Product, size: string, color: string, qty?: number) => { ok: boolean; reason?: string }
  remove: (key: string) => void
  setQty: (key: string, qty: number) => void
  clear: () => void
  openDrawer: () => void
  closeDrawer: () => void
}

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      drawerOpen: false,
      pulse: 0,
      add: (product, size, color, qty = 1) => {
        const available = stockFor(product, size, color)
        const key = variantKey(product.id, size, color)
        const existing = get().items.find((i) => i.key === key)
        const nextQty = (existing?.qty ?? 0) + qty
        if (available <= 0) return { ok: false, reason: 'This combination is out of stock.' }
        if (nextQty > available) return { ok: false, reason: `Only ${available} left in this size and colour.` }
        set((s) => ({
          pulse: s.pulse + 1,
          items: existing
            ? s.items.map((i) => (i.key === key ? { ...i, qty: nextQty } : i))
            : [...s.items, { key, productId: product.id, size, color, qty }],
        }))
        return { ok: true }
      },
      remove: (key) => set((s) => ({ items: s.items.filter((i) => i.key !== key) })),
      setQty: (key, qty) =>
        set((s) => ({
          items: qty <= 0 ? s.items.filter((i) => i.key !== key) : s.items.map((i) => (i.key === key ? { ...i, qty } : i)),
        })),
      clear: () => set({ items: [] }),
      openDrawer: () => set({ drawerOpen: true }),
      closeDrawer: () => set({ drawerOpen: false }),
    }),
    {
      name: storeKey('cart'),
      storage: createJSONStorage(() => safeStorage),
      version: 1,
      partialize: (s) => ({ items: s.items }),
    },
  ),
)

export interface CartLine extends CartItem {
  product: Product
  unitPrice: number
  lineTotal: number
  maxQty: number
}

/** Joins cart items with live catalog data. Items whose product was deleted are dropped. */
export function useCartLines() {
  const items = useCart((s) => s.items)
  const products = useCatalog((s) => s.products)

  return useMemo(() => {
    const lines: CartLine[] = []
    for (const item of items) {
      const product = products.find((p) => p.id === item.productId)
      if (!product) continue
      const maxQty = stockFor(product, item.size, item.color)
      lines.push({ ...item, product, unitPrice: product.price, lineTotal: product.price * item.qty, maxQty })
    }
    const subtotal = lines.reduce((n, l) => n + l.lineTotal, 0)
    const shipping = shippingFor(subtotal)
    const count = lines.reduce((n, l) => n + l.qty, 0)
    return { lines, subtotal, shipping, total: subtotal + shipping, count }
  }, [items, products])
}
