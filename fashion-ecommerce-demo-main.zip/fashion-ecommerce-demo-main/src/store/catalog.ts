import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { SEED_PRODUCTS } from '../data/products'
import { safeStorage, storeKey } from '../lib/storage'
import { totalStock } from '../lib/utils'
import type { Product } from '../types'

interface CatalogState {
  products: Product[]
  upsert: (p: Product) => void
  remove: (id: string) => void
  setVariantStock: (id: string, size: string, color: string, stock: number) => void
  reset: () => void
}

export const useCatalog = create<CatalogState>()(
  persist(
    (set) => ({
      products: SEED_PRODUCTS,
      upsert: (p) =>
        set((s) => {
          const next = { ...p, stock: totalStock(p) }
          const exists = s.products.some((x) => x.id === p.id)
          return { products: exists ? s.products.map((x) => (x.id === p.id ? next : x)) : [next, ...s.products] }
        }),
      remove: (id) => set((s) => ({ products: s.products.filter((p) => p.id !== id) })),
      setVariantStock: (id, size, color, stock) =>
        set((s) => ({
          products: s.products.map((p) => {
            if (p.id !== id) return p
            const variants = p.variants.map((v) =>
              v.size === size && v.color === color ? { ...v, stock: Math.max(0, stock) } : v,
            )
            const next = { ...p, variants }
            return { ...next, stock: totalStock(next) }
          }),
        })),
      reset: () => set({ products: SEED_PRODUCTS }),
    }),
    { name: storeKey('catalog'), storage: createJSONStorage(() => safeStorage), version: 1 },
  ),
)

export const findProduct = (products: Product[], slug: string) => products.find((p) => p.slug === slug)
