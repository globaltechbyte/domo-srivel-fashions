import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { SEED_CUSTOMERS, SEED_INSTAGRAM } from '../data/social'
import { deleteMedia } from '../lib/idb'
import { uploadKeys } from '../lib/media'
import { moveItem } from '../lib/social'
import { safeStorage, storeKey } from '../lib/storage'
import type { CustomerPhoto, InstagramItem } from '../types'

/**
 * Metadata for the two gallery modules lives in localStorage; uploaded files live in IndexedDB
 * (see lib/idb.ts) and are referenced by key. Nothing here syncs across browsers or devices.
 */
interface SocialState {
  instagram: InstagramItem[]
  customers: CustomerPhoto[]
  saveInstagram: (item: InstagramItem) => void
  removeInstagram: (id: string) => void
  moveInstagram: (id: string, dir: -1 | 1) => void
  setInstagramActive: (id: string, active: boolean) => void
  saveCustomer: (item: CustomerPhoto) => void
  removeCustomer: (id: string) => void
  moveCustomer: (id: string, dir: -1 | 1) => void
  setCustomerVisible: (id: string, visible: boolean) => void
  /** Restores demo seeds and deletes every uploaded file. */
  reset: () => void
}

const igKeys = (i?: InstagramItem) => (i ? uploadKeys(i.media, i.thumbnail) : [])
const cpKeys = (c?: CustomerPhoto) => (c ? uploadKeys(c.photo) : [])
/** Files that were referenced by `before` but are no longer referenced by `after`. */
const orphans = (before: string[], after: string[]) => before.filter((k) => !after.includes(k))

const STORE_NAME = storeKey('social')

export const useSocial = create<SocialState>()(
  persist(
    (set, get) => ({
      instagram: SEED_INSTAGRAM,
      customers: SEED_CUSTOMERS,

      saveInstagram: (item) => {
        const prev = get().instagram.find((i) => i.id === item.id)
        set((s) => ({ instagram: prev ? s.instagram.map((i) => (i.id === item.id ? item : i)) : [...s.instagram, item] }))
        void deleteMedia(orphans(igKeys(prev), igKeys(item)))
      },
      removeInstagram: (id) => {
        const prev = get().instagram.find((i) => i.id === id)
        set((s) => ({ instagram: s.instagram.filter((i) => i.id !== id) }))
        void deleteMedia(igKeys(prev))
      },
      moveInstagram: (id, dir) => set((s) => ({ instagram: moveItem(s.instagram, id, dir) })),
      setInstagramActive: (id, active) => set((s) => ({ instagram: s.instagram.map((i) => (i.id === id ? { ...i, active } : i)) })),

      saveCustomer: (item) => {
        const prev = get().customers.find((c) => c.id === item.id)
        set((s) => ({ customers: prev ? s.customers.map((c) => (c.id === item.id ? item : c)) : [...s.customers, item] }))
        void deleteMedia(orphans(cpKeys(prev), cpKeys(item)))
      },
      removeCustomer: (id) => {
        const prev = get().customers.find((c) => c.id === id)
        set((s) => ({ customers: s.customers.filter((c) => c.id !== id) }))
        void deleteMedia(cpKeys(prev))
      },
      moveCustomer: (id, dir) => set((s) => ({ customers: moveItem(s.customers, id, dir) })),
      setCustomerVisible: (id, visible) => set((s) => ({ customers: s.customers.map((c) => (c.id === id ? { ...c, visible } : c)) })),

      reset: () => {
        const { instagram, customers } = get()
        void deleteMedia([...instagram.flatMap(igKeys), ...customers.flatMap(cpKeys)])
        set({ instagram: SEED_INSTAGRAM, customers: SEED_CUSTOMERS })
      },
    }),
    { name: STORE_NAME, storage: createJSONStorage(() => safeStorage), version: 1 },
  ),
)

// Same-browser tab sync (not cross-device).
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === STORE_NAME) void useSocial.persist.rehydrate()
  })
}
