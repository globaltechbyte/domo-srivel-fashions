import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { SAMPLE_ORDERS } from '../data/orders'
import { safeStorage, storeKey } from '../lib/storage'
import { applyTransition, canTransition, cleanShippingInfo, ensureHistory, validateShippingInfo } from '../lib/tracking'
import type { Order, OrderStatus, PaymentStatus, ShippingInfo } from '../types'

export type ActionResult = { ok: true } | { ok: false; reason: string }

interface OrdersState {
  orders: Order[]
  add: (o: Order) => void
  /** Moves an order along the allowed workflow and records a timestamped history event. */
  advance: (id: string, to: OrderStatus) => ActionResult
  setShippingInfo: (id: string, info: ShippingInfo) => ActionResult
  setPayment: (id: string, payment: PaymentStatus) => void
  reset: () => void
}

const STORE_NAME = storeKey('orders')

export const useOrders = create<OrdersState>()(
  persist(
    (set, get) => ({
      orders: SAMPLE_ORDERS,
      add: (o) => set((s) => ({ orders: [ensureHistory(o), ...s.orders] })),
      advance: (id, to) => {
        const order = get().orders.find((o) => o.id === id)
        if (!order) return { ok: false, reason: 'Order not found.' }
        if (!canTransition(order.status, to)) return { ok: false, reason: `An order that is "${order.status}" cannot move to "${to}".` }
        set((s) => ({ orders: s.orders.map((o) => (o.id === id ? applyTransition(o, to) : o)) }))
        return { ok: true }
      },
      setShippingInfo: (id, info) => {
        const errs = validateShippingInfo(info)
        if (Object.keys(errs).length) return { ok: false, reason: Object.values(errs)[0] as string }
        const order = get().orders.find((o) => o.id === id)
        if (!order) return { ok: false, reason: 'Order not found.' }
        if (order.status === 'Cancelled') return { ok: false, reason: 'Cancelled orders cannot have shipping details.' }
        set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, shippingInfo: cleanShippingInfo(info) } : o)) }))
        return { ok: true }
      },
      setPayment: (id, paymentStatus) =>
        set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, paymentStatus } : o)) })),
      reset: () => set({ orders: SAMPLE_ORDERS }),
    }),
    {
      name: STORE_NAME,
      storage: createJSONStorage(() => safeStorage),
      version: 2,
      // v1 orders predate tracking: give them a minimal history and make sure the test order exists.
      migrate: (persisted, version) => {
        const state = persisted as { orders?: Order[] }
        if (version < 2 && Array.isArray(state.orders)) {
          const orders = state.orders.map(ensureHistory)
          const hasTest = orders.some((o) => o.isDemoTest)
          const test = SAMPLE_ORDERS.find((o) => o.isDemoTest)
          return { ...state, orders: hasTest || !test ? orders : [...orders, test] }
        }
        return state
      },
    },
  ),
)

/**
 * Keeps the store in sync between tabs of the SAME browser (admin in one tab, tracking in another).
 * This is a localStorage feature, not cross-device sync: other browsers/devices never see these orders.
 */
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === STORE_NAME) void useOrders.persist.rehydrate()
  })
}
