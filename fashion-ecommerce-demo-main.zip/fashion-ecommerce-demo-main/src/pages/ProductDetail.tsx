import { AnimatePresence, motion } from 'motion/react'
import { ChevronDown, Ruler, ShieldCheck, Truck } from 'lucide-react'
import { useMemo, useRef, useState, type ReactNode } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ColorSwatches, WishlistButton } from '../components/product/parts'
import { Gallery } from '../components/product/Gallery'
import { ProductCard } from '../components/product/ProductCard'
import { SizeGuide } from '../components/product/SizeGuide'
import { SizeSelector } from '../components/product/SizeSelector'
import { Button, ButtonLink } from '../components/ui/Button'
import { WhatsAppIcon } from '../components/ui/BrandIcons'
import { EmptyState, Price, QuantityStepper, Reveal } from '../components/ui/primitives'
import { SHIPPING, WHATSAPP_IS_PLACEHOLDER } from '../config'
import { categoryLabel } from '../data/products'
import { useAddToCart } from '../hooks/useAddToCart'
import { useDocumentTitle } from '../hooks/useMisc'
import { formatPrice, shippingFor, stockFor } from '../lib/utils'
import { buildWhatsAppMessage, whatsappUrl } from '../lib/whatsapp'
import { useCatalog } from '../store/catalog'
import { useUI } from '../store/ui'

function Accordion({ title, children, defaultOpen }: { title: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(!!defaultOpen)
  return (
    <div className="border-b border-line">
      <button onClick={() => setOpen((o) => !o)} aria-expanded={open} className="flex min-h-14 w-full items-center justify-between text-left text-[13px] font-medium uppercase tracking-[0.14em]">
        {title}
        <ChevronDown size={18} className={`transition-transform duration-300 ${open ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
            <div className="pb-5 text-[15px] leading-relaxed text-ink-soft">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function ProductDetail() {
  const { slug } = useParams()
  const products = useCatalog((s) => s.products)
  const product = products.find((p) => p.slug === slug)
  useDocumentTitle(product?.name ?? 'Not found')

  if (!product) {
    return (
      <EmptyState
        title="We couldn't find that piece"
        body="It may have been moved or is no longer available. Explore the rest of the collection."
        action={<ButtonLink to="/shop">Back to shop</ButtonLink>}
      />
    )
  }
  return <Detail key={product.id} productId={product.id} />
}

function Detail({ productId }: { productId: string }) {
  const products = useCatalog((s) => s.products)
  const product = products.find((p) => p.id === productId)!
  const addToCart = useAddToCart()
  const toast = useUI((s) => s.toast)

  const [color, setColor] = useState(product.colors[0]?.name ?? '')
  const [size, setSize] = useState(product.sizes.length === 1 ? product.sizes[0] : '')
  const [qty, setQty] = useState(1)
  const [sizeError, setSizeError] = useState(false)
  const [guide, setGuide] = useState(false)
  const sizeRef = useRef<HTMLDivElement>(null)

  const hex = product.colors.find((c) => c.name === color)?.hex
  const available = size ? stockFor(product, size, color) : null
  const colorStock = product.variants.filter((v) => v.color === color).reduce((n, v) => n + v.stock, 0)

  const related = useMemo(
    () => products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4),
    [products, product],
  )

  const requireSize = () => {
    if (size) return true
    setSizeError(true)
    sizeRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    toast('Please select a size first', 'error')
    return false
  }

  const handleAdd = () => {
    if (!requireSize()) return
    addToCart(product, size, color, qty)
  }

  const handleWhatsApp = () => {
    if (!requireSize()) return
    const sub = product.price * qty
    const ship = shippingFor(sub)
    const msg = buildWhatsAppMessage({
      lines: [{ productId: product.id, name: product.name, size, color, qty, unitPrice: product.price }],
      subtotal: sub,
      shipping: ship,
      total: sub + ship,
    })
    window.open(whatsappUrl(msg), '_blank', 'noopener,noreferrer')
  }

  const soldOut = product.stock <= 0
  const stockLine =
    available === null
      ? colorStock > 0
        ? { text: 'In stock — select a size', cls: 'text-ok' }
        : { text: 'Out of stock in this colour', cls: 'text-bad' }
      : available <= 0
        ? { text: 'Out of stock in this size', cls: 'text-bad' }
        : available <= 3
          ? { text: `Only ${available} left`, cls: 'text-warn' }
          : { text: 'In stock', cls: 'text-ok' }

  return (
    <div className="container-x pb-32 pt-6 lg:pb-10 lg:pt-10">
      <nav aria-label="Breadcrumb" className="mb-6 text-[13px] text-ink-soft">
        <ol className="flex flex-wrap items-center gap-2">
          <li><Link to="/" className="hover:text-rose">Home</Link></li>
          <li aria-hidden="true">/</li>
          <li><Link to={`/shop?category=${product.category}`} className="hover:text-rose">{categoryLabel(product.category)}</Link></li>
          <li aria-hidden="true">/</li>
          <li aria-current="page" className="text-charcoal">{product.name}</li>
        </ol>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
        <Gallery product={product} hex={hex} />

        <div className="lg:sticky lg:top-28 lg:self-start">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="eyebrow mb-3">{categoryLabel(product.category)}</p>
              <h1 className="text-[2.4rem] leading-[1.05] md:text-5xl">{product.name}</h1>
            </div>
            <WishlistButton productId={product.id} name={product.name} className="shrink-0 border border-line" />
          </div>
          <div className="mt-4"><Price product={product} size="lg" /></div>
          <p className="mt-1 text-[13px] text-ink-soft">Inclusive of all taxes (sample)</p>

          <div className="mt-8">
            <p className="mb-3 text-sm">Colour: <span className="font-medium">{color}</span></p>
            <ColorSwatches colors={product.colors} selected={color} onSelect={(c) => { setColor(c); if (size && stockFor(product, size, c) <= 0) setSize('') }} size="lg" />
          </div>

          <motion.div ref={sizeRef} className="mt-7" animate={sizeError ? { x: [0, -7, 7, -4, 4, 0] } : { x: 0 }} transition={{ duration: 0.4 }} onAnimationComplete={() => sizeError && setTimeout(() => setSizeError(false), 1200)}>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm">Size: <span className="font-medium">{size || 'Select a size'}</span></p>
              <button onClick={() => setGuide(true)} className="flex min-h-11 items-center gap-1.5 text-sm underline underline-offset-4 hover:text-rose">
                <Ruler size={16} /> Size guide
              </button>
            </div>
            <SizeSelector product={product} color={color} selected={size} onSelect={(s) => { setSize(s); setSizeError(false) }} error={sizeError} />
            {sizeError && <p role="alert" className="mt-2 text-sm text-bad">Please select a size to continue.</p>}
          </motion.div>

          <p className={`mt-5 flex items-center gap-2 text-sm font-medium ${stockLine.cls}`} aria-live="polite">
            <span className="size-2 rounded-full bg-current" /> {stockLine.text}
          </p>

          <div className="mt-6 flex items-center gap-4">
            <QuantityStepper value={qty} onChange={setQty} max={Math.max(1, available ?? 10)} />
            <Button size="lg" className="flex-1" onClick={handleAdd} disabled={soldOut || available === 0}>
              {soldOut ? 'Sold out' : 'Add to bag'}
            </Button>
          </div>
          <Button variant="outline" size="md" className="mt-3 w-full" onClick={handleWhatsApp} disabled={soldOut || available === 0}>
            <WhatsAppIcon /> Buy via WhatsApp
          </Button>
          {WHATSAPP_IS_PLACEHOLDER && (
            <p className="mt-2 text-[12px] text-ink-soft">Demo: the WhatsApp number is a placeholder. Set yours in src/config.ts.</p>
          )}

          <ul className="mt-8 space-y-3 border-y border-line py-6 text-sm">
            <li className="flex gap-3"><Truck size={20} strokeWidth={1.5} className="mt-0.5 shrink-0 text-rose" /><span>Delivery in {SHIPPING.eta}. Free shipping above {formatPrice(SHIPPING.freeAbove)}, otherwise {formatPrice(SHIPPING.flatRate)}.</span></li>
            <li className="flex gap-3"><ShieldCheck size={20} strokeWidth={1.5} className="mt-0.5 shrink-0 text-rose" /><span>Cash on Delivery available. Orders are confirmed by our team before dispatch.</span></li>
          </ul>

          <div className="mt-2">
            <Accordion title="Description" defaultOpen><p>{product.description}</p></Accordion>
            <Accordion title="Fabric & care">
              <p className="mb-3"><span className="font-medium text-charcoal">Fabric:</span> {product.fabric}</p>
              <ul className="list-disc space-y-1 pl-5">{product.care.map((c) => <li key={c}>{c}</li>)}</ul>
            </Accordion>
            <Accordion title="Delivery & exchanges">
              <p>Shipped across India in {SHIPPING.eta}. Unused items with tags may be exchanged within 7 days (sample policy). Message us on WhatsApp to start an exchange.</p>
            </Accordion>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24 md:mt-32" aria-labelledby="rel-h">
          <h2 id="rel-h" className="mb-8 text-4xl md:text-5xl">You may also love</h2>
          <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:gap-x-6 lg:grid-cols-4">
            {related.map((p, i) => <Reveal key={p.id} delay={i * 0.06}><ProductCard product={p} /></Reveal>)}
          </div>
        </section>
      )}

      {/* Mobile sticky purchase bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-ivory/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur lg:hidden">
        <div className="mx-auto flex max-w-xl items-center gap-4">
          <div className="min-w-0">
            <p className="truncate text-[13px] text-ink-soft">{size ? `${color} · ${size}` : color}</p>
            <p className="font-medium tabular-nums">{formatPrice(product.price * qty)}</p>
          </div>
          <Button size="md" className="flex-1" onClick={handleAdd} disabled={soldOut || available === 0}>
            {soldOut ? 'Sold out' : size ? 'Add to bag' : 'Select size'}
          </Button>
        </div>
      </div>

      <SizeGuide open={guide} onClose={() => setGuide(false)} />
    </div>
  )
}
