import { motion, useScroll, useTransform } from 'motion/react'
import { ArrowRight, Check, RefreshCcw, Truck } from 'lucide-react'
import { useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button, ButtonLink } from '../components/ui/Button'
import { WhatsAppIcon } from '../components/ui/BrandIcons'
import { FashionImage } from '../components/ui/FashionImage'
import { HeroArt } from '../components/ui/ProductArt'
import { Reveal, SectionHeading } from '../components/ui/primitives'
import { ProductCard } from '../components/product/ProductCard'
import { ProductCarousel } from '../components/product/ProductCarousel'
import { CustomerGallery } from '../components/social/CustomerGallery'
import { InstagramGallery } from '../components/social/InstagramGallery'
import { CATEGORY_ART, VALUES } from '../data/content'
import { CATEGORIES } from '../data/products'
import { useDocumentTitle } from '../hooks/useMisc'
import { BRAND } from '../config'
import { makeArt } from '../lib/art'
import { useCatalog } from '../store/catalog'

const EASE = [0.22, 1, 0.36, 1] as const

function HeroLine({ children, delay }: { children: React.ReactNode; delay: number }) {
  return (
    <span className="block overflow-hidden pb-[0.12em]">
      <motion.span className="block" initial={{ y: '105%' }} animate={{ y: 0 }} transition={{ duration: 0.9, delay, ease: EASE }}>
        {children}
      </motion.span>
    </span>
  )
}

function Hero() {
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '12%'])

  return (
    <section ref={ref} className="relative isolate overflow-hidden bg-[#3a1f29]" aria-label="Featured collection">
      <div className="relative min-h-[calc(100svh-104px)] md:min-h-[min(86vh,820px)]">
        <motion.div className="absolute inset-0 -z-10" style={{ y }} initial={{ scale: 1.1 }} animate={{ scale: 1 }} transition={{ duration: 1.8, ease: EASE }}>
          <div className="h-full w-full scale-[1.04] md:hidden">
            <HeroArt viewBox="660 0 760 900" />
          </div>
          <div className="hidden h-full w-full scale-[1.04] md:block">
            <HeroArt />
          </div>
        </motion.div>
        {/* readability scrims */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-[#24121a]/90 via-[#24121a]/25 to-transparent md:hidden" />
        <div className="absolute inset-0 -z-10 hidden bg-gradient-to-r from-[#24121a]/85 via-[#24121a]/45 to-transparent md:block" />

        <div className="container-x flex min-h-[inherit] items-end pb-14 pt-24 md:items-center md:pb-0 md:pt-0">
          <div className="max-w-xl text-white">
            <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.2 }} className="mb-5 text-[11px] font-medium uppercase tracking-[0.3em] text-[#f0cfc0]">
              The Autumn–Winter Edit
            </motion.p>
            <h1 className="text-[3.1rem] leading-[0.98] sm:text-6xl md:text-7xl lg:text-[5.4rem]">
              <HeroLine delay={0.3}>Elegance, Woven</HeroLine>
              <HeroLine delay={0.42}>
                Into Every <em className="font-normal italic text-[#f3d4c4]">Moment.</em>
              </HeroLine>
            </h1>
            <motion.p initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.75, ease: EASE }} className="mt-6 max-w-md text-base leading-relaxed text-white/85 md:text-lg">
              Discover timeless silhouettes, modern femininity, and effortless everyday luxury.
            </motion.p>
            <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.9, ease: EASE }} className="mt-9 flex flex-col gap-3 sm:flex-row">
              <ButtonLink to="/shop" size="lg" variant="light">
                Shop Collection
              </ButtonLink>
              <ButtonLink to="/shop?new=1&sort=newest" size="lg" variant="outline" className="!border-white/80 !text-white hover:!bg-white hover:!text-charcoal">
                Explore New Arrivals
              </ButtonLink>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

function TrustStrip() {
  const items = [
    { i: <Truck size={20} strokeWidth={1.5} />, t: 'Complimentary shipping', s: 'On selected orders' },
    { i: <Check size={20} strokeWidth={1.5} />, t: 'Cash on Delivery', s: 'Pay when it arrives' },
    { i: <WhatsAppIcon />, t: 'Order on WhatsApp', s: 'Personal styling help' },
    { i: <RefreshCcw size={20} strokeWidth={1.5} />, t: 'Easy exchanges', s: 'Sample 7-day policy' },
  ]
  return (
    <div className="border-b border-line bg-white">
      <ul className="container-x grid grid-cols-2 gap-y-5 py-6 lg:grid-cols-4">
        {items.map((x) => (
          <li key={x.t} className="flex items-center gap-3">
            <span className="grid size-11 shrink-0 place-items-center rounded-full bg-rose-mist text-rose">{x.i}</span>
            <span className="leading-tight">
              <span className="block text-[14px] font-medium">{x.t}</span>
              <span className="block text-[13px] text-ink-soft">{x.s}</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function Categories() {
  return (
    <section className="container-x pt-20 md:pt-28" aria-labelledby="cat-h">
      <SectionHeading eyebrow="Shop by category" title="Find your silhouette" />
      <h2 id="cat-h" className="sr-only">Categories</h2>
      <div className="grid grid-cols-2 gap-3 md:gap-5 lg:grid-cols-3">
        {CATEGORIES.map((c, i) => (
          <Reveal key={c.slug} delay={(i % 3) * 0.08}>
            <Link to={`/shop?category=${c.slug}`} className="group relative block aspect-[4/5] overflow-hidden bg-sand lg:aspect-[5/6]">
              <div className="h-full w-full transition-transform duration-[900ms] ease-out group-hover:scale-[1.06]">
                <FashionImage src={CATEGORY_ART[c.slug]} alt={`${c.label} collection`} category={c.slug} />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/5 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-4 text-white md:p-6">
                <div>
                  <h3 className="text-[1.65rem] leading-none md:text-4xl">{c.label}</h3>
                  <p className="mt-1.5 hidden text-sm text-white/80 md:block">{c.blurb}</p>
                </div>
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-white/20 backdrop-blur transition-all duration-300 group-hover:bg-white group-hover:text-charcoal md:size-11">
                  <ArrowRight size={18} />
                </span>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  )
}

function NewArrivals() {
  const products = useCatalog((s) => s.products)
  const items = useMemo(() => products.filter((p) => p.isNew).slice(0, 8), [products])
  return (
    <section className="container-x pt-24 md:pt-32" aria-labelledby="new-h">
      <SectionHeading
        eyebrow="Just landed"
        title="New Arrivals"
        action={
          <Link to="/shop?new=1&sort=newest" className="hidden shrink-0 items-center gap-2 text-sm underline-offset-4 hover:text-rose hover:underline md:inline-flex">
            View all <ArrowRight size={16} />
          </Link>
        }
      />
      <h2 id="new-h" className="sr-only">New arrivals</h2>
      <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:gap-x-6 lg:grid-cols-4">
        {items.map((p, i) => (
          <Reveal key={p.id} delay={(i % 4) * 0.07}>
            <ProductCard product={p} priority={i < 4} />
          </Reveal>
        ))}
      </div>
      <div className="mt-10 text-center md:hidden">
        <ButtonLink to="/shop?new=1&sort=newest" variant="outline">View all new arrivals</ButtonLink>
      </div>
    </section>
  )
}

function FeaturedCollection() {
  return (
    <section className="mt-24 bg-sand md:mt-32" aria-labelledby="feat-h">
      <div className="container-x grid items-center gap-10 py-16 md:py-24 lg:grid-cols-2 lg:gap-20">
        <Reveal className="relative">
          <div className="aspect-[4/5] overflow-hidden">
            <FashionImage src={makeArt({ category: 'occasion-wear', pattern: 'butti', view: 'styled', hex: '#7A1F2B' })} alt="Festive Edit lehenga" category="occasion-wear" />
          </div>
          <div className="absolute -bottom-6 right-4 hidden w-40 border-[6px] border-sand md:block lg:-right-8 lg:w-52">
            <div className="aspect-[3/4]">
              <FashionImage src={makeArt({ category: 'sarees', pattern: 'butti', view: 'detail', hex: '#1F5B4A' })} alt="Zari detail" category="sarees" />
            </div>
          </div>
        </Reveal>
        <Reveal delay={0.1} className="lg:pr-6">
          <p className="eyebrow mb-4">The Festive Edit</p>
          <h2 id="feat-h" className="text-[2.6rem] leading-[1.02] md:text-6xl">
            Crafted for the Woman <em className="italic text-rose">You Are.</em>
          </h2>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink-soft">
            Zari, silk and softly structured silhouettes, designed for the weddings, festivals and evenings that matter. Every piece is made to be worn, remembered and passed on.
          </p>
          <ul className="mt-8 space-y-3 text-[15px]">
            {['Hand-finished zari and thread detailing', 'Silhouettes that flatter and move with you', 'Cash on Delivery and WhatsApp ordering'].map((t) => (
              <li key={t} className="flex items-center gap-3">
                <span className="grid size-6 place-items-center rounded-full bg-rose text-white"><Check size={14} /></span>
                {t}
              </li>
            ))}
          </ul>
          <ButtonLink to="/collections" size="lg" className="mt-10">
            Explore the Collection
          </ButtonLink>
        </Reveal>
      </div>
    </section>
  )
}

function Bestsellers() {
  const products = useCatalog((s) => s.products)
  const items = useMemo(() => {
    const best = products.filter((p) => p.isBestseller)
    return best.length >= 4 ? best : products.filter((p) => p.isFeatured)
  }, [products])
  return (
    <section className="container-x overflow-hidden pt-24 md:pt-32" aria-labelledby="best-h">
      <SectionHeading eyebrow="Most loved" title="Bestsellers" />
      <h2 id="best-h" className="sr-only">Bestsellers</h2>
      <Reveal>
        <ProductCarousel products={items} />
      </Reveal>
    </section>
  )
}

function BrandStory() {
  return (
    <section className="container-x pt-24 md:pt-32" aria-labelledby="story-h">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-20">
        <Reveal>
          <p className="eyebrow mb-4">Our philosophy</p>
          <h2 id="story-h" className="text-[2.4rem] leading-[1.04] md:text-6xl">
            Quiet luxury, rooted in Indian craft.
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-ink-soft">
            {BRAND.name} began with a simple belief: the clothes you reach for most should also be the ones that make you feel your best. We design with intention, with fabric first, finishing next, and always for comfort.
          </p>
        </Reveal>
        <div className="grid gap-px overflow-hidden border border-line bg-line sm:grid-cols-2">
          {VALUES.map((v, i) => (
            <Reveal key={v.title} delay={i * 0.06} className="bg-ivory p-7 md:p-9">
              <span className="font-serif text-4xl italic text-rose/70">0{i + 1}</span>
              <h3 className="mt-2 text-3xl">{v.title}</h3>
              <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">{v.body}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

function Newsletter() {
  const [done, setDone] = useState(false)
  return (
    <section className="container-x pt-24 md:pt-32" aria-labelledby="news-h">
      <div className="bg-rose-mist px-6 py-14 text-center md:px-16 md:py-20">
        <p className="eyebrow mb-3">Stay in the loop</p>
        <h2 id="news-h" className="mx-auto max-w-xl text-4xl md:text-5xl">First access to new collections</h2>
        <form
          className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault()
            setDone(true)
          }}
        >
          <label htmlFor="news-email" className="sr-only">Email address</label>
          <input id="news-email" type="email" required placeholder="Your email address" className="field flex-1" />
          <Button type="submit" size="md">Subscribe</Button>
        </form>
        <p className="mt-4 min-h-6 text-[13px] text-ink-soft" role="status">
          {done ? 'Demo only — nothing was saved or sent. Connect an email service to go live.' : 'Visual demo — sign-ups are not stored.'}
        </p>
      </div>
    </section>
  )
}

export default function Home() {
  useDocumentTitle('')
  return (
    <>
      <Hero />
      <TrustStrip />
      <Categories />
      <NewArrivals />
      <FeaturedCollection />
      <Bestsellers />
      <BrandStory />
      <CustomerGallery />
      <InstagramGallery />
      <Newsletter />
    </>
  )
}
