import { motion } from 'motion/react'
import { CheckCircle2, Clock, MessageCircle } from 'lucide-react'
import { useParams } from 'react-router-dom'
import { ButtonLink, Button } from '../components/ui/Button'
import { WhatsAppIcon } from '../components/ui/BrandIcons'
import { EmptyState } from '../components/ui/primitives'
import { SummaryRows } from '../components/product/CartParts'
import { WHATSAPP_IS_PLACEHOLDER } from '../config'
import { useDocumentTitle } from '../hooks/useMisc'
import { formatDate, formatPrice } from '../lib/utils'
import { buildWhatsAppMessage, whatsappUrl } from '../lib/whatsapp'
import { useOrders } from '../store/orders'

export default function OrderConfirmation() {
  const { id } = useParams()
  const order = useOrders((s) => s.orders.find((o) => o.id === id))
  useDocumentTitle(order ? order.ref : 'Order')

  if (!order) {
    return (
      <div className="container-x py-16">
        <EmptyState title="Order not found" body="This demo order isn't stored in this browser." action={<ButtonLink to="/shop">Continue shopping</ButtonLink>} />
      </div>
    )
  }

  const isWa = order.method === 'whatsapp'
  const c = order.customer
  const reopen = () => {
    const msg = buildWhatsAppMessage({ ref: order.ref, lines: order.lines, subtotal: order.subtotal, shipping: order.shipping, total: order.total, customer: { ...c, mobile: `+91 ${c.mobile}` } })
    window.open(whatsappUrl(msg), '_blank', 'noopener,noreferrer')
  }

  return (
    <div className="container-x pb-8 pt-10 md:pt-16">
      <div className="mx-auto max-w-3xl">
        <div className="mb-8 border border-dashed border-rose/50 bg-rose-mist px-4 py-3 text-center text-sm">
          <strong>DEMO ORDER</strong> — saved only in this browser. No business has received this order and no payment was taken.
        </div>

        <div className="text-center">
          <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 300, damping: 18 }} className={`mx-auto mb-6 grid size-20 place-items-center rounded-full ${isWa ? 'bg-[#e4f3ea] text-[#25804d]' : 'bg-rose-mist text-rose'}`}>
            {isWa ? <MessageCircle size={36} strokeWidth={1.4} /> : <CheckCircle2 size={38} strokeWidth={1.4} />}
          </motion.div>
          <h1 className="text-4xl md:text-6xl">{isWa ? 'One more step: send it on WhatsApp' : 'Demo order placed'}</h1>
          <p className="mx-auto mt-4 max-w-xl text-ink-soft">
            {isWa
              ? 'We opened WhatsApp with your order pre-filled. Please press send there. Your order is not confirmed until the store replies and agrees availability and payment.'
              : 'This simulates how a Cash on Delivery order would look. In a live store, the team would now call or message to confirm.'}
          </p>
          <p className="mt-6 text-sm text-ink-soft">Demo order number</p>
          <p className="font-serif text-3xl tracking-wide">{order.ref}</p>
        </div>

        {isWa && (
          <div className="mt-8 space-y-3 bg-sand p-6">
            <ol className="list-decimal space-y-2 pl-5 text-[15px]">
              <li>Open the WhatsApp chat (it should have opened in a new tab).</li>
              <li>Review the message and press <strong>Send</strong>.</li>
              <li>Wait for the store to confirm availability and payment details.</li>
            </ol>
            <Button onClick={reopen} className="mt-2 w-full sm:w-auto"><WhatsAppIcon /> Open WhatsApp again</Button>
            {WHATSAPP_IS_PLACEHOLDER && <p className="text-[13px] text-ink-soft">Demo note: the WhatsApp number is a placeholder, set yours in src/config.ts.</p>}
          </div>
        )}

        <div className="mt-10 grid gap-8 md:grid-cols-2">
          <section aria-labelledby="od-h">
            <h2 id="od-h" className="mb-4 text-3xl">Order details</h2>
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between gap-4"><dt className="text-ink-soft">Payment method</dt><dd>{isWa ? 'WhatsApp order (payment arranged in chat)' : 'Cash on Delivery'}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-ink-soft">Status</dt><dd className="inline-flex items-center gap-1.5 font-medium text-warn"><Clock size={15} /> {order.status}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-ink-soft">Placed</dt><dd>{formatDate(order.createdAt)}</dd></div>
            </dl>
          </section>
          <section aria-labelledby="dd-h">
            <h2 id="dd-h" className="mb-4 text-3xl">Delivering to</h2>
            <address className="text-sm not-italic leading-relaxed">
              <p className="font-medium">{c.fullName}</p>
              <p>{c.address1}{c.address2 && `, ${c.address2}`}</p>
              {c.landmark && <p>Landmark: {c.landmark}</p>}
              <p>{c.city}, {c.state} – {c.pincode}</p>
              <p className="mt-1">+91 {c.mobile}</p>
            </address>
          </section>
        </div>

        <section className="mt-10 border-t border-line pt-8" aria-labelledby="os-h">
          <h2 id="os-h" className="mb-2 text-3xl">Order summary</h2>
          <ul className="divide-y divide-line">
            {order.lines.map((l, i) => (
              <li key={i} className="flex justify-between gap-4 py-4 text-sm">
                <span>
                  <span className="block">{l.name}</span>
                  <span className="text-ink-soft">{l.color} · Size {l.size} · Qty {l.qty}</span>
                </span>
                <span className="tabular-nums">{formatPrice(l.unitPrice * l.qty)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4"><SummaryRows subtotal={order.subtotal} shipping={order.shipping} total={order.total} /></div>
        </section>

        <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
          <ButtonLink to={`/track-order?ref=${encodeURIComponent(order.ref)}`} size="lg">Track this order</ButtonLink>
          <ButtonLink to="/shop" size="lg" variant="outline">Continue shopping</ButtonLink>
          <ButtonLink to="/admin-demo/orders" size="lg" variant="ghost">See it in the admin demo</ButtonLink>
        </div>
      </div>
    </div>
  )
}
