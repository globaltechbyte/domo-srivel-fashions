import { AlertTriangle, Clock, Package, ShoppingBag } from 'lucide-react'
import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { FashionImage } from '../../components/ui/FashionImage'
import { useDocumentTitle } from '../../hooks/useMisc'
import { recolor } from '../../lib/art'
import { formatDate, formatPrice, LOW_STOCK_THRESHOLD, totalStock } from '../../lib/utils'
import { useCatalog } from '../../store/catalog'
import { useOrders } from '../../store/orders'
import { Card, PageTitle, StatusBadge } from './parts'

function StatCard({ icon, label, value, hint, to }: { icon: React.ReactNode; label: string; value: string | number; hint?: string; to?: string }) {
  const body = (
    <Card className="h-full p-5 transition-shadow hover:shadow-md">
      <div className="flex items-center justify-between text-ink-soft">
        <span className="text-sm">{label}</span>
        {icon}
      </div>
      <p className="mt-3 font-serif text-5xl tabular-nums">{value}</p>
      {hint && <p className="mt-1 text-[13px] text-ink-soft">{hint}</p>}
    </Card>
  )
  return to ? <Link to={to} className="block">{body}</Link> : body
}

function SalesChart({ data }: { data: { label: string; value: number }[] }) {
  const max = Math.max(...data.map((d) => d.value), 1)
  const W = 560
  const H = 200
  const bw = W / data.length
  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H + 30}`} className="w-full" role="img" aria-label="Bar chart of order value over the last 7 days">
        <title>Order value, last 7 days (illustrative)</title>
        {[0.25, 0.5, 0.75, 1].map((t) => (
          <line key={t} x1="0" x2={W} y1={H - H * t} y2={H - H * t} stroke="#e7ded7" strokeDasharray="3 4" />
        ))}
        {data.map((d, i) => {
          const h = (d.value / max) * (H - 10)
          return (
            <g key={d.label}>
              <rect x={i * bw + bw * 0.22} y={H - h} width={bw * 0.56} height={Math.max(h, 2)} fill="#8E5362" opacity={d.value ? 1 : 0.25} rx="1" />
              <text x={i * bw + bw / 2} y={H + 20} textAnchor="middle" fontSize="12" fill="#5e5651">{d.label}</text>
            </g>
          )
        })}
      </svg>
      <figcaption className="sr-only">
        {data.map((d) => `${d.label}: ${formatPrice(d.value)}`).join('; ')}
      </figcaption>
    </figure>
  )
}

export default function Dashboard() {
  useDocumentTitle('Admin demo')
  const products = useCatalog((s) => s.products)
  const orders = useOrders((s) => s.orders)

  const stats = useMemo(() => {
    const live = orders.filter((o) => o.status !== 'Cancelled')
    const pending = orders.filter((o) => o.status === 'Pending Confirmation').length
    const low = products.filter((p) => totalStock(p) <= LOW_STOCK_THRESHOLD).sort((a, b) => totalStock(a) - totalStock(b))
    const revenue = live.reduce((n, o) => n + o.total, 0)

    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date()
      d.setHours(0, 0, 0, 0)
      d.setDate(d.getDate() - (6 - i))
      return d
    })
    const chart = days.map((d) => {
      const next = new Date(d)
      next.setDate(next.getDate() + 1)
      const value = live.filter((o) => { const t = new Date(o.createdAt); return t >= d && t < next }).reduce((n, o) => n + o.total, 0)
      return { label: d.toLocaleDateString('en-IN', { weekday: 'short' }), value }
    })
    return { pending, low, revenue, chart, aov: live.length ? Math.round(revenue / live.length) : 0 }
  }, [products, orders])

  return (
    <>
      <PageTitle title="Dashboard" sub="A snapshot of the demo store. All figures come from mock and locally simulated data." />
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4 md:gap-5">
        <StatCard icon={<Package size={18} />} label="Total products" value={products.length} to="/admin-demo/products" />
        <StatCard icon={<ShoppingBag size={18} />} label="Demo orders" value={orders.length} to="/admin-demo/orders" />
        <StatCard icon={<Clock size={18} />} label="Pending confirmations" value={stats.pending} hint="Awaiting action" to="/admin-demo/orders" />
        <StatCard icon={<AlertTriangle size={18} />} label="Low-stock products" value={stats.low.length} hint={`${LOW_STOCK_THRESHOLD} units or fewer`} to="/admin-demo/products" />
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.5fr_1fr]">
        <Card className="p-5 md:p-6">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
            <div>
              <h2 className="text-2xl">Sales summary</h2>
              <p className="text-[13px] text-ink-soft">Illustrative — last 7 days, excluding cancelled orders</p>
            </div>
            <div className="text-right">
              <p className="font-serif text-3xl tabular-nums">{formatPrice(stats.revenue)}</p>
              <p className="text-[13px] text-ink-soft">Avg. order {formatPrice(stats.aov)}</p>
            </div>
          </div>
          <SalesChart data={stats.chart} />
        </Card>

        <Card className="p-5 md:p-6">
          <h2 className="mb-4 text-2xl">Low stock</h2>
          {stats.low.length === 0 ? (
            <p className="text-sm text-ink-soft">All products are well stocked.</p>
          ) : (
            <ul className="divide-y divide-line">
              {stats.low.slice(0, 6).map((p) => (
                <li key={p.id} className="flex items-center gap-3 py-3">
                  <div className="w-10 shrink-0 overflow-hidden bg-sand"><div className="aspect-[3/4]"><FashionImage src={recolor(p.images[0], p.colors[0].hex)} alt="" category={p.category} /></div></div>
                  <span className="min-w-0 flex-1 truncate text-sm">{p.name}</span>
                  <span className={`text-sm font-medium tabular-nums ${totalStock(p) === 0 ? 'text-bad' : 'text-warn'}`}>{totalStock(p)} left</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card className="mt-5 p-5 md:p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl">Recent orders</h2>
          <Link to="/admin-demo/orders" className="text-sm underline underline-offset-4 hover:text-rose">View all</Link>
        </div>
        <ul className="divide-y divide-line">
          {orders.slice(0, 5).map((o) => (
            <li key={o.id} className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 py-3 text-sm">
              <div>
                <p className="font-medium">{o.ref}</p>
                <p className="text-[13px] text-ink-soft">{o.customer.fullName} · {formatDate(o.createdAt)}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="tabular-nums">{formatPrice(o.total)}</span>
                <StatusBadge status={o.status} />
              </div>
            </li>
          ))}
        </ul>
      </Card>
    </>
  )
}
