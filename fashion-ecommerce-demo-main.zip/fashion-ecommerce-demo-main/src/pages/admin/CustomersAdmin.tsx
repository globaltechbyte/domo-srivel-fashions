import { Plus, ShieldAlert } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Button } from '../../components/ui/Button'
import { MediaView } from '../../components/ui/MediaView'
import { Overlay } from '../../components/ui/Overlay'
import { Switch } from '../../components/ui/primitives'
import { useDocumentTitle } from '../../hooks/useMisc'
import { fallbackArt } from '../../lib/art'
import { deleteMedia } from '../../lib/idb'
import { commitDraft, detectPrivateData, uploadKeys, validateDisplayName, type MediaDraft } from '../../lib/media'
import { byOrder, HOME_CUSTOMER_LIMIT, isPublishable, nextOrder } from '../../lib/social'
import { useCatalog } from '../../store/catalog'
import { useSocial } from '../../store/social'
import { useUI } from '../../store/ui'
import type { CustomerPhoto } from '../../types'
import { MediaPicker } from './MediaPicker'
import { Card, PageTitle } from './parts'
import { SocialAdminRow, Tag } from './SocialAdminRow'
import { StorageNotice } from './StorageNotice'

interface Draft {
  photo?: MediaDraft
  displayName: string
  city: string
  productName: string
  review: string
  consentGiven: boolean
  consentNote: string
  privacyChecked: boolean
  order: string
  visible: boolean
  isDemo: boolean
}

function Editor({ item, nextOrderNo, onClose }: { item?: CustomerPhoto; nextOrderNo: number; onClose: () => void }) {
  const save = useSocial((s) => s.saveCustomer)
  const products = useCatalog((s) => s.products)
  const toast = useUI((s) => s.toast)
  const [d, setD] = useState<Draft>(() => ({
    photo: item ? (item.photo.source === 'url' ? { kind: 'url', url: item.photo.value } : { kind: 'existing', ref: item.photo }) : undefined,
    displayName: item?.displayName ?? '',
    city: item?.city ?? '',
    productName: item?.productName ?? '',
    review: item?.review ?? '',
    consentGiven: item?.consentGiven ?? false,
    consentNote: item?.consentNote ?? '',
    privacyChecked: item?.privacyChecked ?? false,
    order: String(item?.order ?? nextOrderNo),
    visible: item?.visible ?? false,
    isDemo: item?.isDemo ?? false,
  }))
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const patch = (p: Partial<Draft>) => {
    setD((x) => ({ ...x, ...p }))
    // Editing a field clears its stale error (consent changes clear the publish error too).
    setErrors((e) => {
      const next = { ...e }
      for (const k of Object.keys(p)) delete next[k]
      delete next.form
      if ('consentGiven' in p || 'privacyChecked' in p || 'isDemo' in p) delete next.visible
      if ('instagramUrl' in p) delete next.url
      if ('photo' in p) delete next.photo
      if ('media' in p || 'thumbnail' in p) delete next.media
      return next
    })
  }
  const canPublish = d.isDemo || (d.consentGiven && d.privacyChecked)

  const submit = async () => {
    const e: Record<string, string> = {}
    if (!d.photo) e.photo = 'Add the delivery photo.'
    const nameErr = validateDisplayName(d.displayName)
    if (nameErr) e.displayName = nameErr
    if (d.city.trim().length < 2) e.city = 'Enter the city.'
    else if (d.city.length > 40) e.city = 'City is too long.'
    else if (detectPrivateData(d.city)) e.city = `This looks like ${detectPrivateData(d.city)}. Use the city name only.`
    if (d.productName.trim().length < 2) e.productName = 'Enter the product purchased.'
    else if (detectPrivateData(d.productName)) e.productName = `This looks like ${detectPrivateData(d.productName)}.`
    if (d.review.length > 280) e.review = 'Keep reviews to 280 characters.'
    else if (detectPrivateData(d.review)) e.review = `The review looks like it contains ${detectPrivateData(d.review)}. Remove it before publishing.`
    if (!/^\d+$/.test(d.order) || Number(d.order) < 1) e.order = 'Use a whole number from 1.'
    if (d.visible && !canPublish) e.visible = 'Confirm the customer’s consent and the privacy check below before making this photo visible.'
    setErrors(e)
    if (Object.keys(e).length) return

    setSaving(true)
    let created: string[] = []
    try {
      const m = await commitDraft(d.photo!)
      if (d.photo!.kind === 'file') created = uploadKeys(m.media)
      const next: CustomerPhoto = {
        id: item?.id ?? `cp-${Date.now().toString(36)}`,
        photo: m.media,
        displayName: d.displayName.trim(),
        city: d.city.trim(),
        productName: d.productName.trim(),
        review: d.review.trim() || undefined,
        consentGiven: d.consentGiven,
        consentAt: d.consentGiven ? (item?.consentGiven && item.consentAt ? item.consentAt : new Date().toISOString()) : undefined,
        consentNote: d.consentNote.trim() || undefined,
        privacyChecked: d.privacyChecked,
        order: Number(d.order),
        visible: d.visible,
        isDemo: d.isDemo || undefined,
        createdAt: item?.createdAt ?? new Date().toISOString(),
      }
      save(next)
      toast(item ? 'Customer photo updated' : 'Customer photo added')
      onClose()
    } catch (err) {
      await deleteMedia(created)
      setErrors({ form: err instanceof Error ? err.message : 'Could not save this photo.' })
      setSaving(false)
    }
  }

  const check = 'mt-0.5 size-4 shrink-0 accent-[var(--color-rose)]'

  return (
    <>
      <div className="space-y-6 p-5 md:p-6">
        <div role="note" className="flex gap-3 border border-warn/40 bg-[#fdf6ea] p-4 text-sm">
          <ShieldAlert size={20} className="mt-0.5 shrink-0 text-warn" aria-hidden="true" />
          <p>Only publish photos customers have agreed to share. <strong>Never show</strong> delivery addresses, phone numbers, parcel labels, tracking codes or other private details. Crop or blur them first. Only a first name or initials, city and product are shown.</p>
        </div>
        {errors.form && <div role="alert" className="border border-bad/40 bg-[#fbeeee] p-3 text-sm text-bad">{errors.form}</div>}

        <MediaPicker label="Delivery photo" kinds={['image']} draft={d.photo} onChange={(photo) => patch({ photo })} error={errors.photo} />

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cp-name" className="mb-1.5 block text-sm">First name or initials</label>
            <input id="cp-name" className="field" placeholder="Priya or P. S." value={d.displayName} onChange={(e) => patch({ displayName: e.target.value })} aria-invalid={!!errors.displayName} autoComplete="off" />
            {errors.displayName && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.displayName}</p>}
          </div>
          <div>
            <label htmlFor="cp-city" className="mb-1.5 block text-sm">City</label>
            <input id="cp-city" className="field" value={d.city} onChange={(e) => patch({ city: e.target.value })} aria-invalid={!!errors.city} autoComplete="off" />
            {errors.city && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.city}</p>}
          </div>
        </div>
        <div>
          <label htmlFor="cp-prod" className="mb-1.5 block text-sm">Product purchased</label>
          <input id="cp-prod" className="field" list="cp-products" value={d.productName} onChange={(e) => patch({ productName: e.target.value })} aria-invalid={!!errors.productName} />
          <datalist id="cp-products">{products.map((p) => <option key={p.id} value={p.name} />)}</datalist>
          {errors.productName && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.productName}</p>}
        </div>
        <div>
          <label htmlFor="cp-review" className="mb-1.5 block text-sm">Customer feedback <span className="text-ink-soft">(optional, the customer’s own words)</span></label>
          <textarea id="cp-review" className="field" rows={3} maxLength={300} value={d.review} onChange={(e) => patch({ review: e.target.value })} aria-invalid={!!errors.review} />
          <p className="mt-1 text-[12px] text-ink-soft">{d.review.length}/280. Only add text a customer actually wrote and approved. Never write or edit reviews on their behalf.</p>
          {errors.review && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.review}</p>}
        </div>

        <fieldset className="space-y-3 border border-line bg-white p-4">
          <legend className="px-1 text-sm font-medium">Consent &amp; privacy (required to publish)</legend>
          <label className="flex items-start gap-3 text-sm"><input type="checkbox" className={check} checked={d.consentGiven} onChange={(e) => patch({ consentGiven: e.target.checked })} /> I confirm this customer has agreed to have this photo, their first name/initials, city and any feedback published on our website.</label>
          <div>
            <label htmlFor="cp-consent" className="mb-1 block text-[13px] text-ink-soft">How was consent given? (admin only, never shown publicly)</label>
            <input id="cp-consent" className="field !min-h-10" placeholder="e.g. WhatsApp message, 12 Oct" value={d.consentNote} onChange={(e) => patch({ consentNote: e.target.value })} />
          </div>
          <label className="flex items-start gap-3 text-sm"><input type="checkbox" className={check} checked={d.privacyChecked} onChange={(e) => patch({ privacyChecked: e.target.checked })} /> I have checked the photo: it shows no address, phone number, parcel label, tracking code or other private information.</label>
          <label className="flex items-start gap-3 text-sm"><input type="checkbox" className={check} checked={d.isDemo} onChange={(e) => patch({ isDemo: e.target.checked })} /> This is a demo / placeholder example, not a real customer (shows a “Demo example” label).</label>
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cp-order" className="mb-1.5 block text-sm">Display order</label>
            <input id="cp-order" className="field" inputMode="numeric" value={d.order} onChange={(e) => patch({ order: e.target.value.replace(/\D/g, '') })} aria-invalid={!!errors.order} />
            {errors.order && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.order}</p>}
          </div>
          <div>
            <div className="flex items-center justify-between gap-3 border border-line bg-white px-4">
              <span className="text-sm">Visible on homepage</span>
              <Switch checked={d.visible} onChange={(visible) => patch({ visible })} label="Visible on homepage" />
            </div>
            {!canPublish && <p className="mt-1 text-[12px] text-ink-soft">Needs consent and the privacy check before it can be visible.</p>}
            {errors.visible && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.visible}</p>}
          </div>
        </div>
      </div>
      <div className="sticky bottom-0 flex justify-end gap-3 border-t border-line bg-ivory px-5 py-4 md:px-6">
        <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
        <Button onClick={submit} disabled={saving}>{saving ? 'Saving…' : item ? 'Save changes' : 'Add photo'}</Button>
      </div>
    </>
  )
}

export default function CustomersAdmin() {
  useDocumentTitle('Admin · Customer photos')
  const items = useSocial((s) => s.customers)
  const { moveCustomer, setCustomerVisible, removeCustomer } = useSocial.getState()
  const toast = useUI((s) => s.toast)
  const sorted = useMemo(() => [...items].sort(byOrder), [items])
  const [editing, setEditing] = useState<CustomerPhoto | undefined>()
  const [open, setOpen] = useState(false)
  const [deleting, setDeleting] = useState<CustomerPhoto | null>(null)
  const live = sorted.filter(isPublishable).length

  const toggle = (c: CustomerPhoto, v: boolean) => {
    if (v && !(c.isDemo || (c.consentGiven && c.privacyChecked))) {
      toast('Add consent and complete the privacy check first (Edit).', 'error')
      return
    }
    setCustomerVisible(c.id, v)
  }

  return (
    <>
      <PageTitle title="Customer photos" sub={`“Loved by Our Customers” on the homepage. ${live} published, the first ${HOME_CUSTOMER_LIMIT} are shown.`} action={<Button onClick={() => { setEditing(undefined); setOpen(true) }}><Plus size={18} /> Add photo</Button>} />
      <Card className="mb-4 p-4 text-sm text-ink-soft">
        Photos appear publicly only with <strong>customer consent</strong> and a completed <strong>privacy check</strong>. Public cards show a first name or initials, city and product, never addresses, phone numbers, parcel labels or tracking codes. Demo examples are clearly labelled and carry no review text.
      </Card>
      <StorageNotice />

      {sorted.length === 0 ? (
        <div className="border border-line bg-white p-12 text-center text-ink-soft">No customer photos yet.</div>
      ) : (
        <ul className="space-y-3">
          {sorted.map((c, idx) => {
            const publishable = c.isDemo || (c.consentGiven && c.privacyChecked)
            return (
              <li key={c.id}>
                <SocialAdminRow
                  thumb={<MediaView media={c.photo} alt="" fallbackArt={fallbackArt('kurtis', c.id)} />}
                  title={`${c.displayName} · ${c.city}`}
                  meta={c.productName}
                  badges={<>
                    {c.isDemo ? <Tag tone="warn">Demo example</Tag> : c.consentGiven ? <Tag tone="ok">Consent confirmed</Tag> : <Tag tone="bad">No consent</Tag>}
                    {!c.isDemo && !c.privacyChecked && <Tag tone="bad">Privacy check pending</Tag>}
                    {c.review && <Tag tone="info">Has feedback</Tag>}
                    {c.photo.source === 'upload' && <Tag>Stored in this browser</Tag>}
                    {c.visible && !publishable && <Tag tone="bad">Blocked: not publishable</Tag>}
                    {!c.visible && <Tag>Hidden</Tag>}
                  </>}
                  position={idx}
                  count={sorted.length}
                  order={c.order}
                  enabled={c.visible}
                  enabledLabel="Visible on homepage"
                  onMove={(dir) => moveCustomer(c.id, dir)}
                  onToggle={(v) => toggle(c, v)}
                  onEdit={() => { setEditing(c); setOpen(true) }}
                  onDelete={() => setDeleting(c)}
                />
              </li>
            )
          })}
        </ul>
      )}

      <Overlay open={open} onClose={() => setOpen(false)} mode="drawer" title={editing ? 'Edit customer photo' : 'Add customer photo'} widthClass="max-w-[620px]">
        {open && <Editor key={editing?.id ?? 'new'} item={editing} nextOrderNo={nextOrder(items)} onClose={() => setOpen(false)} />}
      </Overlay>

      <Overlay open={!!deleting} onClose={() => setDeleting(null)} title="Remove this photo?" widthClass="max-w-md">
        <div className="space-y-5 p-6">
          <p className="text-ink-soft">The photo from {deleting?.displayName} will be removed from the site{deleting?.photo.source === 'upload' ? ' and deleted from this browser' : ''}. This can’t be undone (except with “Reset demo data”).</p>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button className="!bg-bad hover:!bg-[#8a2f32]" onClick={() => { if (deleting) { removeCustomer(deleting.id); toast('Customer photo removed', 'info') } setDeleting(null) }}>Remove</Button>
          </div>
        </div>
      </Overlay>
    </>
  )
}
