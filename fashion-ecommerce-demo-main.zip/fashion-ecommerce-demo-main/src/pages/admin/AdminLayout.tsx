import { ArrowLeft, Camera, Images, LayoutDashboard, Package, RotateCcw, ShoppingBag } from 'lucide-react'
import { useState } from 'react'
import { Link, NavLink, Outlet } from 'react-router-dom'
import { Button } from '../../components/ui/Button'
import { Overlay } from '../../components/ui/Overlay'
import { Toaster } from '../../components/ui/Toaster'
import { Wordmark } from '../../components/ui/primitives'
import { cn } from '../../lib/utils'
import { useCatalog } from '../../store/catalog'
import { useOrders } from '../../store/orders'
import { useSocial } from '../../store/social'
import { useUI } from '../../store/ui'

const LINKS = [
  { to: '/admin-demo', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin-demo/products', label: 'Products', icon: Package, end: false },
  { to: '/admin-demo/orders', label: 'Orders', icon: ShoppingBag, end: false },
  { to: '/admin-demo/instagram', label: 'Instagram gallery', icon: Images, end: false },
  { to: '/admin-demo/customers', label: 'Customer photos', icon: Camera, end: false },
]

export function AdminLayout() {
  const [confirmReset, setConfirmReset] = useState(false)
  const resetCatalog = useCatalog((s) => s.reset)
  const resetOrders = useOrders((s) => s.reset)
  const resetSocial = useSocial((s) => s.reset)
  const toast = useUI((s) => s.toast)

  const reset = () => {
    resetCatalog()
    resetOrders()
    resetSocial()
    setConfirmReset(false)
    toast('Demo data restored to defaults', 'info')
  }

  const linkCls = ({ isActive }: { isActive: boolean }) =>
    cn(
      'flex min-h-11 items-center gap-3 px-4 text-sm transition-colors',
      isActive ? 'bg-charcoal text-white' : 'text-charcoal hover:bg-sand',
    )

  return (
    <div className="min-h-dvh bg-[#f6f2ee]">
      <div className="bg-warn px-4 py-2 text-center text-[13px] font-medium text-white">
        DEMO ADMIN — presentation only. Mock data stored in your browser. No authentication, no real customers.
      </div>
      <div className="mx-auto flex max-w-[1500px] flex-col lg:flex-row">
        <aside className="shrink-0 border-b border-line bg-ivory lg:min-h-[calc(100dvh-36px)] lg:w-64 lg:border-b-0 lg:border-r">
          <div className="flex items-center justify-between px-4 py-4 lg:block lg:px-6 lg:py-8">
            <Link to="/admin-demo" aria-label="Admin demo home"><Wordmark className="!text-xl lg:!text-2xl" /></Link>
            <p className="eyebrow hidden pt-2 lg:block">Admin demo</p>
            <Link to="/" className="flex min-h-11 items-center gap-2 text-sm text-ink-soft hover:text-rose lg:hidden"><ArrowLeft size={16} /> Store</Link>
          </div>
          <nav aria-label="Admin" className="flex gap-1 overflow-x-auto px-2 pb-3 lg:flex-col lg:px-3 lg:pb-0">
            {LINKS.map((l) => (
              <NavLink key={l.to} to={l.to} end={l.end} className={linkCls}>
                <l.icon size={18} /> {l.label}
              </NavLink>
            ))}
          </nav>
          <div className="hidden space-y-1 px-3 pt-8 lg:block">
            <Link to="/" className="flex min-h-11 items-center gap-3 px-4 text-sm text-ink-soft hover:text-rose"><ArrowLeft size={18} /> Back to store</Link>
            <button onClick={() => setConfirmReset(true)} className="flex min-h-11 w-full items-center gap-3 px-4 text-sm text-ink-soft hover:text-bad"><RotateCcw size={18} /> Reset demo data</button>
          </div>
        </aside>
        <main className="min-w-0 flex-1 px-4 py-8 lg:px-10 lg:py-10">
          <Outlet />
          <button onClick={() => setConfirmReset(true)} className="mt-12 flex min-h-11 items-center gap-2 text-sm text-ink-soft hover:text-bad lg:hidden"><RotateCcw size={16} /> Reset demo data</button>
        </main>
      </div>

      <Overlay open={confirmReset} onClose={() => setConfirmReset(false)} title="Reset demo data?" widthClass="max-w-md">
        <div className="space-y-5 p-6">
          <p className="text-ink-soft">This restores the sample products, orders and gallery items, and deletes any demo orders, edits and uploaded gallery files. Your cart and wishlist are not affected.</p>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setConfirmReset(false)}>Cancel</Button>
            <Button onClick={reset}>Reset data</Button>
          </div>
        </div>
      </Overlay>
      <Toaster />
    </div>
  )
}
