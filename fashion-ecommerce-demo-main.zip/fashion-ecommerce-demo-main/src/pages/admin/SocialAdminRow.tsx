import { ArrowDown, ArrowUp, Pencil, Trash2 } from 'lucide-react'
import type { ReactNode } from 'react'
import { Switch } from '../../components/ui/primitives'
import { Card } from './parts'

/** One row in a social-proof admin list: thumbnail, details, order controls, switch, edit/delete. */
export function SocialAdminRow({
  thumb,
  title,
  meta,
  badges,
  position,
  count,
  order,
  enabled,
  enabledLabel,
  onMove,
  onToggle,
  onEdit,
  onDelete,
}: {
  thumb: ReactNode
  title: string
  meta: ReactNode
  badges?: ReactNode
  position: number
  count: number
  order: number
  enabled: boolean
  enabledLabel: string
  onMove: (dir: -1 | 1) => void
  onToggle: (v: boolean) => void
  onEdit: () => void
  onDelete: () => void
}) {
  const icon = 'grid size-11 place-items-center transition-colors hover:bg-sand disabled:opacity-30 disabled:hover:bg-transparent'
  return (
    <Card className={`flex flex-wrap items-center gap-x-4 gap-y-2 p-3 ${enabled ? '' : 'bg-ivory/60'}`}>
      <div className="aspect-square w-16 shrink-0 overflow-hidden bg-sand md:w-20">{thumb}</div>
      <div className="min-w-0 flex-1 basis-48">
        <p className="truncate font-medium">{title}</p>
        <div className="text-[13px] text-ink-soft">{meta}</div>
        {badges && <div className="mt-1.5 flex flex-wrap gap-1.5">{badges}</div>}
      </div>
      <div className="flex items-center gap-1">
        <span className="mr-1 text-[12px] text-ink-soft tabular-nums" aria-label={`Display order ${order}`}>#{order}</span>
        <button onClick={() => onMove(-1)} disabled={position === 0} aria-label={`Move “${title}” earlier`} className={icon}><ArrowUp size={16} /></button>
        <button onClick={() => onMove(1)} disabled={position === count - 1} aria-label={`Move “${title}” later`} className={icon}><ArrowDown size={16} /></button>
      </div>
      <div className="flex items-center">
        <Switch checked={enabled} onChange={onToggle} label={`${enabledLabel}: ${title}`} />
        <button onClick={onEdit} aria-label={`Edit ${title}`} className={icon}><Pencil size={17} /></button>
        <button onClick={onDelete} aria-label={`Delete ${title}`} className={`${icon} text-ink-soft hover:!bg-[#fbeeee] hover:text-bad`}><Trash2 size={17} /></button>
      </div>
    </Card>
  )
}

export function Tag({ tone = 'neutral', children }: { tone?: 'neutral' | 'ok' | 'warn' | 'bad' | 'info'; children: ReactNode }) {
  const cls = { neutral: 'bg-sand text-ink-soft', ok: 'bg-[#e1f1e6] text-[#235c3a]', warn: 'bg-[#fbf0dc] text-[#7a4d10]', bad: 'bg-[#f6e1e1] text-[#8a2c2f]', info: 'bg-[#e3eefb] text-[#1f4f86]' }[tone]
  return <span className={`inline-block px-2 py-0.5 text-[11px] font-medium ${cls}`}>{children}</span>
}
