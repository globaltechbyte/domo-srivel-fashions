import { Search } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Overlay } from '../../components/ui/Overlay'
import { useDocumentTitle } from '../../hooks/useMisc'
import { formatDate, formatPrice } from '../../lib/utils'
import { useOrders } from '../../store/orders'
import { ALL_STATUSES } from '../../lib/tracking'
import type { Order } from '../../types'
import { OrderDetail } from './OrderDetail'
import { Card, PageTitle, PaymentBadge, StatusBadge } from './parts'

const methodLabel = (o: Order) => (o.method === 'cod' ? 'Cash on Delivery' : 'WhatsApp')

export default function OrdersAdmin() {
  useDocumentTitle('Admin · Orders')
  const orders = useOrders((s) => s.orders)
  const [q, setQ] = useState('')
  const [status, setStatusF] = useState('')
  const [method, setMethod] = useState('')
  const [openId, setOpenId] = useState<string | null>(null)

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase()
    return orders.filter((o) => {
      if (status && o.status !== status) return false
      if (method && o.method !== method) return false
      if (term && !`${o.ref} ${o.customer.fullName} ${o.customer.mobile} ${o.customer.city}`.toLowerCase().includes(term)) return false
      return true
    })
  }, [orders, q, status, method])

  const current = orders.find((o) => o.id === openId)

  return (
    <>
      <PageTitle title="Orders" sub="Simulated orders from the demo checkout, plus a few labelled samples." />

      <Card className="mb-4 flex flex-wrap items-center gap-3 p-3">
        <div className="relative min-w-[200px] flex-1">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft" />
          <label htmlFor="ao-q" className="sr-only">Search orders</label>
          <input id="ao-q" className="field !min-h-10 !pl-10" placeholder="Search order no., name, mobile, city" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <label className="sr-only" htmlFor="ao-s">Status</label>
        <select id="ao-s" className="field !min-h-10 !w-auto" value={status} onChange={(e) => setStatusF(e.target.value)}>
          <option value="">All statuses</option>
          {ALL_STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <label className="sr-only" htmlFor="ao-m">Method</label>
        <select id="ao-m" className="field !min-h-10 !w-auto" value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="">All methods</option>
          <option value="cod">Cash on Delivery</option>
          <option value="whatsapp">WhatsApp</option>
        </select>
      </Card>

      {rows.length === 0 ? (
        <Card className="p-12 text-center text-ink-soft">{orders.length === 0 ? 'No orders yet. Place a demo order from the store checkout.' : 'No orders match these filters.'}</Card>
      ) : (
        <>
          <Card className="hidden overflow-x-auto md:block">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-[12px] uppercase tracking-wider text-ink-soft">
                  <th className="p-4 font-medium">Order</th>
                  <th className="p-4 font-medium">Customer</th>
                  <th className="p-4 font-medium">Method</th>
                  <th className="p-4 font-medium">Total</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium">Payment</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((o) => (
                  <tr key={o.id} className="border-b border-line last:border-0 hover:bg-ivory/60">
                    <td className="p-4">
                      <button onClick={() => setOpenId(o.id)} className="text-left font-medium underline-offset-4 hover:text-rose hover:underline">{o.ref}</button>
                      <p className="text-[12px] text-ink-soft">{formatDate(o.createdAt)}{o.isDemoTest ? ' · demo test order' : o.isSample ? ' · sample' : ''}</p>
                    </td>
                    <td className="p-4">{o.customer.fullName}<p className="text-[12px] text-ink-soft">{o.customer.city}</p></td>
                    <td className="p-4 text-ink-soft">{methodLabel(o)}</td>
                    <td className="p-4 tabular-nums">{formatPrice(o.total)}</td>
                    <td className="p-4"><StatusBadge status={o.status} /></td>
                    <td className="p-4"><PaymentBadge status={o.paymentStatus} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <ul className="space-y-3 md:hidden">
            {rows.map((o) => (
              <li key={o.id}>
                <button onClick={() => setOpenId(o.id)} className="block w-full text-left">
                  <Card className="space-y-2 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div><p className="font-medium">{o.ref}</p><p className="text-[12px] text-ink-soft">{formatDate(o.createdAt)}{o.isDemoTest ? ' · demo test order' : o.isSample ? ' · sample' : ''}</p></div>
                      <p className="tabular-nums">{formatPrice(o.total)}</p>
                    </div>
                    <p className="text-sm text-ink-soft">{o.customer.fullName} · {methodLabel(o)}</p>
                    <div className="flex flex-wrap gap-2"><StatusBadge status={o.status} /><PaymentBadge status={o.paymentStatus} /></div>
                  </Card>
                </button>
              </li>
            ))}
          </ul>
        </>
      )}

      <Overlay open={!!current} onClose={() => setOpenId(null)} mode="drawer" title={current ? `Order ${current.ref}` : 'Order'} widthClass="max-w-[560px]">
        {current && <OrderDetail order={current} />}
      </Overlay>
    </>
  )
}
