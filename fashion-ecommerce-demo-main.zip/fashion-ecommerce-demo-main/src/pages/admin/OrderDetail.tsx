import { ArrowRight, Ban, ExternalLink } from 'lucide-react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '../../components/ui/Button'
import { isTerminal, nextStatuses, safeTrackingUrl, validateShippingInfo, type ShippingErrors } from '../../lib/tracking'
import { formatDate, formatPrice } from '../../lib/utils'
import { useOrders } from '../../store/orders'
import { useUI } from '../../store/ui'
import type { Order, PaymentStatus, ShippingInfo } from '../../types'
import { PaymentBadge, StatusBadge } from './parts'

const methodLabel = (o: Order) => (o.method === 'cod' ? 'Cash on Delivery' : 'WhatsApp')
const SHIPPING_EDITABLE = ['Packed', 'Shipped', 'Delivered']

function ShippingForm({ order }: { order: Order }) {
  const setShippingInfo = useOrders((s) => s.setShippingInfo)
  const toast = useUI((s) => s.toast)
  const [form, setForm] = useState<ShippingInfo>({
    courierName: order.shippingInfo?.courierName ?? '',
    trackingNumber: order.shippingInfo?.trackingNumber ?? '',
    trackingUrl: order.shippingInfo?.trackingUrl ?? '',
  })
  const [errors, setErrors] = useState<ShippingErrors>({})
  const safe = safeTrackingUrl(form.trackingUrl)
  const dirty =
    (form.courierName ?? '') !== (order.shippingInfo?.courierName ?? '') ||
    (form.trackingNumber ?? '') !== (order.shippingInfo?.trackingNumber ?? '') ||
    (form.trackingUrl ?? '') !== (order.shippingInfo?.trackingUrl ?? '')

  const save = () => {
    const errs = validateShippingInfo(form)
    setErrors(errs)
    if (Object.keys(errs).length) return
    const res = setShippingInfo(order.id, form)
    toast(res.ok ? 'Shipping details saved' : res.reason, res.ok ? 'success' : 'error')
  }
  const set = (k: keyof ShippingInfo) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }))
    setErrors((x) => ({ ...x, [k]: undefined }))
  }

  return (
    <section aria-labelledby="od-ship-h">
      <h3 id="od-ship-h" className="mb-1 text-2xl">Courier &amp; tracking</h3>
      <p className="mb-3 text-[13px] text-ink-soft">Optional. Shown to the customer on the tracking page. The link is only shown if it is a valid http(s) URL.</p>
      <div className="space-y-3">
        <div>
          <label htmlFor="sh-courier" className="mb-1.5 block text-sm">Courier name</label>
          <input id="sh-courier" className="field" value={form.courierName} onChange={set('courierName')} placeholder="e.g. Sample Courier Express" aria-invalid={!!errors.courierName} />
          {errors.courierName && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.courierName}</p>}
        </div>
        <div>
          <label htmlFor="sh-number" className="mb-1.5 block text-sm">Tracking number</label>
          <input id="sh-number" className="field" value={form.trackingNumber} onChange={set('trackingNumber')} aria-invalid={!!errors.trackingNumber} />
          {errors.trackingNumber && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.trackingNumber}</p>}
        </div>
        <div>
          <label htmlFor="sh-url" className="mb-1.5 block text-sm">Tracking URL</label>
          <input id="sh-url" className="field" inputMode="url" value={form.trackingUrl} onChange={set('trackingUrl')} placeholder="https://courier.example/track/123" aria-invalid={!!errors.trackingUrl} aria-describedby="sh-url-hint" />
          {errors.trackingUrl && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.trackingUrl}</p>}
          <p id="sh-url-hint" className="mt-1 text-[12px] text-ink-soft">
            {safe ? (
              <a href={safe} target="_blank" rel="noopener noreferrer nofollow" className="inline-flex items-center gap-1 underline underline-offset-4 hover:text-rose">Test link <ExternalLink size={12} aria-hidden="true" /></a>
            ) : 'Leave empty to hide the courier link.'}
          </p>
        </div>
        <Button onClick={save} disabled={!dirty} variant="dark" size="sm">Save shipping details</Button>
      </div>
    </section>
  )
}

export function OrderDetail({ order }: { order: Order }) {
  const advance = useOrders((s) => s.advance)
  const setPayment = useOrders((s) => s.setPayment)
  const toast = useUI((s) => s.toast)
  const [confirmCancel, setConfirmCancel] = useState(false)

  const options = nextStatuses(order.status)
  const forward = options.find((s) => s !== 'Cancelled')
  const canCancel = options.includes('Cancelled')

  const move = (to: Parameters<typeof advance>[1]) => {
    const res = advance(order.id, to)
    setConfirmCancel(false)
    toast(res.ok ? `Order marked ${to}` : res.reason, res.ok ? 'info' : 'error')
  }

  return (
    <div className="space-y-8 p-5 md:p-6">
      {order.isDemoTest && <p className="bg-charcoal px-3 py-2 text-[13px] text-white">Demo test order — use it to try the customer tracking page.</p>}
      {order.isSample && !order.isDemoTest && <p className="bg-sand px-3 py-2 text-[13px]">Sample order with fictional customer details.</p>}

      <div className="flex flex-wrap gap-2"><StatusBadge status={order.status} /><PaymentBadge status={order.paymentStatus} /></div>

      <section aria-labelledby="od-flow-h">
        <h3 id="od-flow-h" className="mb-3 text-2xl">Status</h3>
        {isTerminal(order.status) ? (
          <p className="text-sm text-ink-soft">
            {order.status === 'Delivered' ? 'This order is delivered and its status is final.' : 'This order is cancelled and its status is final.'}
          </p>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-ink-soft">Orders move forward one step at a time. Allowed next steps:</p>
            <div className="flex flex-wrap gap-3">
              {forward && <Button onClick={() => move(forward)}>Mark as {forward} <ArrowRight size={16} aria-hidden="true" /></Button>}
              {canCancel && !confirmCancel && (
                <Button variant="outline" className="!border-bad !text-bad hover:!bg-bad hover:!text-white" onClick={() => setConfirmCancel(true)}><Ban size={16} aria-hidden="true" /> Cancel order</Button>
              )}
            </div>
            {confirmCancel && (
              <div role="alertdialog" aria-label="Confirm cancellation" className="border border-bad/40 bg-[#fbeeee] p-4 text-sm">
                <p className="font-medium text-bad">Cancel this order?</p>
                <p className="mt-1 text-ink-soft">Cancelled is final: the order cannot be reopened.</p>
                <div className="mt-3 flex gap-2">
                  <Button size="sm" className="!bg-bad hover:!bg-[#8a2f32]" onClick={() => move('Cancelled')}>Yes, cancel order</Button>
                  <Button size="sm" variant="outline" onClick={() => setConfirmCancel(false)}>Keep order</Button>
                </div>
              </div>
            )}
          </div>
        )}
      </section>

      {SHIPPING_EDITABLE.includes(order.status) ? (
        <ShippingForm key={order.id + order.status} order={order} />
      ) : (
        <p className="text-[13px] text-ink-soft">Courier and tracking fields become available once the order is packed.</p>
      )}

      {order.method === 'cod' && order.status !== 'Cancelled' && (
        <section>
          <label htmlFor="od-pay" className="mb-1.5 block text-sm font-medium">COD payment status</label>
          <select id="od-pay" className="field" value={order.paymentStatus} onChange={(e) => setPayment(order.id, e.target.value as PaymentStatus)}>
            <option>COD – Pending</option>
            <option>COD – Collected</option>
          </select>
        </section>
      )}

      <section aria-labelledby="od-hist-h">
        <h3 id="od-hist-h" className="mb-3 text-2xl">Status history</h3>
        <ol className="space-y-3 border-l-2 border-line pl-4">
          {[...order.history].reverse().map((e, i) => (
            <li key={`${e.status}-${e.at}-${i}`} className="relative text-sm">
              <span className="absolute -left-[22px] top-1.5 size-2.5 rounded-full bg-rose" aria-hidden="true" />
              <span className="font-medium">{e.status}</span>
              <time dateTime={e.at} className="block text-[13px] text-ink-soft">{formatDate(e.at)}</time>
            </li>
          ))}
        </ol>
      </section>

      <section>
        <h3 className="mb-3 text-2xl">Customer</h3>
        <address className="text-sm not-italic leading-relaxed">
          <p className="font-medium">{order.customer.fullName}</p>
          <p>+91 {order.customer.mobile}</p>
          <p className="mt-2 text-ink-soft">
            {order.customer.address1}{order.customer.address2 && `, ${order.customer.address2}`}
            {order.customer.landmark && ` (near ${order.customer.landmark})`}<br />
            {order.customer.city}, {order.customer.state} – {order.customer.pincode}
          </p>
        </address>
        <p className="mt-2 text-[12px] text-ink-soft">Full details are shown here for the demo store owner only; the public tracking page masks them.</p>
      </section>

      <section>
        <h3 className="mb-2 text-2xl">Items</h3>
        <ul className="divide-y divide-line text-sm">
          {order.lines.map((l, i) => (
            <li key={i} className="flex justify-between gap-4 py-3">
              <span>{l.name}<span className="block text-ink-soft">{l.color} · {l.size} · Qty {l.qty}</span></span>
              <span className="tabular-nums">{formatPrice(l.unitPrice * l.qty)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-3 space-y-1 border-t border-line pt-3 text-sm">
          <div className="flex justify-between"><dt className="text-ink-soft">Subtotal</dt><dd className="tabular-nums">{formatPrice(order.subtotal)}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-soft">Shipping</dt><dd className="tabular-nums">{order.shipping ? formatPrice(order.shipping) : 'Free'}</dd></div>
          <div className="flex justify-between text-base font-medium"><dt>Total</dt><dd className="tabular-nums">{formatPrice(order.total)}</dd></div>
        </dl>
        <p className="mt-3 text-[13px] text-ink-soft">{methodLabel(order)} · placed {formatDate(order.createdAt)}</p>
        <Link to={`/track-order?ref=${encodeURIComponent(order.ref)}`} className="mt-3 inline-block text-sm underline underline-offset-4 hover:text-rose">Open customer tracking page</Link>
      </section>
    </div>
  )
}
