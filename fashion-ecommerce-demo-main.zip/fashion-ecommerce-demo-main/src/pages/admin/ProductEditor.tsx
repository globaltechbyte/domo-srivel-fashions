import { Plus, X } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { FashionImage } from '../../components/ui/FashionImage'
import { commitDraft, IMAGE_TYPES, validateFile } from '../../lib/media'
import { deleteMedia } from '../../lib/idb'
import { PRODUCT_PHOTO_LABELS } from '../../lib/productPhotos'
import { Button } from '../../components/ui/Button'
import { Overlay } from '../../components/ui/Overlay'
import { CATEGORIES, SIZE_SETS } from '../../data/products'
import { makeArt, parseArt } from '../../lib/art'
import { cn, slugify, totalStock } from '../../lib/utils'
import type { CategorySlug, ColorOption, Product, Variant } from '../../types'

const ALL_SIZES = [...SIZE_SETS.apparel, ...SIZE_SETS.free]
const HEX_RE = /^#[0-9a-fA-F]{6}$/

interface Draft {
  name: string
  category: CategorySlug
  price: string
  compareAtPrice: string
  description: string
  fabric: string
  imageUrl: string
  isNew: boolean
  isFeatured: boolean
  colors: ColorOption[]
  sizes: string[]
  stock: Record<string, string> // key `${size}|${color}`
}

const key = (size: string, color: string) => `${size}|${color}`

function toDraft(p?: Product): Draft {
  if (!p) {
    return {
      name: '', category: 'kurtis', price: '', compareAtPrice: '', description: '', fabric: '', imageUrl: '',
      isNew: true, isFeatured: false,
      colors: [{ name: 'Ivory', hex: '#EFE5D3' }],
      sizes: ['S', 'M', 'L'],
      stock: { 'S|Ivory': '5', 'M|Ivory': '5', 'L|Ivory': '5' },
    }
  }
  const stock: Record<string, string> = {}
  p.variants.forEach((v) => (stock[key(v.size, v.color)] = String(v.stock)))
  return {
    name: p.name, category: p.category, price: String(p.price), compareAtPrice: p.compareAtPrice ? String(p.compareAtPrice) : '',
    description: p.description, fabric: p.fabric, imageUrl: p.images.find((i) => !i.startsWith('art:')) ?? '',
    isNew: p.isNew, isFeatured: p.isFeatured, colors: p.colors.map((c) => ({ ...c })), sizes: [...p.sizes], stock,
  }
}

export function ProductEditor({
  open, product, existingSlugs, onClose, onSave,
}: {
  open: boolean
  product?: Product
  existingSlugs: string[]
  onClose: () => void
  onSave: (p: Product) => void
}) {
  return (
    <Overlay open={open} onClose={onClose} mode="drawer" title={product ? 'Edit product' : 'Add demo product'} widthClass="max-w-[640px]">
      {open && <EditorForm key={product?.id ?? 'new'} product={product} existingSlugs={existingSlugs} onClose={onClose} onSave={onSave} />}
    </Overlay>
  )
}

function EditorForm({ product, existingSlugs, onClose, onSave }: { product?: Product; existingSlugs: string[]; onClose: () => void; onSave: (p: Product) => void }) {
  const [d, setD] = useState<Draft>(() => toDraft(product))
  const [errors, setErrors] = useState<string[]>([])
  const [customSize, setCustomSize] = useState('')
  const [files, setFiles] = useState<File[]>([])
  const [saving, setSaving] = useState(false)
  const mounted = useRef(true)
  const savePending = useRef(false)
  useEffect(() => {
    mounted.current = true
    return () => { mounted.current = false }
  }, [])
  const patch = (p: Partial<Draft>) => setD((x) => ({ ...x, ...p }))
  const movePhoto = (index: number, direction: -1 | 1) => setFiles((current) => {
    const next = [...current]
    const target = index + direction
    if (target < 0 || target >= next.length) return current
    const photo = next[index]
    next[index] = next[target]
    next[target] = photo
    return next
  })

  const total = useMemo(
    () => d.sizes.reduce((n, s) => n + d.colors.reduce((m, c) => m + (Number(d.stock[key(s, c.name)]) || 0), 0), 0),
    [d.sizes, d.colors, d.stock],
  )

  const toggleSize = (s: string) => patch({ sizes: d.sizes.includes(s) ? d.sizes.filter((x) => x !== s) : [...d.sizes, s] })
  const sortedSizes = [...d.sizes].sort((a, b) => ALL_SIZES.indexOf(a) - ALL_SIZES.indexOf(b))

  const setColor = (i: number, c: Partial<ColorOption>) => {
    const old = d.colors[i]
    const next = d.colors.map((x, k) => (k === i ? { ...x, ...c } : x))
    const stock = { ...d.stock }
    if (c.name !== undefined && c.name !== old.name) {
      d.sizes.forEach((s) => {
        stock[key(s, c.name!)] = stock[key(s, old.name)] ?? '0'
        delete stock[key(s, old.name)]
      })
    }
    patch({ colors: next, stock })
  }

  const save = async () => {
    if (savePending.current) return
    const errs: string[] = []
    const price = Number(d.price)
    const compare = d.compareAtPrice ? Number(d.compareAtPrice) : undefined
    if (d.name.trim().length < 3) errs.push('Product name must be at least 3 characters.')
    if (!price || price <= 0) errs.push('Enter a valid price greater than 0.')
    if (compare !== undefined && (!compare || compare <= price)) errs.push('Compare-at price must be higher than the price (or left empty).')
    if (d.sizes.length === 0) errs.push('Select at least one size.')
    if (d.colors.length === 0) errs.push('Add at least one colour.')
    if (d.colors.some((c) => !c.name.trim())) errs.push('Every colour needs a name.')
    if (new Set(d.colors.map((c) => c.name.trim().toLowerCase())).size !== d.colors.length) errs.push('Colour names must be unique.')
    if (d.colors.some((c) => !HEX_RE.test(c.hex))) errs.push('Every colour needs a valid hex value.')
    if (!files.length && d.imageUrl && !/^(https?:\/\/|\/|upload:)/.test(d.imageUrl.trim())) errs.push('Image URL must start with https://, http:// or /.')
    setErrors(errs)
    if (errs.length) return

    const colors = d.colors.map((c) => ({ name: c.name.trim(), hex: c.hex }))
    const variants: Variant[] = []
    sortedSizes.forEach((size) =>
      colors.forEach((c, ci) => {
        const orig = d.colors[ci].name
        variants.push({ size, color: c.name, stock: Math.max(0, Math.floor(Number(d.stock[key(size, orig)] ?? d.stock[key(size, c.name)]) || 0)) })
      }),
    )

    // images: keep existing illustration style when present, retinted to the first colour
    const firstHex = colors[0].hex
    const existingArt = product?.images.map(parseArt).find(Boolean)
    const pattern = existingArt?.pattern ?? 'floral'
    const art = (['front', 'detail', 'styled', 'flat'] as const).map((view) => makeArt({ category: d.category, pattern, view, hex: firstHex }))
    let images = d.imageUrl.trim() ? [d.imageUrl.trim(), ...(product?.images.filter((i) => !i.startsWith('art:') && i !== d.imageUrl.trim()) ?? [])] : art

    let slug = slugify(d.name)
    if (!product || product.name !== d.name) {
      const taken = existingSlugs.filter((s) => s !== product?.slug)
      let n = 2
      const base = slug
      while (taken.includes(slug)) slug = `${base}-${n++}`
    } else slug = product.slug

    savePending.current = true
    setSaving(true)
    const written: string[] = []
    try {
      if (files.length) {
        for (const file of files) {
          const result = await commitDraft({ kind: 'file', file, previewUrl: '', mediaKind: 'image' })
          written.push(result.media.value)
          if (!mounted.current) {
            await deleteMedia(written)
            return
          }
        }
        images = written.map((id) => `upload:${id}`)
      }
      const saved: Product = {
        id: product?.id ?? `p-${Date.now()}`,
        name: d.name.trim(), slug, category: d.category,
        description: d.description.trim() || 'Description coming soon.',
        fabric: d.fabric.trim() || 'Fabric details coming soon',
        care: product?.care ?? ['Dry clean recommended', 'Iron on low heat'],
        price, compareAtPrice: compare, images, colors, sizes: sortedSizes, variants, stock: 0,
        isNew: d.isNew, isFeatured: d.isFeatured, isBestseller: product?.isBestseller, collection: product?.collection,
      }
      saved.stock = totalStock(saved)
      onSave(saved)
      onClose()
    } catch (error) {
      await deleteMedia(written)
      if (mounted.current) setErrors([error instanceof Error ? error.message : 'Could not save product photos. Please try again.'])
    } finally {
      savePending.current = false
      if (mounted.current) setSaving(false)
    }
  }

  const label = 'mb-1.5 block text-sm'

  return (
    <>
      <div className="space-y-6 p-5 md:p-6">
        {errors.length > 0 && (
          <div role="alert" className="border border-bad/40 bg-[#fbeeee] p-4 text-sm text-bad">
            <p className="mb-1 font-medium">Please fix the following:</p>
            <ul className="list-disc pl-5">{errors.map((e) => <li key={e}>{e}</li>)}</ul>
          </div>
        )}

        <div>
          <label htmlFor="pe-name" className={label}>Product name</label>
          <input id="pe-name" className="field" value={d.name} onChange={(e) => patch({ name: e.target.value })} />
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="sm:col-span-1">
            <label htmlFor="pe-cat" className={label}>Category</label>
            <select id="pe-cat" className="field" value={d.category} onChange={(e) => patch({ category: e.target.value as CategorySlug })}>
              {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.label}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="pe-price" className={label}>Price (₹)</label>
            <input id="pe-price" className="field" inputMode="numeric" value={d.price} onChange={(e) => patch({ price: e.target.value.replace(/\D/g, '') })} />
          </div>
          <div>
            <label htmlFor="pe-cmp" className={label}>Compare-at (₹)</label>
            <input id="pe-cmp" className="field" inputMode="numeric" placeholder="Optional" value={d.compareAtPrice} onChange={(e) => patch({ compareAtPrice: e.target.value.replace(/\D/g, '') })} />
          </div>
        </div>
        <div>
          <label htmlFor="pe-desc" className={label}>Description</label>
          <textarea id="pe-desc" className="field" rows={3} value={d.description} onChange={(e) => patch({ description: e.target.value })} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="pe-fab" className={label}>Fabric</label>
            <input id="pe-fab" className="field" value={d.fabric} onChange={(e) => patch({ fabric: e.target.value })} />
          </div>
          <div>
            <label htmlFor="pe-img" className={label}>Photo URL <span className="text-ink-soft">(optional)</span></label>
            <input id="pe-img" className="field" placeholder="https://… or /products/photo.jpg" disabled={saving || files.length > 0} value={d.imageUrl.startsWith('upload:') ? '' : d.imageUrl} onChange={(e) => patch({ imageUrl: e.target.value })} />
          </div>
        </div>
        <div className="border border-line bg-white p-4">
          <label htmlFor="pe-upload" className={label}>Upload product photos</label>
          <input id="pe-upload" type="file" multiple accept={IMAGE_TYPES.join(',')} disabled={saving} className="block w-full text-sm file:mr-3 file:cursor-pointer file:border-0 file:bg-rose-mist file:px-4 file:py-3 file:text-rose" onChange={(e) => {
            const selected = Array.from(e.target.files ?? [])
            e.target.value = ''
            if (!selected.length) return
            const issues = selected.map((file) => validateFile(file, ['image'])).filter((issue): issue is string => !!issue)
            if (files.length + selected.length > 4) issues.push('Choose up to 4 photos. Remove a selected photo before adding another.')
            setErrors(issues)
            if (!issues.length) setFiles((current) => [...current, ...selected])
          }} />
          <p className="mt-2 text-xs text-ink-soft">Add 3–4 photos together or one at a time. JPG, PNG or WebP, up to 5 MB each. New photos replace the current set when you save.</p>
          <p className="mt-2 text-xs text-ink-soft">1. Cover · 2. Detail · 3. Hover view · 4. Extra view. The hover view fades in on the product card; all photos appear in the product gallery. With two photos, the detail photo is also the hover view.</p>
          <p className="mt-1 text-xs text-ink-soft">Uploaded photos are saved in this browser only.</p>
          <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-4">
            {files.length ? files.map((file, i) => (
              <div key={`${file.name}-${i}`}>
                <FilePreview file={file} />
                <p className="mt-1 text-xs font-medium">{i + 1}. {PRODUCT_PHOTO_LABELS[i]}</p>
                <p className="mt-1 truncate text-xs text-ink-soft">{file.name}</p>
                <div className="mt-1 flex gap-2">
                  <button type="button" disabled={saving || i === 0} aria-label={`Move photo ${i + 1} earlier`} className="min-h-8 px-2 text-xs text-rose disabled:opacity-30" onClick={() => movePhoto(i, -1)}>←</button>
                  <button type="button" disabled={saving || i === files.length - 1} aria-label={`Move photo ${i + 1} later`} className="min-h-8 px-2 text-xs text-rose disabled:opacity-30" onClick={() => movePhoto(i, 1)}>→</button>
                </div>
                <button type="button" disabled={saving} className="mt-1 text-xs text-rose underline" onClick={() => setFiles((current) => current.filter((_, index) => index !== i))}>Remove</button>
              </div>
            )) : (d.imageUrl ? [d.imageUrl, ...(product?.images.filter((i) => !i.startsWith('art:') && i !== d.imageUrl) ?? [])] : []).map((src, i) => (
              <div key={`${src}-${i}`}>
                <div className="aspect-[3/4] overflow-hidden bg-sand"><FashionImage src={src} alt={`Product photo ${i + 1}`} category={d.category} /></div>
                <p className="mt-1 text-xs font-medium">{i + 1}. {PRODUCT_PHOTO_LABELS[i] ?? 'Extra'}</p>
              </div>
            ))}
          </div>
          {files.length > 0 && <Button variant="ghost" size="sm" disabled={saving} className="mt-2" onClick={() => setFiles([])}>Keep current photos</Button>}
        </div>
        <div className="flex flex-wrap gap-6">
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" className="size-4 accent-[var(--color-rose)]" checked={d.isNew} onChange={(e) => patch({ isNew: e.target.checked })} /> Mark as new arrival</label>
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" className="size-4 accent-[var(--color-rose)]" checked={d.isFeatured} onChange={(e) => patch({ isFeatured: e.target.checked })} /> Featured</label>
        </div>

        <fieldset>
          <legend className="mb-2 text-sm font-medium">Sizes</legend>
          <div className="flex flex-wrap gap-2">
            {[...ALL_SIZES, ...d.sizes.filter((s) => !ALL_SIZES.includes(s))].map((s) => (
              <button key={s} type="button" aria-pressed={d.sizes.includes(s)} onClick={() => toggleSize(s)} className={cn('min-h-10 min-w-12 border px-3 text-sm transition-colors', d.sizes.includes(s) ? 'border-charcoal bg-charcoal text-white' : 'border-line bg-white hover:border-charcoal')}>{s}</button>
            ))}
          </div>
          <div className="mt-3 flex max-w-xs gap-2">
            <label htmlFor="pe-csize" className="sr-only">Custom size</label>
            <input id="pe-csize" className="field !min-h-10" placeholder="Custom size, e.g. 3XL" value={customSize} onChange={(e) => setCustomSize(e.target.value)} />
            <Button variant="outline" size="sm" onClick={() => { const v = customSize.trim(); if (v && !d.sizes.includes(v)) patch({ sizes: [...d.sizes, v] }); setCustomSize('') }}>Add</Button>
          </div>
        </fieldset>

        <fieldset>
          <legend className="mb-2 text-sm font-medium">Colours</legend>
          <ul className="space-y-2">
            {d.colors.map((c, i) => (
              <li key={i} className="flex items-center gap-2">
                <label className="sr-only" htmlFor={`pe-cn-${i}`}>Colour name</label>
                <input id={`pe-cn-${i}`} className="field !min-h-10 flex-1" value={c.name} onChange={(e) => setColor(i, { name: e.target.value })} />
                <label className="sr-only" htmlFor={`pe-ch-${i}`}>Colour picker for {c.name}</label>
                <input id={`pe-ch-${i}`} type="color" className="size-10 shrink-0 cursor-pointer border border-line bg-white p-1" value={HEX_RE.test(c.hex) ? c.hex : '#000000'} onChange={(e) => setColor(i, { hex: e.target.value.toUpperCase() })} />
                <button type="button" aria-label={`Remove colour ${c.name}`} onClick={() => patch({ colors: d.colors.filter((_, k) => k !== i) })} disabled={d.colors.length === 1} className="grid size-10 shrink-0 place-items-center text-ink-soft hover:text-bad disabled:opacity-30"><X size={18} /></button>
              </li>
            ))}
          </ul>
          <Button variant="outline" size="sm" className="mt-3" onClick={() => patch({ colors: [...d.colors, { name: `Colour ${d.colors.length + 1}`, hex: '#C98B9A' }] })}><Plus size={16} /> Add colour</Button>
        </fieldset>

        <fieldset>
          <legend className="mb-1 text-sm font-medium">Stock by size and colour <span className="font-normal text-ink-soft">· total {total}</span></legend>
          {sortedSizes.length === 0 || d.colors.length === 0 ? (
            <p className="text-sm text-ink-soft">Select sizes and colours first.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[320px] text-sm">
                <thead>
                  <tr className="text-left text-[12px] uppercase tracking-wider text-ink-soft">
                    <th className="py-2 pr-2 font-medium">Size</th>
                    {d.colors.map((c, i) => <th key={i} className="px-1 py-2 font-medium"><span className="mr-1 inline-block size-3 rounded-full border border-black/10 align-middle" style={{ background: c.hex }} />{c.name}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {sortedSizes.map((s) => (
                    <tr key={s} className="border-t border-line">
                      <th scope="row" className="py-1.5 pr-2 text-left font-medium">{s}</th>
                      {d.colors.map((c, i) => (
                        <td key={i} className="px-1 py-1.5">
                          <input aria-label={`Stock for ${s}, ${c.name}`} className="field !min-h-10 !w-20 !px-2 text-center tabular-nums" inputMode="numeric" value={d.stock[key(s, c.name)] ?? '0'} onChange={(e) => patch({ stock: { ...d.stock, [key(s, c.name)]: e.target.value.replace(/\D/g, '') } })} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </fieldset>
      </div>
      <div className="sticky bottom-0 flex justify-end gap-3 border-t border-line bg-ivory px-5 py-4 md:px-6">
        <Button variant="outline" disabled={saving} onClick={onClose}>Cancel</Button>
        <Button disabled={saving} onClick={() => void save()}>{saving ? 'Saving photos…' : product ? 'Save changes' : 'Add product'}</Button>
      </div>
    </>
  )
}

function FilePreview({ file }: { file: File }) {
  const image = useRef<HTMLImageElement>(null)
  useEffect(() => {
    const url = URL.createObjectURL(file)
    if (image.current) image.current.src = url
    return () => URL.revokeObjectURL(url)
  }, [file])
  return <div className="aspect-[3/4] overflow-hidden bg-sand"><img ref={image} alt={file.name} className="h-full w-full object-cover" /></div>
}
