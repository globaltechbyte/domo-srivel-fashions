import { Play, Plus } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Button } from '../../components/ui/Button'
import { MediaView } from '../../components/ui/MediaView'
import { Overlay } from '../../components/ui/Overlay'
import { Switch } from '../../components/ui/primitives'
import { useDocumentTitle } from '../../hooks/useMisc'
import { fallbackArt } from '../../lib/art'
import { deleteMedia } from '../../lib/idb'
import { commitDraft, parseInstagramUrl, uploadKeys, type MediaDraft } from '../../lib/media'
import { byOrder, HOME_INSTAGRAM_LIMIT, instagramKindLabel, nextOrder } from '../../lib/social'
import { useSocial } from '../../store/social'
import { useUI } from '../../store/ui'
import type { InstagramItem, MediaRef } from '../../types'
import { MediaPicker } from './MediaPicker'
import { PageTitle } from './parts'
import { SocialAdminRow, Tag } from './SocialAdminRow'
import { StorageNotice } from './StorageNotice'

const refToDraft = (r?: MediaRef): MediaDraft | undefined => (!r ? undefined : r.source === 'url' ? { kind: 'url', url: r.value } : { kind: 'existing', ref: r })

interface Draft {
  instagramUrl: string
  caption: string
  order: string
  active: boolean
  isDemo: boolean
  media?: MediaDraft
  thumbnail?: MediaDraft
}

function Editor({ item, nextOrderNo, onClose }: { item?: InstagramItem; nextOrderNo: number; onClose: () => void }) {
  const save = useSocial((s) => s.saveInstagram)
  const toast = useUI((s) => s.toast)
  const [d, setD] = useState<Draft>(() => ({
    instagramUrl: item?.instagramUrl ?? '',
    caption: item?.caption ?? '',
    order: String(item?.order ?? nextOrderNo),
    active: item?.active ?? true,
    isDemo: item?.isDemo ?? false,
    media: refToDraft(item?.media),
    thumbnail: refToDraft(item?.thumbnail),
  }))
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const patch = (p: Partial<Draft>) => {
    setD((x) => ({ ...x, ...p }))
    // Editing a field clears its stale error (consent changes clear the publish error too).
    setErrors((e) => {
      const next = { ...e }
      for (const k of Object.keys(p)) delete next[k]
      delete next.form
      if ('consentGiven' in p || 'privacyChecked' in p || 'isDemo' in p) delete next.visible
      if ('instagramUrl' in p) delete next.url
      if ('photo' in p) delete next.photo
      if ('media' in p || 'thumbnail' in p) delete next.media
      return next
    })
  }
  const parsed = parseInstagramUrl(d.instagramUrl)

  const submit = async () => {
    const e: Record<string, string> = {}
    if (d.instagramUrl.trim() && !parsed) e.url = 'Enter a valid Instagram post or reel link, e.g. https://www.instagram.com/p/AbC123xyz/'
    if (!parsed && !d.media && !d.thumbnail) e.media = 'Add an Instagram link, or upload a photo or video.'
    if (!/^\d+$/.test(d.order) || Number(d.order) < 1) e.order = 'Use a whole number from 1.'
    if (d.caption.length > 150) e.caption = 'Keep captions to 150 characters.'
    setErrors(e)
    if (Object.keys(e).length) return

    setSaving(true)
    const created: string[] = []
    try {
      const m = d.media ? await commitDraft(d.media) : undefined
      created.push(...uploadKeys(...(d.media?.kind === 'file' ? [m?.media, m?.poster] : [])))
      const t = d.thumbnail ? await commitDraft(d.thumbnail) : undefined
      created.push(...uploadKeys(...(d.thumbnail?.kind === 'file' ? [t?.media] : [])))
      const next: InstagramItem = {
        id: item?.id ?? `ig-${Date.now().toString(36)}`,
        type: parsed?.type ?? 'upload',
        instagramUrl: parsed?.url,
        media: m?.media,
        // An explicit thumbnail wins; otherwise use the poster captured from an uploaded video.
        thumbnail: t?.media ?? m?.poster ?? (d.media?.kind === 'existing' ? item?.thumbnail : undefined),
        caption: d.caption.trim(),
        order: Number(d.order),
        active: d.active,
        isDemo: d.isDemo || undefined,
        createdAt: item?.createdAt ?? new Date().toISOString(),
      }
      save(next)
      toast(item ? 'Gallery item updated' : 'Gallery item added')
      onClose()
    } catch (err) {
      await deleteMedia(created)
      setErrors({ form: err instanceof Error ? err.message : 'Could not save this item.' })
      setSaving(false)
    }
  }

  return (
    <>
      <div className="space-y-6 p-5 md:p-6">
        {errors.form && <div role="alert" className="border border-bad/40 bg-[#fbeeee] p-3 text-sm text-bad">{errors.form}</div>}

        <div>
          <label htmlFor="ig-url" className="mb-1.5 block text-sm">Instagram post or reel URL <span className="text-ink-soft">(optional)</span></label>
          <input id="ig-url" className="field" inputMode="url" placeholder="https://www.instagram.com/reel/…" value={d.instagramUrl} onChange={(e) => patch({ instagramUrl: e.target.value })} aria-invalid={!!errors.url} aria-describedby="ig-url-hint" />
          <p id="ig-url-hint" className="mt-1 text-[12px] text-ink-soft">
            {parsed ? <>Detected: <strong>{parsed.type === 'reel' ? 'Reel' : 'Post'}</strong>. The card will link to Instagram.</> : 'Cards with a link open Instagram in a new tab. Instagram doesn’t provide previews to this demo, so add a thumbnail below.'}
          </p>
          {errors.url && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.url}</p>}
        </div>

        <MediaPicker label="Photo or video (upload)" kinds={['image', 'video']} draft={d.media} onChange={(media) => patch({ media })} error={errors.media} />
        <MediaPicker label="Thumbnail" kinds={['image']} draft={d.thumbnail} onChange={(thumbnail) => patch({ thumbnail })} hint="Cover image for the card. For uploaded videos a first-frame thumbnail is created automatically if you leave this empty." />

        <div>
          <label htmlFor="ig-cap" className="mb-1.5 block text-sm">Caption</label>
          <textarea id="ig-cap" className="field" rows={2} maxLength={160} value={d.caption} onChange={(e) => patch({ caption: e.target.value })} aria-invalid={!!errors.caption} />
          {errors.caption && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.caption}</p>}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="ig-order" className="mb-1.5 block text-sm">Display order</label>
            <input id="ig-order" className="field" inputMode="numeric" value={d.order} onChange={(e) => patch({ order: e.target.value.replace(/\D/g, '') })} aria-invalid={!!errors.order} />
            <p className="mt-1 text-[12px] text-ink-soft">Lower numbers appear first.</p>
            {errors.order && <p role="alert" className="mt-1 text-[13px] text-bad">{errors.order}</p>}
          </div>
          <div className="flex items-center justify-between gap-3 border border-line bg-white px-4 sm:self-start">
            <span className="text-sm">Show on homepage</span>
            <Switch checked={d.active} onChange={(active) => patch({ active })} label="Show on homepage" />
          </div>
        </div>
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" className="size-4 accent-[var(--color-rose)]" checked={d.isDemo} onChange={(e) => patch({ isDemo: e.target.checked })} />
          Mark as a demo / placeholder example (shows a “Demo” label)
        </label>
      </div>
      <div className="sticky bottom-0 flex justify-end gap-3 border-t border-line bg-ivory px-5 py-4 md:px-6">
        <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
        <Button onClick={submit} disabled={saving}>{saving ? 'Saving…' : item ? 'Save changes' : 'Add item'}</Button>
      </div>
    </>
  )
}

export default function GalleryAdmin() {
  useDocumentTitle('Admin · Instagram gallery')
  const items = useSocial((s) => s.instagram)
  const { moveInstagram, setInstagramActive, removeInstagram } = useSocial.getState()
  const toast = useUI((s) => s.toast)
  const sorted = useMemo(() => [...items].sort(byOrder), [items])
  const [editing, setEditing] = useState<InstagramItem | undefined>()
  const [open, setOpen] = useState(false)
  const [deleting, setDeleting] = useState<InstagramItem | null>(null)
  const shown = sorted.filter((i) => i.active).length

  return (
    <>
      <PageTitle title="Instagram gallery" sub={`“Styled on Instagram” on the homepage. ${shown} active, the first ${HOME_INSTAGRAM_LIMIT} are shown.`} action={<Button onClick={() => { setEditing(undefined); setOpen(true) }}><Plus size={18} /> Add item</Button>} />
      <StorageNotice />

      {sorted.length === 0 ? (
        <div className="border border-line bg-white p-12 text-center text-ink-soft">No gallery items yet. Add your first Instagram post, reel, photo or video.</div>
      ) : (
        <ul className="space-y-3">
          {sorted.map((i, idx) => (
            <li key={i.id}>
              <SocialAdminRow
                thumb={<MediaView media={i.media} poster={i.thumbnail} alt="" fallbackArt={fallbackArt('dresses', i.id)} />}
                title={i.caption || '(no caption)'}
                meta={i.instagramUrl ? <a href={i.instagramUrl} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-rose">{i.instagramUrl.replace('https://www.instagram.com', 'instagram.com')}</a> : 'No Instagram link'}
                badges={<>
                  <Tag tone="info">{i.type === 'reel' || i.media?.kind === 'video' ? <><Play size={10} className="mr-1 inline fill-current" aria-hidden="true" />{instagramKindLabel(i)}</> : instagramKindLabel(i)}</Tag>
                  {i.media?.source === 'upload' && <Tag>Stored in this browser</Tag>}
                  {i.isDemo && <Tag tone="warn">Demo</Tag>}
                  {!i.active && <Tag>Hidden</Tag>}
                </>}
                position={idx}
                count={sorted.length}
                order={i.order}
                enabled={i.active}
                enabledLabel="Show on homepage"
                onMove={(dir) => moveInstagram(i.id, dir)}
                onToggle={(v) => setInstagramActive(i.id, v)}
                onEdit={() => { setEditing(i); setOpen(true) }}
                onDelete={() => setDeleting(i)}
              />
            </li>
          ))}
        </ul>
      )}

      <Overlay open={open} onClose={() => setOpen(false)} mode="drawer" title={editing ? 'Edit gallery item' : 'Add gallery item'} widthClass="max-w-[600px]">
        {open && <Editor key={editing?.id ?? 'new'} item={editing} nextOrderNo={nextOrder(items)} onClose={() => setOpen(false)} />}
      </Overlay>

      <Overlay open={!!deleting} onClose={() => setDeleting(null)} title="Delete gallery item?" widthClass="max-w-md">
        <div className="space-y-5 p-6">
          <p className="text-ink-soft">“{deleting?.caption || 'This item'}” will be removed{deleting?.media?.source === 'upload' ? ', and its uploaded file will be deleted from this browser' : ''}. This can’t be undone (except with “Reset demo data”).</p>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button className="!bg-bad hover:!bg-[#8a2f32]" onClick={() => { if (deleting) { removeInstagram(deleting.id); toast('Gallery item deleted', 'info') } setDeleting(null) }}>Delete</Button>
          </div>
        </div>
      </Overlay>
    </>
  )
}
