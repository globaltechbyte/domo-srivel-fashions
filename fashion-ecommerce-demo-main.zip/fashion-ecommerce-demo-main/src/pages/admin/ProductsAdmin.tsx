import { Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Button } from '../../components/ui/Button'
import { FashionImage } from '../../components/ui/FashionImage'
import { Overlay } from '../../components/ui/Overlay'
import { CATEGORIES, categoryLabel } from '../../data/products'
import { useDocumentTitle } from '../../hooks/useMisc'
import { recolor } from '../../lib/art'
import { formatPrice, LOW_STOCK_THRESHOLD, totalStock } from '../../lib/utils'
import { useCatalog } from '../../store/catalog'
import { useUI } from '../../store/ui'
import type { Product } from '../../types'
import { Card, PageTitle } from './parts'
import { ProductEditor } from './ProductEditor'

function StockPill({ n }: { n: number }) {
  const cls = n === 0 ? 'bg-[#f6e1e1] text-[#8a2c2f]' : n <= LOW_STOCK_THRESHOLD ? 'bg-[#fbf0dc] text-[#7a4d10]' : 'bg-[#e1f1e6] text-[#235c3a]'
  const text = n === 0 ? 'Out of stock' : n <= LOW_STOCK_THRESHOLD ? `Low · ${n}` : `${n} in stock`
  return <span className={`inline-block whitespace-nowrap px-2.5 py-1 text-xs font-medium ${cls}`}>{text}</span>
}

export default function ProductsAdmin() {
  useDocumentTitle('Admin · Products')
  const products = useCatalog((s) => s.products)
  const upsert = useCatalog((s) => s.upsert)
  const remove = useCatalog((s) => s.remove)
  const toast = useUI((s) => s.toast)

  const [q, setQ] = useState('')
  const [cat, setCat] = useState('')
  const [stockF, setStockF] = useState<'' | 'low' | 'out'>('')
  const [editing, setEditing] = useState<Product | undefined>()
  const [editorOpen, setEditorOpen] = useState(false)
  const [deleting, setDeleting] = useState<Product | null>(null)

  const rows = useMemo(
    () =>
      products.filter((p) => {
        if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false
        if (cat && p.category !== cat) return false
        const t = totalStock(p)
        if (stockF === 'out' && t !== 0) return false
        if (stockF === 'low' && !(t > 0 && t <= LOW_STOCK_THRESHOLD)) return false
        return true
      }),
    [products, q, cat, stockF],
  )

  const openNew = () => { setEditing(undefined); setEditorOpen(true) }
  const openEdit = (p: Product) => { setEditing(p); setEditorOpen(true) }
  const save = (p: Product) => {
    const isNew = !products.some((x) => x.id === p.id)
    upsert(p)
    toast(isNew ? `“${p.name}” added` : `“${p.name}” updated`)
  }

  const thumb = (p: Product) => (
    <div className="w-12 shrink-0 overflow-hidden bg-sand"><div className="aspect-[3/4]"><FashionImage src={recolor(p.images[0], p.colors[0]?.hex ?? '#C98B9A')} alt="" category={p.category} /></div></div>
  )

  return (
    <>
      <PageTitle title="Products" sub={`${products.length} products in the demo catalogue`} action={<Button onClick={openNew}><Plus size={18} /> Add demo product</Button>} />

      <Card className="mb-4 flex flex-wrap items-center gap-3 p-3">
        <div className="relative min-w-[200px] flex-1">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft" />
          <label htmlFor="ap-q" className="sr-only">Search products</label>
          <input id="ap-q" className="field !min-h-10 !pl-10" placeholder="Search products" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <label className="sr-only" htmlFor="ap-cat">Category</label>
        <select id="ap-cat" className="field !min-h-10 !w-auto" value={cat} onChange={(e) => setCat(e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.label}</option>)}
        </select>
        <label className="sr-only" htmlFor="ap-stock">Stock level</label>
        <select id="ap-stock" className="field !min-h-10 !w-auto" value={stockF} onChange={(e) => setStockF(e.target.value as '' | 'low' | 'out')}>
          <option value="">Any stock</option>
          <option value="low">Low stock</option>
          <option value="out">Out of stock</option>
        </select>
      </Card>

      {rows.length === 0 ? (
        <Card className="p-12 text-center text-ink-soft">No products match these filters.</Card>
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden overflow-x-auto md:block">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-[12px] uppercase tracking-wider text-ink-soft">
                  <th className="p-4 font-medium">Product</th>
                  <th className="p-4 font-medium">Category</th>
                  <th className="p-4 font-medium">Price</th>
                  <th className="p-4 font-medium">Variants</th>
                  <th className="p-4 font-medium">Stock</th>
                  <th className="p-4 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((p) => (
                  <tr key={p.id} className="border-b border-line last:border-0 hover:bg-ivory/60">
                    <td className="p-4"><div className="flex items-center gap-3">{thumb(p)}<span className="max-w-[240px] font-medium">{p.name}</span></div></td>
                    <td className="p-4 text-ink-soft">{categoryLabel(p.category)}</td>
                    <td className="p-4 tabular-nums">{formatPrice(p.price)}</td>
                    <td className="p-4 text-ink-soft">{p.sizes.length} sizes · {p.colors.length} colours</td>
                    <td className="p-4"><StockPill n={totalStock(p)} /></td>
                    <td className="p-4">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEdit(p)} aria-label={`Edit ${p.name}`} className="grid size-10 place-items-center hover:bg-sand"><Pencil size={17} /></button>
                        <button onClick={() => setDeleting(p)} aria-label={`Delete ${p.name}`} className="grid size-10 place-items-center text-ink-soft hover:bg-[#fbeeee] hover:text-bad"><Trash2 size={17} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <ul className="space-y-3 md:hidden">
            {rows.map((p) => (
              <li key={p.id}>
                <Card className="flex gap-3 p-3">
                  {thumb(p)}
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{p.name}</p>
                    <p className="text-[13px] text-ink-soft">{categoryLabel(p.category)} · {formatPrice(p.price)}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <StockPill n={totalStock(p)} />
                      <div className="flex">
                        <button onClick={() => openEdit(p)} aria-label={`Edit ${p.name}`} className="grid size-11 place-items-center"><Pencil size={18} /></button>
                        <button onClick={() => setDeleting(p)} aria-label={`Delete ${p.name}`} className="grid size-11 place-items-center text-ink-soft"><Trash2 size={18} /></button>
                      </div>
                    </div>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        </>
      )}

      <ProductEditor open={editorOpen} product={editing} existingSlugs={products.map((p) => p.slug)} onClose={() => setEditorOpen(false)} onSave={save} />

      <Overlay open={!!deleting} onClose={() => setDeleting(null)} title="Delete product?" widthClass="max-w-md">
        <div className="space-y-5 p-6">
          <p className="text-ink-soft">“{deleting?.name}” will be removed from the demo catalogue and from any bags that contain it. You can restore defaults any time with “Reset demo data”.</p>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button className="!bg-bad hover:!bg-[#8a2f32]" onClick={() => { if (deleting) { remove(deleting.id); toast(`“${deleting.name}” deleted`, 'info') } setDeleting(null) }}>Delete</Button>
          </div>
        </div>
      </Overlay>
    </>
  )
}
