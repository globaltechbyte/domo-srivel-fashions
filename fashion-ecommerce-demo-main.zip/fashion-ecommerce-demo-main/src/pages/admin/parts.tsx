import { cn } from '../../lib/utils'
import type { OrderStatus, PaymentStatus } from '../../types'

const STATUS_STYLE: Record<OrderStatus, string> = {
  'Pending Confirmation': 'bg-[#fbf0dc] text-[#7a4d10]',
  Confirmed: 'bg-[#e3eefb] text-[#1f4f86]',
  Packed: 'bg-[#ece6f8] text-[#4c3a86]',
  Shipped: 'bg-[#dff2f1] text-[#1d6561]',
  Delivered: 'bg-[#e1f1e6] text-[#235c3a]',
  Cancelled: 'bg-[#f6e1e1] text-[#8a2c2f]',
}

export function StatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 whitespace-nowrap px-2.5 py-1 text-xs font-medium', STATUS_STYLE[status])}>
      <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
      {status}
    </span>
  )
}

export function PaymentBadge({ status }: { status: PaymentStatus }) {
  const tone = status === 'COD – Collected' ? 'bg-[#e1f1e6] text-[#235c3a]' : status === 'COD – Pending' ? 'bg-[#fbf0dc] text-[#7a4d10]' : 'bg-sand text-ink-soft'
  return <span className={cn('inline-block whitespace-nowrap px-2.5 py-1 text-xs font-medium', tone)}>{status}</span>
}

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={cn('border border-line bg-white', className)}>{children}</div>
}

export function PageTitle({ title, sub, action }: { title: string; sub?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-4xl md:text-5xl">{title}</h1>
        {sub && <p className="mt-1 text-ink-soft">{sub}</p>}
      </div>
      {action}
    </div>
  )
}
