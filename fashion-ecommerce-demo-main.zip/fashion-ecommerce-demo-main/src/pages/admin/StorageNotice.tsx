import { HardDrive, TriangleAlert } from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { mediaUsage, storageEstimate } from '../../lib/idb'
import { formatBytes, MEDIA_LIMITS } from '../../lib/media'
import { useSocial } from '../../store/social'
import { Card } from './parts'

/** Warns admins that uploads are local to this browser and shows how much space they use. */
export function StorageNotice() {
  const [usage, setUsage] = useState<{ count: number; bytes: number } | null | undefined>(undefined)
  const [quota, setQuota] = useState<{ usage: number; quota: number } | null>(null)
  // Re-measure whenever gallery metadata changes (uploads/deletes).
  const signature = useSocial((s) => JSON.stringify([s.instagram.map((i) => [i.media?.value, i.thumbnail?.value]), s.customers.map((c) => c.photo.value)]))

  const measure = useCallback(async () => {
    setUsage(await mediaUsage())
    setQuota(await storageEstimate())
  }, [])
  useEffect(() => {
    void measure()
    const t = setTimeout(() => void measure(), 800) // deletes are asynchronous
    return () => clearTimeout(t)
  }, [measure, signature])

  const pct = quota ? Math.min(100, (quota.usage / quota.quota) * 100) : 0

  return (
    <Card className="mb-6 border-warn/40 bg-[#fdf6ea] p-4 text-sm">
      <p className="flex items-center gap-2 font-medium text-[#7a4d10]"><TriangleAlert size={17} aria-hidden="true" /> Demo uploads live only in this browser</p>
      <ul className="mt-2 list-disc space-y-1 pl-5 text-ink-soft">
        <li>Uploaded photos and videos are stored in this browser&rsquo;s IndexedDB. They <strong>do not sync</strong> to other devices or browsers, and visitors on other devices won&rsquo;t see them.</li>
        <li>Clearing site data, using a private window, or low disk space can delete them. For a real site, host media on a CDN and use image URLs.</li>
        <li>Limits: images up to {formatBytes(MEDIA_LIMITS.imageBytes)} (resized to {MEDIA_LIMITS.maxImageDimension}px, metadata removed), videos up to {formatBytes(MEDIA_LIMITS.videoBytes)}.</li>
      </ul>
      <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-1 text-[13px] text-ink-soft">
        <span className="inline-flex items-center gap-1.5"><HardDrive size={15} aria-hidden="true" />
          {usage === undefined ? 'Measuring storage…' : usage === null ? 'Upload storage unavailable in this browser' : `${usage.count} uploaded ${usage.count === 1 ? 'file' : 'files'} · ${formatBytes(usage.bytes)}`}
        </span>
        {quota && (
          <span className="flex items-center gap-2">
            Browser storage {pct < 1 ? '<1' : Math.round(pct)}% used
            <span className="h-1.5 w-24 overflow-hidden bg-line" role="presentation"><span className="block h-full bg-rose" style={{ width: `${Math.max(pct, 2)}%` }} /></span>
          </span>
        )}
      </div>
    </Card>
  )
}
