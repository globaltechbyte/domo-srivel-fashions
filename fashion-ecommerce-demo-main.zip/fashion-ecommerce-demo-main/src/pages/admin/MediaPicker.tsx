import { ImagePlus, Link2, Trash2, Upload } from 'lucide-react'
import { useEffect, useId, useRef, useState } from 'react'
import { Button } from '../../components/ui/Button'
import { MediaView } from '../../components/ui/MediaView'
import { acceptFor, formatBytes, MEDIA_LIMITS, safeMediaUrl, validateFile, type MediaDraft } from '../../lib/media'
import type { MediaKind } from '../../types'

const FALLBACK = 'art:dresses:plain:front:C98B9A'

function Preview({ draft, alt }: { draft: MediaDraft; alt: string }) {
  if (draft.kind === 'existing') return <MediaView media={draft.ref} alt={alt} fallbackArt={FALLBACK} eager />
  if (draft.kind === 'url') {
    const ok = safeMediaUrl(draft.url)
    return ok ? <img src={ok} alt={alt} className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center bg-sand text-[11px] text-ink-soft">Invalid URL</div>
  }
  return draft.mediaKind === 'video' ? (
    <video src={draft.previewUrl} muted playsInline preload="metadata" className="h-full w-full object-cover" aria-label={alt} />
  ) : (
    <img src={draft.previewUrl} alt={alt} className="h-full w-full object-cover" />
  )
}

/**
 * Admin control for choosing a photo/video: upload a file or paste an image URL.
 * Nothing is written to storage until the parent form is saved (see lib/media `commitDraft`).
 */
export function MediaPicker({
  label,
  kinds,
  draft,
  onChange,
  hint,
  error,
  allowUrl = true,
}: {
  label: string
  kinds: MediaKind[]
  draft: MediaDraft | undefined
  onChange: (d: MediaDraft | undefined) => void
  hint?: string
  error?: string
  allowUrl?: boolean
}) {
  const id = useId()
  const input = useRef<HTMLInputElement>(null)
  const [fileError, setFileError] = useState<string | null>(null)
  const [showUrl, setShowUrl] = useState(draft?.kind === 'url')
  const previewUrl = draft?.kind === 'file' ? draft.previewUrl : null

  // Free the object URL when the file is replaced or the form closes.
  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl) }, [previewUrl])

  const pick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    const problem = validateFile(file, kinds)
    setFileError(problem)
    if (problem) return
    setShowUrl(false)
    onChange({ kind: 'file', file, previewUrl: URL.createObjectURL(file), mediaKind: file.type.startsWith('video/') ? 'video' : 'image' })
  }

  const what = kinds.length === 2 ? 'photo or video' : kinds[0] === 'video' ? 'video' : 'photo'
  const limits = [kinds.includes('image') && `images up to ${formatBytes(MEDIA_LIMITS.imageBytes)}`, kinds.includes('video') && `videos up to ${formatBytes(MEDIA_LIMITS.videoBytes)}`].filter(Boolean).join(', ')
  const msg = fileError ?? error

  return (
    <fieldset>
      <legend className="mb-1.5 text-sm">{label}</legend>
      <div className="flex gap-4">
        <div className="aspect-[3/4] w-24 shrink-0 overflow-hidden border border-line bg-sand">
          {draft ? <Preview draft={draft} alt={`${label} preview`} /> : <div className="grid h-full place-items-center text-ink-soft"><ImagePlus size={22} aria-hidden="true" /></div>}
        </div>
        <div className="min-w-0 flex-1 space-y-2">
          <input ref={input} id={`${id}-file`} type="file" accept={acceptFor(kinds)} onChange={pick} className="sr-only" aria-describedby={`${id}-hint`} />
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => input.current?.click()}><Upload size={15} aria-hidden="true" /> {draft ? `Replace ${what}` : `Upload ${what}`}</Button>
            {allowUrl && kinds.includes('image') && (
              <Button size="sm" variant="ghost" onClick={() => setShowUrl((v) => !v)} aria-expanded={showUrl}><Link2 size={15} aria-hidden="true" /> Image URL</Button>
            )}
            {draft && <Button size="sm" variant="ghost" onClick={() => { onChange(undefined); setShowUrl(false); setFileError(null) }}><Trash2 size={15} aria-hidden="true" /> Remove</Button>}
          </div>
          {draft?.kind === 'file' && <p className="text-[12px] text-ink-soft">{draft.file.name} · {formatBytes(draft.file.size)}{draft.mediaKind === 'image' && ' · will be resized'}</p>}
          {showUrl && (
            <div>
              <label htmlFor={`${id}-url`} className="sr-only">Image URL</label>
              <input id={`${id}-url`} className="field !min-h-10" inputMode="url" placeholder="https://… or /gallery/photo.jpg" value={draft?.kind === 'url' ? draft.url : ''} onChange={(e) => onChange(e.target.value ? { kind: 'url', url: e.target.value } : undefined)} />
            </div>
          )}
          <p id={`${id}-hint`} className="text-[12px] text-ink-soft">{hint ?? `JPG, PNG or WebP ${kinds.includes('video') ? 'or MP4/WebM/MOV ' : ''}— ${limits}.`}</p>
          {msg && <p role="alert" className="text-[13px] text-bad">{msg}</p>}
        </div>
      </div>
    </fieldset>
  )
}
