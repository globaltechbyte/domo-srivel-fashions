import { ShoppingBag } from 'lucide-react'
import { CartLineItem, ShippingProgress, SummaryRows } from '../components/product/CartParts'
import { ButtonLink } from '../components/ui/Button'
import { EmptyState } from '../components/ui/primitives'
import { useDocumentTitle } from '../hooks/useMisc'
import { useCartLines } from '../store/cart'

export default function Cart() {
  useDocumentTitle('Your bag')
  const { lines, subtotal, shipping, total, count } = useCartLines()
  const overStock = lines.some((l) => l.qty > l.maxQty)

  if (lines.length === 0) {
    return (
      <div className="container-x py-16">
        <EmptyState
          icon={<ShoppingBag size={34} strokeWidth={1.3} />}
          title="Your bag is empty"
          body="Your selections will appear here. Discover our latest pieces to begin."
          action={<ButtonLink to="/shop" size="lg">Continue shopping</ButtonLink>}
        />
      </div>
    )
  }

  return (
    <div className="container-x pb-8 pt-8 md:pt-12">
      <h1 className="text-5xl md:text-6xl">Your bag</h1>
      <p className="mt-2 text-ink-soft">{count} {count === 1 ? 'item' : 'items'}</p>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_400px] lg:gap-16">
        <ul className="divide-y divide-line border-y border-line">
          {lines.map((l) => <CartLineItem key={l.key} line={l} large />)}
        </ul>
        <aside className="h-fit space-y-6 bg-sand p-6 md:p-8 lg:sticky lg:top-28" aria-label="Order summary">
          <h2 className="text-3xl">Order summary</h2>
          <ShippingProgress subtotal={subtotal} />
          <SummaryRows subtotal={subtotal} shipping={shipping} total={total} />
          {overStock ? (
            <p role="alert" className="text-sm text-bad">Some items exceed available stock. Please adjust quantities.</p>
          ) : (
            <ButtonLink to="/checkout" size="lg" className="w-full">Proceed to checkout</ButtonLink>
          )}
          <ButtonLink to="/shop" variant="ghost" className="w-full">Continue shopping</ButtonLink>
          <p className="text-[13px] text-ink-soft">Pay by Cash on Delivery or order via WhatsApp. No online payment is taken in this demo.</p>
        </aside>
      </div>
    </div>
  )
}
