import { motion } from 'motion/react'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { FilterPanel, type Filters } from '../components/product/FilterPanel'
import { ProductCard } from '../components/product/ProductCard'
import { Button } from '../components/ui/Button'
import { Overlay } from '../components/ui/Overlay'
import { EmptyState, ProductCardSkeleton } from '../components/ui/primitives'
import { CATEGORIES, COLLECTIONS, categoryLabel } from '../data/products'
import { useDocumentTitle, useSimulatedLoading } from '../hooks/useMisc'
import { useCatalog } from '../store/catalog'
import type { CategorySlug } from '../types'

const PAGE_SIZE = 12
type Sort = 'featured' | 'newest' | 'price-asc' | 'price-desc'

const SORTS: { value: Sort; label: string }[] = [
  { value: 'featured', label: 'Featured' },
  { value: 'newest', label: 'Newest first' },
  { value: 'price-asc', label: 'Price: low to high' },
  { value: 'price-desc', label: 'Price: high to low' },
]

const list = (v: string | null) => (v ? v.split(',').filter(Boolean) : [])

export default function Shop() {
  const products = useCatalog((s) => s.products)
  const [params, setParams] = useSearchParams()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [visible, setVisible] = useState(PAGE_SIZE)

  const bounds = useMemo(() => {
    const prices = products.map((p) => p.price)
    const lo = prices.length ? Math.floor(Math.min(...prices) / 500) * 500 : 0
    const hi = prices.length ? Math.ceil(Math.max(...prices) / 500) * 500 : 20000
    return { min: lo, max: hi }
  }, [products])

  const category = (params.get('category') ?? '') as CategorySlug | ''
  const q = params.get('q') ?? ''
  const sort = (params.get('sort') as Sort) || 'featured'
  const onlyNew = params.get('new') === '1'
  const collection = COLLECTIONS.find((c) => c.slug === params.get('collection'))
  const filters: Filters = {
    category: CATEGORIES.some((c) => c.slug === category) ? category : '',
    sizes: list(params.get('sizes')),
    colors: list(params.get('colors')),
    min: Number(params.get('min')) || bounds.min,
    max: Number(params.get('max')) || bounds.max,
  }

  const title = collection ? collection.title : onlyNew ? 'New Arrivals' : filters.category ? categoryLabel(filters.category) : 'All Pieces'
  useDocumentTitle(title)
  const loading = useSimulatedLoading(420, params.get('category') + '|' + onlyNew)

  const update = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(params)
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === '') next.delete(k)
      else next.set(k, v)
    }
    setParams(next, { replace: true })
  }

  const onFilterChange = (f: Partial<Filters>) => {
    const patch: Record<string, string | null> = {}
    if ('category' in f) {
      patch.category = f.category || null
      patch.new = null
      patch.collection = null
    }
    if (f.sizes) patch.sizes = f.sizes.join(',') || null
    if (f.colors) patch.colors = f.colors.join(',') || null
    if (f.min !== undefined) patch.min = f.min <= bounds.min ? null : String(f.min)
    if (f.max !== undefined) patch.max = f.max >= bounds.max ? null : String(f.max)
    update(patch)
  }

  const allSizes = useMemo(() => {
    const order = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Free Size']
    return order.filter((s) => products.some((p) => p.sizes.includes(s)))
  }, [products])

  const allColors = useMemo(() => {
    const m = new Map<string, string>()
    products.forEach((p) => p.colors.forEach((c) => m.set(c.name, c.hex)))
    return [...m].map(([name, hex]) => ({ name, hex }))
  }, [products])

  const matches = (p: (typeof products)[number], ignoreCategory = false) => {
    if (!ignoreCategory && filters.category && p.category !== filters.category) return false
    if (onlyNew && !p.isNew) return false
    if (collection && p.collection !== collection.slug) return false
    if (q && !`${p.name} ${categoryLabel(p.category)} ${p.fabric}`.toLowerCase().includes(q.toLowerCase())) return false
    if (p.price < filters.min || p.price > filters.max) return false
    if (filters.sizes.length && !filters.sizes.some((s) => p.sizes.includes(s))) return false
    if (filters.colors.length && !filters.colors.some((c) => p.colors.some((pc) => pc.name === c))) return false
    return true
  }

  const results = useMemo(() => {
    const out = products.filter((p) => matches(p))
    switch (sort) {
      case 'newest':
        return out.sort((a, b) => Number(b.isNew) - Number(a.isNew) || b.id.localeCompare(a.id))
      case 'price-asc':
        return out.sort((a, b) => a.price - b.price)
      case 'price-desc':
        return out.sort((a, b) => b.price - a.price)
      default:
        return out.sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products, params, bounds])

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: products.filter((p) => matches(p, true)).length }
    for (const cat of CATEGORIES) c[cat.slug] = products.filter((p) => matches(p, true) && p.category === cat.slug).length
    return c
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products, params, bounds])

  useEffect(() => setVisible(PAGE_SIZE), [params])

  const chips: { label: string; clear: () => void }[] = []
  if (collection) chips.push({ label: collection.title, clear: () => update({ collection: null }) })
  if (onlyNew) chips.push({ label: 'New arrivals', clear: () => update({ new: null }) })
  if (filters.category) chips.push({ label: categoryLabel(filters.category), clear: () => update({ category: null }) })
  if (q) chips.push({ label: `“${q}”`, clear: () => update({ q: null }) })
  filters.sizes.forEach((s) => chips.push({ label: `Size ${s}`, clear: () => onFilterChange({ sizes: filters.sizes.filter((x) => x !== s) }) }))
  filters.colors.forEach((c) => chips.push({ label: c, clear: () => onFilterChange({ colors: filters.colors.filter((x) => x !== c) }) }))
  if (filters.min > bounds.min || filters.max < bounds.max) chips.push({ label: `₹${filters.min.toLocaleString('en-IN')} – ₹${filters.max.toLocaleString('en-IN')}`, clear: () => update({ min: null, max: null }) })

  const clearAll = () => setParams(sort !== 'featured' ? { sort } : {}, { replace: true })
  const shown = results.slice(0, visible)

  const panel = (
    <FilterPanel filters={filters} onChange={onFilterChange} bounds={bounds} sizes={allSizes} colors={allColors} counts={counts} />
  )

  return (
    <div className="container-x pb-8 pt-8 md:pt-12">
      <header className="mb-8 md:mb-10">
        <p className="eyebrow mb-3">Shop</p>
        <h1 className="text-5xl md:text-6xl">{title}</h1>
        {(collection || filters.category) && (
          <p className="mt-3 max-w-xl text-ink-soft">{collection ? collection.blurb : CATEGORIES.find((c) => c.slug === filters.category)?.blurb}</p>
        )}
      </header>

      <div className="sticky top-16 z-30 -mx-4 mb-6 border-y border-line bg-ivory/95 px-4 backdrop-blur md:static md:mx-0 md:border-0 md:bg-transparent md:px-0 md:backdrop-blur-none lg:top-20">
        <div className="flex flex-wrap items-center gap-3 py-3 md:py-0">
          <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setMobileOpen(true)}>
            <SlidersHorizontal size={16} /> Filters{chips.length > 0 && ` (${chips.length})`}
          </Button>
          <div className="relative order-last w-full basis-full md:order-none md:max-w-xs md:flex-1 md:basis-auto">
            <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft" />
            <label htmlFor="shop-q" className="sr-only">Search products</label>
            <input
              id="shop-q"
              value={q}
              onChange={(e) => update({ q: e.target.value })}
              placeholder="Search by name"
              className="field !min-h-10 !pl-10 text-[14px]"
            />
          </div>
          <p className="hidden text-sm text-ink-soft md:block" aria-live="polite">
            {results.length} {results.length === 1 ? 'piece' : 'pieces'}
          </p>
          <div className="ml-auto flex items-center gap-2">
            <label htmlFor="sort" className="hidden text-sm text-ink-soft sm:block">Sort by</label>
            <select id="sort" value={sort} onChange={(e) => update({ sort: e.target.value === 'featured' ? null : e.target.value })} className="field !min-h-10 !w-auto pr-8 text-[14px]">
              {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>
        </div>
      </div>

      {chips.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-2">
          {chips.map((c) => (
            <button key={c.label} onClick={c.clear} className="inline-flex min-h-9 items-center gap-1.5 bg-sand px-3 text-[13px] transition-colors hover:bg-line">
              {c.label} <X size={14} aria-label="Remove filter" />
            </button>
          ))}
          <button onClick={clearAll} className="min-h-9 px-2 text-[13px] underline underline-offset-4 hover:text-rose">Clear filters</button>
        </div>
      )}

      <div className="lg:grid lg:grid-cols-[250px_1fr] lg:gap-12 xl:grid-cols-[270px_1fr] xl:gap-16">
        <aside className="hidden lg:block" aria-label="Filters">
          <div className="sticky top-28 max-h-[calc(100vh-8rem)] overflow-y-auto pr-2">{panel}</div>
        </aside>

        <section aria-label="Products">
          <p className="mb-4 text-sm text-ink-soft md:hidden" aria-live="polite">
            {results.length} {results.length === 1 ? 'piece' : 'pieces'}
          </p>
          {loading ? (
            <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:gap-x-6 xl:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => <ProductCardSkeleton key={i} />)}
            </div>
          ) : results.length === 0 ? (
            <EmptyState
              icon={<Search size={32} strokeWidth={1.3} />}
              title="No pieces found"
              body="Nothing matches those filters. Try removing a few or browse everything."
              action={<Button onClick={clearAll}>Clear all filters</Button>}
            />
          ) : (
            <>
              <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:gap-x-6 xl:grid-cols-3">
                {shown.map((p, i) => (
                  <motion.div key={p.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: Math.min(i % PAGE_SIZE, 8) * 0.04 }}>
                    <ProductCard product={p} priority={i < 4} />
                  </motion.div>
                ))}
              </div>
              {visible < results.length && (
                <div className="mt-14 text-center">
                  <p className="mb-4 text-sm text-ink-soft">Showing {shown.length} of {results.length}</p>
                  <Button variant="outline" size="lg" onClick={() => setVisible((v) => v + PAGE_SIZE)}>Load more</Button>
                </div>
              )}
            </>
          )}
        </section>
      </div>

      <Overlay
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        mode="drawer"
        title="Filters"
        widthClass="max-w-[400px]"
        footer={
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" onClick={clearAll}>Clear all</Button>
            <Button onClick={() => setMobileOpen(false)}>Show {results.length}</Button>
          </div>
        }
      >
        <div className="px-5">{panel}</div>
      </Overlay>
    </div>
  )
}
