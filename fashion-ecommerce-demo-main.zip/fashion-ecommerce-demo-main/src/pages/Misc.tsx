import { motion } from 'motion/react'
import { Compass, Heart } from 'lucide-react'
import { Component, useMemo, type ErrorInfo, type ReactNode } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ProductCard } from '../components/product/ProductCard'
import { ButtonLink } from '../components/ui/Button'
import { FashionImage } from '../components/ui/FashionImage'
import { EmptyState, Reveal, SectionHeading } from '../components/ui/primitives'
import { PAGES } from '../data/content'
import { COLLECTIONS } from '../data/products'
import { useDocumentTitle } from '../hooks/useMisc'
import { makeArt } from '../lib/art'
import { useCatalog } from '../store/catalog'
import { useWishlist } from '../store/ui'

export function Wishlist() {
  useDocumentTitle('Wishlist')
  const ids = useWishlist((s) => s.ids)
  const products = useCatalog((s) => s.products)
  const items = useMemo(() => products.filter((p) => ids.includes(p.id)), [products, ids])
  return (
    <div className="container-x pb-8 pt-8 md:pt-12">
      <h1 className="text-5xl md:text-6xl">Wishlist</h1>
      <p className="mt-2 text-ink-soft">Saved in this browser (demo).</p>
      {items.length === 0 ? (
        <EmptyState icon={<Heart size={32} strokeWidth={1.3} />} title="Nothing saved yet" body="Tap the heart on any piece to keep it here for later." action={<ButtonLink to="/shop" size="lg">Explore the collection</ButtonLink>} />
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-x-3 gap-y-10 md:gap-x-6 lg:grid-cols-4">
          {items.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}

export function Collections() {
  useDocumentTitle('Collections')
  return (
    <div className="container-x pb-8 pt-8 md:pt-12">
      <SectionHeading eyebrow="Curated" title="Collections" />
      <div className="grid gap-5 md:grid-cols-2">
        {COLLECTIONS.map((c, i) => (
          <Reveal key={c.slug} delay={(i % 2) * 0.08}>
            <Link to={`/shop?collection=${c.slug}`} className="group relative block aspect-[4/5] overflow-hidden bg-sand md:aspect-[5/6]">
              <div className="h-full w-full transition-transform duration-[900ms] ease-out group-hover:scale-105">
                <FashionImage src={makeArt({ category: c.category, pattern: 'butti', view: 'styled', hex: c.hex })} alt={c.title} category={c.category} />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 text-white md:p-9">
                <h2 className="text-4xl md:text-5xl">{c.title}</h2>
                <p className="mt-2 max-w-sm text-white/85">{c.blurb}</p>
                <span className="mt-4 inline-block border-b border-white/70 pb-0.5 text-sm tracking-wide">Shop the edit</span>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </div>
  )
}

export function StaticPage() {
  const { slug = '' } = useParams()
  const page = PAGES[slug]
  useDocumentTitle(page?.title ?? 'Not found')
  if (!page) return <NotFound />
  return (
    <div className="container-x pb-8 pt-10 md:pt-16">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-5xl md:text-6xl">{page.title}</h1>
        <p className="mt-3 text-[13px] text-ink-soft">Sample content for the demo. Replace with your own before launch.</p>
        <div className="mt-10 space-y-8">
          {page.sections.map((s) => (
            <section key={s.h}>
              <h2 className="mb-2 text-3xl">{s.h}</h2>
              <p className="leading-relaxed text-ink-soft">{s.p}</p>
            </section>
          ))}
        </div>
      </div>
    </div>
  )
}

export function NotFound() {
  useDocumentTitle('Page not found')
  return (
    <div className="container-x py-16">
      <EmptyState
        icon={<Compass size={34} strokeWidth={1.3} />}
        title="This page has wandered off"
        body="The link may be broken or the page may have moved. Let's get you back to something beautiful."
        action={<div className="flex flex-col gap-3 sm:flex-row"><ButtonLink to="/" size="lg">Go home</ButtonLink><ButtonLink to="/shop" size="lg" variant="outline">Shop all</ButtonLink></div>}
      />
    </div>
  )
}

interface BoundaryState { error: Error | null }
export class ErrorBoundary extends Component<{ children: ReactNode }, BoundaryState> {
  state: BoundaryState = { error: null }
  static getDerivedStateFromError(error: Error) { return { error } }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error(error, info.componentStack) }
  render() {
    if (!this.state.error) return this.props.children
    return (
      <div className="grid min-h-dvh place-items-center bg-ivory px-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="max-w-md text-center">
          <p className="font-brand text-3xl font-semibold tracking-[-0.025em]">Srivel Fashion House</p>
          <h1 className="mt-8 text-4xl">Something went awry</h1>
          <p className="mt-3 text-ink-soft">An unexpected error occurred. Your bag is safe. Please reload the page.</p>
          <div className="mt-8 flex justify-center gap-3">
            <button onClick={() => window.location.reload()} className="min-h-12 bg-rose px-6 text-sm font-medium text-white hover:bg-rose-deep">Reload</button>
            <a href="/" className="grid min-h-12 place-items-center border border-charcoal px-6 text-sm font-medium">Go home</a>
          </div>
        </motion.div>
      </div>
    )
  }
}
