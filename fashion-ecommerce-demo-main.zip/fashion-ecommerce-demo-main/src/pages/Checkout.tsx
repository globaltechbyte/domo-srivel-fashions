import { AlertTriangle, Banknote, Info } from 'lucide-react'
import { useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { SummaryRows } from '../components/product/CartParts'
import { Button, ButtonLink } from '../components/ui/Button'
import { WhatsAppIcon } from '../components/ui/BrandIcons'
import { FashionImage } from '../components/ui/FashionImage'
import { EmptyState } from '../components/ui/primitives'
import { WHATSAPP_IS_PLACEHOLDER } from '../config'
import { useDocumentTitle } from '../hooks/useMisc'
import { recolor } from '../lib/art'
import { cn, demoOrderRef, formatPrice, INDIAN_STATES, validateCustomer, type FieldErrors } from '../lib/utils'
import { buildWhatsAppMessage, whatsappUrl } from '../lib/whatsapp'
import { useCart, useCartLines } from '../store/cart'
import { useOrders } from '../store/orders'
import type { CustomerDetails, Order } from '../types'

const EMPTY: CustomerDetails = { fullName: '', mobile: '', address1: '', address2: '', city: '', state: '', pincode: '', landmark: '' }
type Method = 'whatsapp' | 'cod'

function Field({ id, label, error, optional, children }: { id: string; label: string; error?: string; optional?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm">
        {label} {optional && <span className="text-ink-soft">(optional)</span>}
      </label>
      {children}
      {error && <p id={`${id}-err`} role="alert" className="mt-1.5 text-[13px] text-bad">{error}</p>}
    </div>
  )
}

export default function Checkout() {
  useDocumentTitle('Checkout')
  const { lines, subtotal, shipping, total } = useCartLines()
  const clear = useCart((s) => s.clear)
  const addOrder = useOrders((s) => s.add)
  const navigate = useNavigate()
  const formRef = useRef<HTMLFormElement>(null)

  const [form, setForm] = useState<CustomerDetails>(EMPTY)
  const [errors, setErrors] = useState<FieldErrors>({})
  const [method, setMethod] = useState<Method>('whatsapp')
  const [submitting, setSubmitting] = useState(false)

  if (lines.length === 0) {
    return (
      <div className="container-x py-16">
        <EmptyState title="Nothing to check out yet" body="Add something you love to your bag first." action={<ButtonLink to="/shop" size="lg">Browse the collection</ButtonLink>} />
      </div>
    )
  }

  const overStock = lines.filter((l) => l.qty > l.maxQty)
  const set = (k: keyof CustomerDetails) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }))
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }))
  }
  const blur = (k: keyof CustomerDetails) => () => {
    const e = validateCustomer(form)[k]
    setErrors((er) => ({ ...er, [k]: e }))
  }
  const ia = (k: keyof CustomerDetails) => ({
    'aria-invalid': !!errors[k],
    'aria-describedby': errors[k] ? `${k}-err` : undefined,
  })

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (submitting || overStock.length) return
    const clean: CustomerDetails = {
      ...form,
      fullName: form.fullName.trim(),
      mobile: form.mobile.replace(/\s|-/g, ''),
      address1: form.address1.trim(),
      address2: form.address2.trim(),
      city: form.city.trim(),
      pincode: form.pincode.trim(),
      landmark: form.landmark.trim(),
    }
    const errs = validateCustomer(clean)
    setErrors(errs)
    const firstBad = (Object.keys(errs) as (keyof CustomerDetails)[])[0]
    if (firstBad) {
      formRef.current?.querySelector<HTMLElement>(`#${firstBad}`)?.focus()
      return
    }

    setSubmitting(true)
    const ref = demoOrderRef()
    const orderLines = lines.map((l) => ({ productId: l.productId, name: l.product.name, size: l.size, color: l.color, qty: l.qty, unitPrice: l.unitPrice }))
    const createdAt = new Date().toISOString()
    const order: Order = {
      id: `ord-${Date.now()}`,
      ref,
      createdAt,
      history: [{ status: 'Pending Confirmation', at: createdAt }],
      customer: clean,
      lines: orderLines,
      subtotal,
      shipping,
      total,
      method,
      status: 'Pending Confirmation',
      paymentStatus: method === 'cod' ? 'COD – Pending' : 'Not applicable',
    }

    if (method === 'whatsapp') {
      const msg = buildWhatsAppMessage({ ref, lines: orderLines, subtotal, shipping, total, customer: { ...clean, mobile: `+91 ${clean.mobile}` } })
      window.open(whatsappUrl(msg), '_blank', 'noopener,noreferrer')
    }
    addOrder(order)
    clear()
    navigate(`/order/${order.id}`, { replace: true })
  }

  return (
    <div className="container-x pb-8 pt-8 md:pt-12">
      <h1 className="text-5xl md:text-6xl">Checkout</h1>
      <p className="mt-2 text-ink-soft">Demo checkout. No payment is taken and no real order is placed.</p>

      <form ref={formRef} onSubmit={submit} noValidate className="mt-8 grid gap-10 lg:grid-cols-[1fr_420px] lg:gap-16">
        <div className="space-y-10">
          <fieldset>
            <legend className="mb-5 font-serif text-3xl">Delivery details</legend>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Field id="fullName" label="Full name" error={errors.fullName}>
                  <input id="fullName" className="field" autoComplete="name" value={form.fullName} onChange={set('fullName')} onBlur={blur('fullName')} {...ia('fullName')} />
                </Field>
              </div>
              <div className="sm:col-span-2">
                <Field id="mobile" label="Mobile number" error={errors.mobile}>
                  <div className="flex">
                    <span className="grid min-w-14 place-items-center border border-r-0 border-line bg-sand text-sm">+91</span>
                    <input id="mobile" className="field" inputMode="numeric" autoComplete="tel-national" maxLength={12} placeholder="10-digit number" value={form.mobile} onChange={set('mobile')} onBlur={blur('mobile')} {...ia('mobile')} />
                  </div>
                </Field>
              </div>
              <div className="sm:col-span-2">
                <Field id="address1" label="Address line 1" error={errors.address1}>
                  <input id="address1" className="field" autoComplete="address-line1" placeholder="House / flat no., street" value={form.address1} onChange={set('address1')} onBlur={blur('address1')} {...ia('address1')} />
                </Field>
              </div>
              <div className="sm:col-span-2">
                <Field id="address2" label="Address line 2" optional>
                  <input id="address2" className="field" autoComplete="address-line2" placeholder="Area, locality" value={form.address2} onChange={set('address2')} />
                </Field>
              </div>
              <Field id="city" label="City" error={errors.city}>
                <input id="city" className="field" autoComplete="address-level2" value={form.city} onChange={set('city')} onBlur={blur('city')} {...ia('city')} />
              </Field>
              <Field id="state" label="State" error={errors.state}>
                <select id="state" className="field" autoComplete="address-level1" value={form.state} onChange={set('state')} onBlur={blur('state')} {...ia('state')}>
                  <option value="">Select state</option>
                  {INDIAN_STATES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </Field>
              <Field id="pincode" label="PIN code" error={errors.pincode}>
                <input id="pincode" className="field" inputMode="numeric" autoComplete="postal-code" maxLength={6} placeholder="6 digits" value={form.pincode} onChange={set('pincode')} onBlur={blur('pincode')} {...ia('pincode')} />
              </Field>
              <Field id="landmark" label="Landmark" optional>
                <input id="landmark" className="field" value={form.landmark} onChange={set('landmark')} />
              </Field>
            </div>
          </fieldset>

          <fieldset>
            <legend className="mb-5 font-serif text-3xl">How would you like to order?</legend>
            <div className="grid gap-3 sm:grid-cols-2" role="radiogroup">
              {([
                { v: 'whatsapp', t: 'Order via WhatsApp', s: 'Send a pre-filled message. We confirm availability and share payment details.', i: <WhatsAppIcon /> },
                { v: 'cod', t: 'Cash on Delivery', s: 'Place a simulated order and pay on delivery. Status: Pending Confirmation.', i: <Banknote size={20} /> },
              ] as const).map((o) => (
                <label key={o.v} className={cn('flex cursor-pointer gap-4 border p-5 transition-colors', method === o.v ? 'border-charcoal bg-white' : 'border-line bg-white/50 hover:border-charcoal/50')}>
                  <input type="radio" name="method" value={o.v} checked={method === o.v} onChange={() => setMethod(o.v)} className="mt-1 size-4 accent-[var(--color-rose)]" />
                  <span>
                    <span className="flex items-center gap-2 font-medium">{o.i} {o.t}</span>
                    <span className="mt-1 block text-sm text-ink-soft">{o.s}</span>
                  </span>
                </label>
              ))}
            </div>

            {method === 'whatsapp' ? (
              <div className="mt-4 flex gap-3 bg-rose-mist p-4 text-sm" role="note">
                <Info size={18} className="mt-0.5 shrink-0 text-rose" />
                <p>
                  WhatsApp will open with your order pre-filled. <strong>You must press send in WhatsApp</strong> — your order is not confirmed until the store replies.
                  {WHATSAPP_IS_PLACEHOLDER && ' The WhatsApp number in this demo is a placeholder (edit src/config.ts), so the chat will not reach a real shop.'}
                </p>
              </div>
            ) : (
              <div className="mt-4 flex gap-3 bg-rose-mist p-4 text-sm" role="note">
                <Info size={18} className="mt-0.5 shrink-0 text-rose" />
                <p>This is a <strong>simulated</strong> Cash on Delivery order saved only in this browser. No business receives it.</p>
              </div>
            )}
          </fieldset>
        </div>

        <aside className="h-fit space-y-6 bg-sand p-6 md:p-8 lg:sticky lg:top-28" aria-label="Order summary">
          <h2 className="text-3xl">Order summary</h2>
          <ul className="space-y-4">
            {lines.map((l) => {
              const hex = l.product.colors.find((c) => c.name === l.color)?.hex
              return (
                <li key={l.key} className="flex gap-3">
                  <div className="relative w-16 shrink-0 overflow-hidden bg-white">
                    <div className="aspect-[3/4]"><FashionImage src={hex ? recolor(l.product.images[0], hex) : l.product.images[0]} alt="" category={l.product.category} /></div>
                    <span className="absolute -right-0 top-0 grid min-w-5 place-items-center bg-charcoal px-1 text-[11px] text-white">{l.qty}</span>
                  </div>
                  <div className="min-w-0 flex-1 text-sm">
                    <p className="line-clamp-2">{l.product.name}</p>
                    <p className="text-ink-soft">{l.color} · {l.size}</p>
                  </div>
                  <p className="text-sm tabular-nums">{formatPrice(l.lineTotal)}</p>
                </li>
              )
            })}
          </ul>
          <SummaryRows subtotal={subtotal} shipping={shipping} total={total} />
          {overStock.length > 0 && (
            <p role="alert" className="flex gap-2 text-sm text-bad"><AlertTriangle size={18} className="shrink-0" /> Some items exceed available stock. <Link to="/cart" className="underline">Update your bag</Link></p>
          )}
          <Button type="submit" size="lg" className="w-full" disabled={submitting || overStock.length > 0}>
            {method === 'whatsapp' ? <><WhatsAppIcon /> Send order on WhatsApp</> : 'Place demo COD order'}
          </Button>
          {Object.keys(errors).some((k) => errors[k as keyof CustomerDetails]) && (
            <p role="alert" className="text-sm text-bad">Please fix the highlighted fields above.</p>
          )}
        </aside>
      </form>
    </div>
  )
}
