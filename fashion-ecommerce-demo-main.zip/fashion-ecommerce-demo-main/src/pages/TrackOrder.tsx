import { AnimatePresence, motion } from 'motion/react'
import { ExternalLink, Info, Loader2, PackageSearch, SearchX } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { OrderTimeline } from '../components/order/OrderTimeline'
import { Button, ButtonLink } from '../components/ui/Button'
import { Skeleton } from '../components/ui/primitives'
import { DEMO_TEST_ORDER } from '../data/orders'
import { useDocumentTitle } from '../hooks/useMisc'
import { SHIPPING } from '../config'
import {
  buildTimeline, findOrder, maskMobile, maskName, maskPincode, safeTrackingUrl, validateTrackInput, type TrackErrors, type TrackInput,
} from '../lib/tracking'
import { formatDate, formatPrice } from '../lib/utils'
import { useOrders } from '../store/orders'
import type { Order } from '../types'
import { PaymentBadge, StatusBadge } from './admin/parts'

const EASE = [0.22, 1, 0.36, 1] as const
type Phase = 'idle' | 'loading' | 'done'

function DetailCard({ title, children, delay = 0 }: { title: string; children: React.ReactNode; delay?: number }) {
  return (
    <motion.section initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, delay, ease: EASE }} className="border border-line bg-white p-5 md:p-6">
      <h3 className="mb-3 text-2xl">{title}</h3>
      {children}
    </motion.section>
  )
}

function ShippingCard({ order }: { order: Order }) {
  const info = order.shippingInfo
  const safeUrl = safeTrackingUrl(info?.trackingUrl)
  const shippedOrBeyond = order.status === 'Shipped' || order.status === 'Delivered'
  const hasAny = !!(info?.courierName || info?.trackingNumber || safeUrl)

  return (
    <DetailCard title="Shipping" delay={0.1}>
      {order.status === 'Cancelled' ? (
        <p className="text-sm text-ink-soft">This order was cancelled, so nothing will be shipped.</p>
      ) : hasAny ? (
        <dl className="space-y-2.5 text-sm">
          {info?.courierName && <div className="flex justify-between gap-4"><dt className="text-ink-soft">Courier</dt><dd className="text-right">{info.courierName}</dd></div>}
          {info?.trackingNumber && <div className="flex justify-between gap-4"><dt className="text-ink-soft">Tracking no.</dt><dd className="break-all text-right font-medium tabular-nums">{info.trackingNumber}</dd></div>}
          {safeUrl && (
            <div className="pt-2">
              <a
                href={safeUrl}
                target="_blank"
                rel="noopener noreferrer nofollow"
                className="inline-flex min-h-11 items-center gap-2 border border-charcoal px-4 text-sm font-medium transition-colors hover:bg-charcoal hover:text-white"
              >
                Track with courier <ExternalLink size={15} aria-hidden="true" />
                <span className="sr-only">(opens an external website in a new tab)</span>
              </a>
              <p className="mt-2 text-[12px] text-ink-soft">Opens the courier&rsquo;s own website. We don&rsquo;t control its content.</p>
            </div>
          )}
        </dl>
      ) : (
        <p className="text-sm text-ink-soft">
          {shippedOrBeyond ? 'No courier details were added for this order.' : 'Courier and tracking details will appear here once your order is shipped.'}
        </p>
      )}
      {order.status !== 'Delivered' && order.status !== 'Cancelled' && (
        <p className="mt-4 border-t border-line pt-3 text-[13px] text-ink-soft">Standard delivery is usually {SHIPPING.eta} after confirmation.</p>
      )}
    </DetailCard>
  )
}

function Result({ order }: { order: Order }) {
  const steps = useMemo(() => buildTimeline(order), [order])
  const isDemo = order.isSample || order.isDemoTest || order.ref.startsWith('AUR-DEMO-')
  const c = order.customer

  return (
    <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.45, ease: EASE }} className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4 border border-line bg-white p-5 md:p-6">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-ink-soft">Order</p>
            {order.isDemoTest && <span className="bg-charcoal px-2 py-0.5 text-[11px] font-medium uppercase tracking-[0.12em] text-white">Demo test order</span>}
            {order.isSample && !order.isDemoTest && <span className="bg-sand px-2 py-0.5 text-[11px] font-medium uppercase tracking-[0.12em] text-ink-soft">Sample</span>}
          </div>
          <p className="font-serif text-3xl tracking-wide md:text-4xl">{order.ref}</p>
          <p className="mt-1 text-sm text-ink-soft">Placed {formatDate(order.createdAt)}</p>
        </div>
        <div className="flex flex-col items-start gap-2 md:items-end">
          <StatusBadge status={order.status} />
          <PaymentBadge status={order.paymentStatus} />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr] lg:gap-8">
        <section className="border border-line bg-white p-5 md:p-8" aria-labelledby="tl-h">
          <h2 id="tl-h" className="mb-7 text-3xl">Order progress</h2>
          <OrderTimeline steps={steps} />
        </section>

        <div className="space-y-6">
          <DetailCard title="Items" delay={0.05}>
            <ul className="divide-y divide-line">
              {order.lines.map((l, i) => (
                <li key={i} className="flex justify-between gap-4 py-3 text-sm first:pt-0">
                  <span>{l.name}<span className="block text-ink-soft">{l.color} · Size {l.size} · Qty {l.qty}</span></span>
                  <span className="tabular-nums">{formatPrice(l.unitPrice * l.qty)}</span>
                </li>
              ))}
            </ul>
            <dl className="mt-3 space-y-1 border-t border-line pt-3 text-sm">
              <div className="flex justify-between"><dt className="text-ink-soft">Shipping</dt><dd className="tabular-nums">{order.shipping ? formatPrice(order.shipping) : 'Free'}</dd></div>
              <div className="flex justify-between text-base font-medium"><dt>Total</dt><dd className="tabular-nums">{formatPrice(order.total)}</dd></div>
              <div className="flex justify-between pt-2"><dt className="text-ink-soft">Payment</dt><dd>{order.method === 'cod' ? 'Cash on Delivery' : 'WhatsApp order'}</dd></div>
            </dl>
          </DetailCard>

          <ShippingCard order={order} />

          <DetailCard title="Delivering to" delay={0.15}>
            <p className="text-sm leading-relaxed">
              {maskName(c.fullName)}<br />
              {c.city}, {c.state} – {maskPincode(c.pincode)}<br />
              <span className="text-ink-soft">Mobile {maskMobile(c.mobile)}</span>
            </p>
            <p className="mt-3 text-[12px] text-ink-soft">Full address details are hidden here to protect your privacy.</p>
          </DetailCard>
        </div>
      </div>

      {isDemo && (
        <p className="text-center text-[13px] text-ink-soft">
          Demo tracking: statuses are set by the demo admin in this browser. No real courier or fulfilment is involved.
        </p>
      )}
    </motion.div>
  )
}

export default function TrackOrder() {
  useDocumentTitle('Track your order')
  const [params] = useSearchParams()
  const orders = useOrders((s) => s.orders)
  const [form, setForm] = useState<TrackInput>({ ref: params.get('ref') ?? '', mobile: '' })
  const [errors, setErrors] = useState<TrackErrors>({})
  const [phase, setPhase] = useState<Phase>('idle')
  const [query, setQuery] = useState<TrackInput | null>(null)
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined)
  const resultRef = useRef<HTMLDivElement>(null)

  useEffect(() => () => clearTimeout(timer.current), [])

  // Live: re-evaluates whenever the order store changes (e.g. admin updates a status in another tab).
  const order = query ? findOrder(orders, query) : undefined

  const lookup = (input: TrackInput) => {
    const errs = validateTrackInput(input)
    setErrors(errs)
    if (errs.ref || errs.mobile) {
      document.getElementById(errs.ref ? 'tr-ref' : 'tr-mobile')?.focus()
      return
    }
    setPhase('loading')
    setQuery(null)
    clearTimeout(timer.current)
    timer.current = setTimeout(() => {
      setQuery(input)
      setPhase('done')
      setTimeout(() => resultRef.current?.focus({ preventScroll: false }), 80)
    }, 750)
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (phase !== 'loading') lookup(form)
  }

  const fillDemo = () => {
    const next = { ref: DEMO_TEST_ORDER.ref, mobile: DEMO_TEST_ORDER.mobile }
    setForm(next)
    setErrors({})
    lookup(next)
  }

  const ia = (k: keyof TrackErrors) => ({ 'aria-invalid': !!errors[k], 'aria-describedby': errors[k] ? `tr-${k}-err` : undefined })

  return (
    <div className="container-x pb-8 pt-8 md:pt-14">
      <header className="mx-auto max-w-2xl text-center">
        <p className="eyebrow mb-3">Order tracking</p>
        <h1 className="text-5xl md:text-6xl">Track your order</h1>
        <p className="mt-4 text-ink-soft">Enter your order ID and the mobile number you used at checkout.</p>
      </header>

      <div className="mx-auto mt-8 flex max-w-2xl gap-3 border border-dashed border-rose/50 bg-rose-mist p-4 text-sm" role="note">
        <Info size={18} className="mt-0.5 shrink-0 text-rose" aria-hidden="true" />
        <p>
          <strong>Demo tracking.</strong> This looks up simulated orders saved in this browser only. It does not connect to a courier or a real fulfilment system,
          and it does not sync between devices.
        </p>
      </div>

      <form onSubmit={submit} noValidate className="mx-auto mt-6 max-w-2xl border border-line bg-white p-5 md:p-8">
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="tr-ref" className="mb-1.5 block text-sm">Order ID</label>
            <input id="tr-ref" className="field uppercase placeholder:normal-case" placeholder="AUR-DEMO-123456" autoComplete="off" autoCapitalize="characters" spellCheck={false} value={form.ref} onChange={(e) => { setForm({ ...form, ref: e.target.value }); setErrors((x) => ({ ...x, ref: undefined })) }} {...ia('ref')} />
            {errors.ref && <p id="tr-ref-err" role="alert" className="mt-1.5 text-[13px] text-bad">{errors.ref}</p>}
          </div>
          <div>
            <label htmlFor="tr-mobile" className="mb-1.5 block text-sm">Registered mobile number</label>
            <div className="flex">
              <span className="grid min-w-14 place-items-center border border-r-0 border-line bg-sand text-sm" aria-hidden="true">+91</span>
              <input id="tr-mobile" className="field" inputMode="numeric" autoComplete="tel-national" placeholder="10-digit number" value={form.mobile} onChange={(e) => { setForm({ ...form, mobile: e.target.value }); setErrors((x) => ({ ...x, mobile: undefined })) }} {...ia('mobile')} />
            </div>
            {errors.mobile && <p id="tr-mobile-err" role="alert" className="mt-1.5 text-[13px] text-bad">{errors.mobile}</p>}
          </div>
        </div>
        <Button type="submit" size="lg" className="mt-6 w-full" disabled={phase === 'loading'}>
          {phase === 'loading' ? <><Loader2 size={18} className="motion-safe:animate-spin" aria-hidden="true" /> Looking up your order…</> : <><PackageSearch size={18} aria-hidden="true" /> Track order</>}
        </Button>

        <div className="mt-6 border-t border-line pt-5 text-sm">
          <p className="font-medium">Want to try it?</p>
          <p className="mt-1 text-ink-soft">
            Use the <strong>demo test order</strong>: ID <code className="bg-sand px-1.5 py-0.5">{DEMO_TEST_ORDER.ref}</code>, mobile <code className="bg-sand px-1.5 py-0.5">{DEMO_TEST_ORDER.mobile}</code>.
            Orders you place in this demo also work with the number you entered.
          </p>
          <Button variant="outline" size="sm" className="mt-3" onClick={fillDemo} disabled={phase === 'loading'}>Track the demo test order</Button>
        </div>
      </form>

      <div ref={resultRef} tabIndex={-1} className="mx-auto mt-10 max-w-6xl outline-none" aria-live="polite" aria-busy={phase === 'loading'}>
        <AnimatePresence mode="wait">
          {phase === 'loading' && (
            <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6" aria-label="Loading order">
              <Skeleton className="h-28 w-full" />
              <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
                <Skeleton className="h-96 w-full" />
                <div className="space-y-6"><Skeleton className="h-48 w-full" /><Skeleton className="h-32 w-full" /></div>
              </div>
            </motion.div>
          )}
          {phase === 'done' && order && <Result key={order.id} order={order} />}
          {phase === 'done' && !order && (
            <motion.div key="nf" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto flex max-w-md flex-col items-center py-8 text-center">
              <div className="mb-6 grid size-20 place-items-center rounded-full bg-rose-mist text-rose"><SearchX size={32} strokeWidth={1.3} aria-hidden="true" /></div>
              <h2 className="text-3xl">We couldn&rsquo;t find that order</h2>
              <p className="mt-3 text-ink-soft">
                Please check the order ID and mobile number. Demo orders are stored only in the browser they were placed in, so they won&rsquo;t appear on other devices.
              </p>
              <ButtonLink to="/shop" variant="outline" className="mt-6">Continue shopping</ButtonLink>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
