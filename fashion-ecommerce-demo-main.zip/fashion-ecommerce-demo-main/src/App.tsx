import { MotionConfig } from 'motion/react'
import { lazy, Suspense } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { ScrollToTop, StoreLayout } from './components/layout/StoreLayout'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import Home from './pages/Home'
import { Collections, ErrorBoundary, NotFound, StaticPage, Wishlist } from './pages/Misc'
import OrderConfirmation from './pages/OrderConfirmation'
import ProductDetail from './pages/ProductDetail'
import TrackOrder from './pages/TrackOrder'
import Shop from './pages/Shop'

// The admin demo is code-split so shoppers never download it.
const AdminLayout = lazy(() => import('./pages/admin/AdminLayout').then((m) => ({ default: m.AdminLayout })))
const Dashboard = lazy(() => import('./pages/admin/Dashboard'))
const ProductsAdmin = lazy(() => import('./pages/admin/ProductsAdmin'))
const OrdersAdmin = lazy(() => import('./pages/admin/OrdersAdmin'))
const GalleryAdmin = lazy(() => import('./pages/admin/GalleryAdmin'))
const CustomersAdmin = lazy(() => import('./pages/admin/CustomersAdmin'))

export default function App() {
  return (
    <ErrorBoundary>
      <MotionConfig reducedMotion="user">
        <BrowserRouter>
          <ScrollToTop />
          <Suspense fallback={<div className="font-brand grid min-h-dvh place-items-center px-6 text-center text-2xl font-semibold tracking-[-0.025em]">Srivel Fashion House</div>}>
            <Routes>
              <Route element={<StoreLayout />}>
                <Route index element={<Home />} />
                <Route path="shop" element={<Shop />} />
                <Route path="collections" element={<Collections />} />
                <Route path="product/:slug" element={<ProductDetail />} />
                <Route path="cart" element={<Cart />} />
                <Route path="checkout" element={<Checkout />} />
                <Route path="order/:id" element={<OrderConfirmation />} />
                <Route path="track-order" element={<TrackOrder />} />
                <Route path="wishlist" element={<Wishlist />} />
                <Route path="pages/:slug" element={<StaticPage />} />
                <Route path="*" element={<NotFound />} />
              </Route>
              <Route path="admin-demo" element={<AdminLayout />}>
                <Route index element={<Dashboard />} />
                <Route path="products" element={<ProductsAdmin />} />
                <Route path="orders" element={<OrdersAdmin />} />
                <Route path="instagram" element={<GalleryAdmin />} />
                <Route path="customers" element={<CustomersAdmin />} />
              </Route>
            </Routes>
          </Suspense>
        </BrowserRouter>
      </MotionConfig>
    </ErrorBoundary>
  )
}
