export type CategorySlug =
  | 'sarees'
  | 'kurtis'
  | 'ethnic-sets'
  | 'western-wear'
  | 'dresses'
  | 'occasion-wear'

export interface CategoryInfo {
  slug: CategorySlug
  label: string
  blurb: string
}

export interface ColorOption {
  name: string
  hex: string
}

export interface Variant {
  size: string
  color: string // ColorOption.name
  stock: number
}

export interface Product {
  id: string
  name: string
  slug: string
  category: CategorySlug
  description: string
  fabric: string
  care: string[]
  price: number
  compareAtPrice?: number
  /** Real image URLs, or `art:` generated-illustration tokens (see lib/art). */
  images: string[]
  colors: ColorOption[]
  sizes: string[]
  variants: Variant[]
  stock: number
  isNew: boolean
  isFeatured: boolean
  isBestseller?: boolean
  collection?: string
}

export interface CartItem {
  key: string
  productId: string
  size: string
  color: string
  qty: number
}

export type OrderStatus =
  | 'Pending Confirmation'
  | 'Confirmed'
  | 'Packed'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'

export type PaymentStatus = 'COD – Pending' | 'COD – Collected' | 'Not applicable'

export interface CustomerDetails {
  fullName: string
  mobile: string
  address1: string
  address2: string
  city: string
  state: string
  pincode: string
  landmark: string
}

export interface OrderLine {
  productId: string
  name: string
  size: string
  color: string
  qty: number
  unitPrice: number
}

export interface StatusEvent {
  status: OrderStatus
  /** ISO timestamp */
  at: string
}

export interface ShippingInfo {
  courierName?: string
  trackingNumber?: string
  /** Optional external courier tracking page. Only http(s) URLs are ever rendered as links. */
  trackingUrl?: string
}

export interface Order {
  id: string
  ref: string
  createdAt: string
  customer: CustomerDetails
  lines: OrderLine[]
  subtotal: number
  shipping: number
  total: number
  method: 'cod' | 'whatsapp'
  status: OrderStatus
  paymentStatus: PaymentStatus
  /** Every status the order has been in, oldest first. */
  history: StatusEvent[]
  shippingInfo?: ShippingInfo
  isSample?: boolean
  /** The dedicated, clearly marked order for trying out tracking. */
  isDemoTest?: boolean
}

/* ── Social proof: Instagram gallery & customer photos ───────────────────
   Clean, API-ready models. In the demo they live in localStorage (metadata)
   and IndexedDB (uploaded files). In production: `media.value` becomes a CDN URL. */

export type MediaKind = 'image' | 'video'
/** art = generated demo illustration, url = external/public image, upload = file in this browser's IndexedDB */
export type MediaSource = 'art' | 'url' | 'upload'

export interface MediaRef {
  source: MediaSource
  kind: MediaKind
  /** art token | http(s)/relative URL | IndexedDB key */
  value: string
  mimeType?: string
  sizeBytes?: number
  width?: number
  height?: number
}

export type InstagramItemType = 'post' | 'reel' | 'upload'

export interface InstagramItem {
  id: string
  type: InstagramItemType
  /** Canonical https://www.instagram.com/{p|reel}/{code}/ link, when the item points at real Instagram content. */
  instagramUrl?: string
  media?: MediaRef
  thumbnail?: MediaRef
  caption: string
  /** Lower numbers appear first. */
  order: number
  active: boolean
  isDemo?: boolean
  createdAt: string
}

export interface CustomerPhoto {
  id: string
  photo: MediaRef
  /** First name or initials only, e.g. "Priya" or "P. S." */
  displayName: string
  city: string
  productName: string
  /** Optional, genuine customer feedback. Never auto-generated. */
  review?: string
  /** The customer agreed to have this photo and these details published. */
  consentGiven: boolean
  consentAt?: string
  /** Admin-only note about how consent was obtained (e.g. "WhatsApp, 12 Oct"). Never shown publicly. */
  consentNote?: string
  /** Admin confirms the photo shows no address, phone number, parcel label or tracking code. */
  privacyChecked: boolean
  order: number
  visible: boolean
  isDemo?: boolean
  createdAt: string
}
